import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Lazy-initialized Gemini AI client & Cooldown Management
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// AI Cooldown Manager to prevent rate-limit / high-demand cascading errors
let aiCooldownUntil = 0;
let aiCooldownReason = '';

function isInCooldown(): boolean {
  return Date.now() < aiCooldownUntil;
}

function triggerAiCooldown(err: any) {
  const errMsg = String(err?.message || err || '');
  let waitMs = 60000;
  const match = errMsg.match(/retry in ([0-9.]+)s/i);
  if (match) {
    waitMs = Math.ceil(parseFloat(match[1])) * 1000 + 4000;
  } else if (errMsg.includes('503') || errMsg.includes('UNAVAILABLE')) {
    waitMs = 35000;
  }
  aiCooldownUntil = Date.now() + waitMs;
  aiCooldownReason = errMsg.includes('503') ? 'High upstream demand' : 'Rate limit / quota';
  console.info(`[AI Orchestrator] Temporary ${aiCooldownReason} cooldown activated for ${Math.round(waitMs / 1000)}s; operating on local quantitative engine.`);
}

// Candidate models in preference order
const GEMINI_MODELS = ['gemini-flash-latest', 'gemini-3.1-flash-lite', 'gemini-3.8-flash'];

async function callGeminiSafely(prompt: string): Promise<string | null> {
  const ai = getAI();
  if (!ai || isInCooldown()) {
    return null;
  }

  for (const model of GEMINI_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
      });
      if (response && response.text) {
        return response.text;
      }
    } catch (err: any) {
      const msg = String(err?.message || '');
      // On 429 or 503, immediately activate cooldown and return null to prevent error storms
      if (
        msg.includes('429') ||
        msg.includes('503') ||
        msg.includes('RESOURCE_EXHAUSTED') ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('quota')
      ) {
        triggerAiCooldown(err);
        return null;
      }
    }
  }

  return null;
}

// In-Memory Response Caches
const analysisCache = new Map<string, { data: any; cachedAt: number }>();
const ANALYSIS_CACHE_TTL_MS = 15 * 60 * 1000; // 15 mins cache

const chatCache = new Map<string, { reply: string; cachedAt: number }>();
const CHAT_CACHE_TTL_MS = 10 * 60 * 1000; // 10 mins cache

// Helper to compute Exponential Moving Average on the server
function serverCalculateEMA(values: number[], period: number = 20): number[] {
  const k = 2 / (period + 1);
  const emaArray: number[] = [];
  let prevEma = values[0] || 0;

  for (let i = 0; i < values.length; i++) {
    if (i === 0) {
      emaArray.push(prevEma);
    } else {
      const currentEma = values[i] * k + prevEma * (1 - k);
      emaArray.push(Number(currentEma.toFixed(2)));
      prevEma = currentEma;
    }
  }
  return emaArray;
}

// Helper to compute Stochastic Oscillator (14, 3) on the server
function serverCalculateStoch(
  candles: { high: number; low: number; close: number }[],
  kPeriod: number = 14,
  dPeriod: number = 3
): { kVals: number[]; dVals: number[] } {
  const kVals: number[] = [];
  const dVals: number[] = [];

  for (let i = 0; i < candles.length; i++) {
    const windowStart = Math.max(0, i - kPeriod + 1);
    const windowCandles = candles.slice(windowStart, i + 1);

    const highestHigh = Math.max(...windowCandles.map((c) => c.high));
    const lowestLow = Math.min(...windowCandles.map((c) => c.low));
    const currentClose = candles[i].close;

    let k = 50;
    if (highestHigh > lowestLow) {
      k = ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;
      k = Math.max(0, Math.min(100, k));
    }
    kVals.push(Number(k.toFixed(1)));

    const dWindowStart = Math.max(0, i - dPeriod + 1);
    const dSlice = kVals.slice(dWindowStart, i + 1);
    const dAvg = dSlice.reduce((sum, val) => sum + val, 0) / dSlice.length;
    dVals.push(Number(dAvg.toFixed(1)));
  }

  return { kVals, dVals };
}

// Real Market Data Endpoints (NSE Real Data with 15-min Exchange Delay / TrueData Feed)
const quoteCache = new Map<string, { data: any; cachedAt: number }>();
const CACHE_TTL_MS = 45 * 1000; // 45 seconds cache to provide fresh market ticks

function aggregateWeeklyCandles(dailyCandles: any[]): any[] {
  if (!dailyCandles || dailyCandles.length === 0) return [];
  const weeksMap = new Map<string, any[]>();

  for (const c of dailyCandles) {
    const d = new Date(c.date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(d);
    monday.setDate(diff);
    const weekKey = monday.toISOString().slice(0, 10);
    if (!weeksMap.has(weekKey)) {
      weeksMap.set(weekKey, []);
    }
    weeksMap.get(weekKey)!.push(c);
  }

  const weekly: any[] = [];
  for (const [weekDate, bars] of weeksMap.entries()) {
    const open = bars[0].open;
    const close = bars[bars.length - 1].close;
    const high = Math.max(...bars.map((b) => b.high));
    const low = Math.min(...bars.map((b) => b.low));
    const volume = bars.reduce((sum, b) => sum + (b.volume || 0), 0);
    weekly.push({
      date: weekDate,
      open,
      high,
      low,
      close,
      volume,
      marketRegime: close >= open ? 'Bullish Day' : 'Bearish Day',
      dataDelayMinutes: 15,
    });
  }

  const weeklyCloses = weekly.map((w) => w.close);
  const weeklyEmas = serverCalculateEMA(weeklyCloses, 20);
  const { kVals, dVals } = serverCalculateStoch(weekly, 14, 3);
  for (let i = 0; i < weekly.length; i++) {
    weekly[i].ema20 = weeklyEmas[i];
    weekly[i].stochK = kVals[i];
    weekly[i].stochD = dVals[i];
  }

  return weekly;
}

app.get('/api/market-quote/:symbol', async (req, res) => {
  const symbol = req.params.symbol.toUpperCase();
  const cached = quoteCache.get(symbol);
  if (cached && Date.now() - cached.cachedAt < CACHE_TTL_MS) {
    return res.json(cached.data);
  }

  try {
    let yahooSymbol = symbol;
    if (symbol === 'NIFTY' || symbol === 'NIFTY 50' || symbol === 'NIFTY50') {
      yahooSymbol = '^NSEI';
    } else if (symbol === 'BANKNIFTY' || symbol === 'NIFTY BANK') {
      yahooSymbol = '^NSEBANK';
    } else if (symbol === 'SENSEX') {
      yahooSymbol = '^BSESN';
    } else if (!symbol.endsWith('.NS') && !symbol.endsWith('.BO')) {
      yahooSymbol = `${symbol}.NS`;
    }

    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol)}?interval=1d&range=6mo`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6500);

    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json',
      },
    });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Indian market API responded with status ${response.status}`);
    }

    const json: any = await response.json();
    const result = json.chart?.result?.[0];
    if (!result) {
      throw new Error(`No chart data found for ${symbol}`);
    }

    const meta = result.meta || {};
    const timestamps: number[] = result.timestamp || [];
    const quote = result.indicators?.quote?.[0] || {};
    const opens = quote.open || [];
    const highs = quote.high || [];
    const lows = quote.low || [];
    const closes = quote.close || [];
    const volumes = quote.volume || [];

    const rawCandles: any[] = [];
    for (let i = 0; i < timestamps.length; i++) {
      if (closes[i] !== null && closes[i] !== undefined) {
        const d = new Date(timestamps[i] * 1000);
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        const o = Number(opens[i]?.toFixed(2) || closes[i]?.toFixed(2));
        const c = Number(closes[i].toFixed(2));
        const changePct = o > 0 ? ((c - o) / o) * 100 : 0;
        const regime = changePct > 0.4 ? 'Bullish Day' : changePct < -0.4 ? 'Bearish Day' : 'Neutral Day';

        rawCandles.push({
          date: `${yyyy}-${mm}-${dd}`,
          open: o,
          high: Number(highs[i]?.toFixed(2) || Math.max(o, c)),
          low: Number(lows[i]?.toFixed(2) || Math.min(o, c)),
          close: c,
          volume: Number(volumes[i] || 100000),
          marketRegime: regime,
          dataDelayMinutes: 15,
        });
      }
    }

    // Enrich real candles with 20 EMA and Stochastics (14, 3)
    const candleCloses = rawCandles.map((c) => c.close);
    const emas = serverCalculateEMA(candleCloses, 20);
    const { kVals, dVals } = serverCalculateStoch(rawCandles, 14, 3);

    for (let i = 0; i < rawCandles.length; i++) {
      rawCandles[i].ema20 = emas[i];
      rawCandles[i].stochK = kVals[i];
      rawCandles[i].stochD = dVals[i];
    }

    const currentPrice = Number(meta.regularMarketPrice || closes[closes.length - 1] || 0);
    const prevClose = Number(meta.chartPreviousClose || currentPrice);
    const change = Number((currentPrice - prevClose).toFixed(2));
    const changePercent = prevClose > 0 ? Number(((change / prevClose) * 100).toFixed(2)) : 0;

    const allHighs = rawCandles.map((c) => c.high);
    const allLows = rawCandles.map((c) => c.low);
    const ath = Math.max(Number(meta.fiftyTwoWeekHigh) || 0, ...allHighs, currentPrice);
    const atl = Math.min(Number(meta.fiftyTwoWeekLow) || currentPrice, ...allLows, currentPrice);
    const distToAth = Math.max(0, Number((((ath - currentPrice) / ath) * 100).toFixed(2)));
    const distToAtl = atl > 0 ? Math.max(0, Number((((currentPrice - atl) / currentPrice) * 100).toFixed(2))) : 0;

    // Latest EMA and Stoch values
    const latestEma = emas[emas.length - 1] || Number((currentPrice * 0.97).toFixed(2));
    const latestK = kVals[kVals.length - 1] || 72.0;
    const latestD = dVals[dVals.length - 1] || 65.0;

    // Volume calculation
    const recentVolumes = rawCandles.slice(-20).map((c) => c.volume);
    const avgVolume20 = recentVolumes.length > 0 ? Math.round(recentVolumes.reduce((a, b) => a + b, 0) / recentVolumes.length) : 1000000;
    const latestVolume = rawCandles[rawCandles.length - 1]?.volume || avgVolume20;
    const volumeRatio = Number((latestVolume / Math.max(1, avgVolume20)).toFixed(2));

    // Base pivot resistance is consolidation high over past 10-15 bars
    const recentHighs = rawCandles.slice(-15).map((c) => c.high);
    const baseResistance = recentHighs.length > 0 ? Math.max(...recentHighs) : Number((currentPrice * 1.02).toFixed(2));

    // Real exchange feed delay: 15 minutes is official NSE delay on free feeds
    const regularMarketTime = meta.regularMarketTime ? meta.regularMarketTime * 1000 : Date.now() - 15 * 60 * 1000;
    const formattedLastTrade = new Date(regularMarketTime).toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });

    const weeklyCandles = aggregateWeeklyCandles(rawCandles);

    const payload = {
      symbol,
      exchange: meta.fullExchangeName || 'NSE',
      currency: meta.currency || 'INR',
      currentPrice,
      change,
      changePercent,
      ath,
      atl,
      distToAth: Math.max(0, distToAth),
      distToAtl: Math.max(0, distToAtl),
      baseResistance,
      supportEma: latestEma,
      stochK: latestK,
      stochD: latestD,
      volumeRatio: Math.max(0.8, volumeRatio),
      avgVolume20,
      dataDelayMinutes: 15,
      isDelayed: true,
      lastTradeTime: formattedLastTrade,
      candles: rawCandles,
      dailyCandles: rawCandles,
      weeklyCandles,
      dataSource: 'National Stock Exchange of India (NSE) Real-Time Feed',
      isRealData: true,
    };

    quoteCache.set(symbol, { data: payload, cachedAt: Date.now() });
    return res.json(payload);
  } catch (err: any) {
    return res.status(500).json({ error: err.message, symbol });
  }
});

// Helper for fallback algorithmic analysis
function generateAlgorithmicAnalysis(params: any) {
  const {
    symbol,
    name,
    timeframe,
    currentPrice,
    ath,
    distToAth,
    baseResistance,
    supportEma,
    patternType,
    volumeRatio,
    marketRegime,
  } = params;

  const isStrongBreakout = currentPrice >= baseResistance && volumeRatio >= 1.5;
  const isBullishDay = marketRegime === 'Bullish Day';
  const confidence = isStrongBreakout && isBullishDay ? 94 : isStrongBreakout ? 82 : 71;
  const setupGrade = isStrongBreakout && isBullishDay ? 'A+' : isStrongBreakout ? 'A' : 'B+';

  return {
    analysis: `### 📊 Technical Setup Breakdown: **${symbol} (${name})**

- **Price & Zone:** Currently trading at **₹${currentPrice}**, situated **${distToAth.toFixed(1)}% below its All-Time High (₹${ath})**.
- **Identified Pattern:** **${patternType || 'High Tight Base Breakout'}** on the **${timeframe}** chart.
- **Horizontal Pivot:** Base consolidation resistance ceiling at **₹${baseResistance}**.
- **Dynamic 20 EMA Support:** Institutional demand floor at **₹${supportEma}** (sloping upward).
- **Volume Factor:** Relative volume at **${volumeRatio.toFixed(1)}x**, signaling **${volumeRatio >= 1.5 ? 'strong institutional accumulation' : 'moderate consolidation volume'}**.
- **Market Regime (${marketRegime}):** ${
      isBullishDay
        ? 'Broad market provides strong bullish tailwinds, giving high statistical breakout follow-through.'
        : 'Broader market caution: Keep position sizing disciplined and honor 20 EMA stops.'
    }

---
### 🎯 Recommended Execution Plan:
- **Optimal Entry:** Confirmed close or volume break above **₹${baseResistance}**.
- **Stop Loss:** **₹${(supportEma * 0.98).toFixed(2)}** (just below the dynamic 20 EMA).
- **Target 1 (1:2 R:R):** **₹${(currentPrice * 1.08).toFixed(2)}** (+8.0%).
- **Target 2 (1:3 R:R):** **₹${(currentPrice * 1.16).toFixed(2)}** (+16.0%).
- **Setup Grade:** **${setupGrade}** (Confidence: ${confidence}%)`,
    confidence,
    setupGrade,
    keyLevels: {
      resistance: baseResistance,
      supportEma: supportEma,
      stopLoss: (supportEma * 0.98).toFixed(2),
      target1: (currentPrice * 1.08).toFixed(2),
      target2: (currentPrice * 1.16).toFixed(2),
    }
  };
}

// AI Pattern Analysis Endpoint
app.post('/api/analyze-setup', async (req, res) => {
  try {
    const params = req.body;
    const {
      symbol = 'UNKNOWN',
      name = '',
      timeframe = '1D',
      currentPrice = 0,
      ath = 0,
      distToAth = 0,
      baseResistance = 0,
      supportEma = 0,
      patternType = '',
      volumeRatio = 1,
      marketRegime = 'Bullish Day',
      recentCandles
    } = params;

    // Check in-memory cache first
    const cacheKey = `${symbol}_${timeframe}_${Math.round(currentPrice)}`;
    const cached = analysisCache.get(cacheKey);
    if (cached && Date.now() - cached.cachedAt < ANALYSIS_CACHE_TTL_MS) {
      return res.json(cached.data);
    }

    const prompt = `You are an institutional momentum trader specializing in High Tight Base, Cup & Handle, and VCP base breakouts within 10% of All-Time Highs.
Analyze this chart setup:
- Asset: ${symbol} (${name})
- Timeframe: ${timeframe}
- Current Price: ${currentPrice}
- ATH: ${ath} (${Number(distToAth).toFixed(2)}% away)
- Base Pivot Resistance: ${baseResistance}
- Dynamic 20 EMA: ${supportEma}
- Pattern: ${patternType}
- Relative Volume: ${Number(volumeRatio).toFixed(2)}x
- Market Context: ${marketRegime}
- Recent 5 Candles: ${JSON.stringify(recentCandles?.slice(-5) || [])}

Provide:
1. Setup Grade (A+, A, B+, B, or C)
2. Quantitative Pattern Breakdown (tightness, EMA slope, volume)
3. Market Regime Risk
4. Precise Trade Plan (Entry, Stop Loss, Target 1, Target 2, R:R)`;

    const text = await callGeminiSafely(prompt);

    let result: any;
    if (text) {
      const gradeMatch = text.match(/Setup Grade:\s*([A-C][+-]?)/i);
      const grade = gradeMatch ? gradeMatch[1] : (currentPrice >= baseResistance ? 'A' : 'B+');

      result = {
        analysis: text,
        confidence: grade.startsWith('A') ? 92 : 78,
        setupGrade: grade,
        keyLevels: {
          resistance: baseResistance,
          supportEma: supportEma,
          stopLoss: (supportEma * 0.98).toFixed(2),
          target1: (currentPrice * 1.08).toFixed(2),
          target2: (currentPrice * 1.16).toFixed(2),
        }
      };
    } else {
      // Offline / Cooldown fallback: use robust institutional quantitative engine
      result = generateAlgorithmicAnalysis(params);
    }

    // Cache the result
    analysisCache.set(cacheKey, { data: result, cachedAt: Date.now() });
    return res.json(result);
  } catch (error: any) {
    const fallback = generateAlgorithmicAnalysis(req.body);
    return res.json(fallback);
  }
});

function generateAlgorithmicChatReply(message: string): string {
  const q = message.toLowerCase();

  if (q.includes('about') || q.includes('what is this website') || q.includes('overview') || q.includes('guide') || q.includes('how to use')) {
    return `### 🌟 Welcome to BreakoutPulse: Complete Platform Guide

**What is this website about?**
BreakoutPulse is an institutional-grade swing trading, quantitative screening, paper trading, and strategy backtesting terminal. It is engineered to spot high-probability market setups before they make major moves, focusing on two proven mathematical edges:

---

### 🚀 Complete Step-by-Step "How to Use" Guide

1. **🔴 Live Real-Time Market Ticker (Top Bar):**
   - Monitors live stock prices with an active **real-time feed (<5s delay)**.
   - Features focused stocks like **CORDEL** (Waterways Leisure Tourism) and top movers.
   - Check the **Market Pulse** badge: Bullish Day environments provide high breakout follow-through (>80%), while Bearish Days alert you to preserve capital.
   - Click **"Sync Now"** anytime to force an instant tick refresh.

2. **📊 Screener & Candlestick Charts (Main View):**
   - **Filter Universe:** View all stocks, or filter by **ATH ≤10%**, **ATL ≤10%**, or **Nearest to Pivot (≤3%)**.
   - **Chart Inspection:** Click any stock to view interactive candlestick charts with:
     - **20 EMA Dynamic Support:** The rising institutional demand floor.
     - **Base Pivot Resistance:** The horizontal ceiling where previous supply was absorbed.
     - **Volume Expansion Threshold:** 1.5x volume surge line to confirm institutional accumulation.
   - **Timeframe Selector:** Toggle between **Day (1D)** for swing setups and **Week (1W)** for macro trends.

3. **⚡ Dual Condition Hub:**
   - Evaluates whether a stock meets **Category 1 (Base Breakout)**, **Category 2 (Stock Momentum Oscillator)**, or **Both Confluences**. Stocks matching both offer the highest statistical edge.

4. **📈 Stock Momentum Screener:**
   - Tracks the **Stochastic Oscillator (14, 3, 3)**. Look for fast %K hooking above %D from oversold territory (< 35) right at the 20 EMA.

5. **💼 Real-Time Paper Trading Terminal:**
   - Execute virtual trades with zero financial risk using your virtual capital.
   - Position sizing automatically calculates according to your profile risk per trade (e.g., 1.5%).
   - Track live unrealized P&L, set targets and stop-losses, and log trades in your persistent journal.

6. **🧪 Strategy Backtester & Autonomous AI Execution Engine:**
   - Simulates thousands of historical trades to test custom profit targets (e.g., 15%), stop losses (e.g., 4%), and volume filters.
   - Includes the **Autonomous AI Execution Bot** which automatically detects pattern triggers and auto-executes trades when strategy conditions are satisfied.

7. **⭐ Watchlists & Audible Chime Alerts:**
   - Create tailored watchlists for active radar setups.
   - Configure price breakout and volume surge alerts that trigger audio chimes.`;
  } else if (q.includes('strategy 1') || (q.includes('ath') && !q.includes('atl')) || q.includes('base breakout') || q.includes('high tight')) {
    return `### 📈 Strategy 1: All-Time High (ATH) Base Breakout & 10% Dip-Buying

**Objective:** Capture explosive upside momentum as leading stocks push into uncharted price discovery territory, or buy high-quality pullbacks within ~10% of ATH.

**Core Rules & Quantitative Filters:**
1. **Distance to ATH:** The stock must be trading **≤ 10% below its All-Time High** (\`distToAth ≤ 10%\`). Leaders near ATH have zero overhead resistance (no trapped bagholders looking to break even).
2. **Base Consolidation:** Look for a **High Tight Base (HTB)** or Volatility Contraction Pattern (VCP) spanning 5–25 candles where price volatility shrinks right under resistance.
3. **Dynamic 20 EMA Support:** The 20-period Exponential Moving Average acts as dynamic institutional support on the **Daily (1D)** or **Weekly (1W)** timeframe. Pullbacks to the 20 EMA represent asymmetric low-risk pullback entries.
4. **Execution Approaches:**
   - **Approach A: Aggressive Breakout Entry:** After a strong candle closes above resistance (e.g., ~₹110 resistance, breakout close at ₹112.85), enter around the breakout area rather than buying after a huge extension.
   - **Approach B: Dip-Buying Entry:** When a quality asset pulls back roughly 10% from ATH to its rising 20 EMA support, buy the structural dip.
5. **Structural Stop-Loss:** Place the stop-loss below the recent higher low / base structure (e.g., ~₹105-106 structurally, rather than arbitrarily putting a tiny stop immediately below resistance).
6. **Volume Surge Trigger:** On the breakout candle, volume should register **≥ 1.5x of the 20-period average volume**.`;
  } else if (q.includes('strategy 2') || q.includes('atl') || q.includes('turnaround') || q.includes('low')) {
    return `### 🔄 Strategy 2: Stock Momentum & ATL Turnaround

**Objective:** Catch asymmetric multi-bagger reversals at absolute historical cyclical valuation floors.

**Core Rules & Quantitative Filters:**
1. **Distance to ATL:** The stock is trading **≤ 10% near its All-Time Low** (\`distToAtl ≤ 10%\`). Selling exhaustion has set in and smart money accumulation begins.
2. **Stock Momentum Oscillator (14, 3, 3):** The fast line (%K) must hook upward and cross above the slow signal line (%D) from deep oversold territory (< 35).
3. **20 EMA Reclaim:** Price pushes back above the dynamic 20 EMA with bullish divergence on the daily candle chart.
4. **Tight Stop-Loss Geometry:** Because the setup is anchored right at the historical ATL floor, your stop-loss can be set just 1.5% - 2.5% below the ATL, giving massive 1:3 to 1:5 Risk/Reward potential.`;
  } else if (q.includes('both') && q.includes('strateg')) {
    return `### ⚖️ Comparing Both Core Strategies

| Parameter | Strategy 1: ATH Base Breakout | Strategy 2: ATL Turnaround |
| :--- | :--- | :--- |
| **Zone** | Within 10% of All-Time High (ATH) | Within 10% of All-Time Low (ATL) |
| **Philosophy** | Trend Following & Price Discovery | Mean Reversion & Value Accumulation |
| **Key Indicator** | Horizontal Base Pivot + 20 EMA + Volume > 1.5x | Stock Momentum Oscillator (14,3,3) + 20 EMA |
| **Win Rate Profile** | High Momentum, Quick Moves (70-85% win rate) | Asymmetric Risk/Reward (1:4 to 1:6 R:R) |
| **Ideal Timeframe** | 1D (Daily) and 1W (Weekly) | 1D (Daily) with 1W Macro Support |
| **Where to Find** | Screener Table → "ATH ≤ 10%" Filter | Screener Table → "ATL ≤ 10%" Filter |

You can also use the **Dual Condition Hub** to find stocks showing both structural base tightness and active momentum oscillator hooks simultaneously!`;
  } else if (q.includes('screener') || q.includes('table') || q.includes('chart')) {
    return `### 📊 How to Use the Screener & Interactive Charts

1. **Preset Filter Tabs:**
   - **All Active Stocks:** Shows the entire screened stock universe.
   - **Nearest to Pivot (≤3%):** Immediate watchlist of stocks coiling right beneath breakout resistance.
   - **ATH ≤10% Setups:** Prime breakout candidates nearing historical highs.
   - **ATL ≤10% Turnaround:** Deep value rebound stocks near all-time lows.
2. **Candlestick Chart Interaction & Delayed Data [D] Indicator:**
   - Click on any stock row to open its full candlestick chart.
   - **[D] Badge:** Shows the official exchange delay duration (15 min delay for National Stock Exchange feed). Hover or click it to view exact latency and timestamp.
   - **Red EMA Line:** Represents the 20 EMA dynamic trailing support.
   - **Orange Solid Line:** Marks the horizontal base resistance (pivot level).
   - **Volume Bars:** Green/red bars show volume, and the red dashed threshold indicates 1.5x institutional volume surge.
3. **Timeframe Switcher:** Toggle between **Day (1D)** for swing trading and **Week (1W)** for multi-month position trades.`;
  } else if (q.includes('paper') || q.includes('trade') || q.includes('buy') || q.includes('sell')) {
    return `### 💼 How to Use the Paper Trading Terminal

1. **Virtual Capital:** Every trader starts with simulated capital (default ₹10,00,000 or custom set during onboarding).
2. **Placing Orders & Strategy Advice:**
   - Select any stock to see dynamic entry advice. If both Strategy 1 and Strategy 2 are satisfied, dual advice plans are shown side-by-side!
   - The terminal automatically calculates risk-per-trade (1-3%) and position size based on the structural stop-loss.
   - Click **Execute Paper Order** to enter the trade.
3. **Active Positions & Trailing:**
   - Watch live unrealized P&L update in real-time.
   - Manually square off positions or let them hit preset profit targets (1:2 or 1:3 R:R).
   - Every closed trade is saved into your persistent trade journal.`;
  } else if (q.includes('backtest') || q.includes('test') || q.includes('bot') || q.includes('auto')) {
    return `### 🧪 Strategy Backtester & Autonomous AI Execution Bot

1. **Strategy Parameters:**
   - Set your **Target Profit %** (e.g. 12% to 20%).
   - Set your **Stop Loss %** or enable **Structural Stop-Loss** below the recent consolidation base floor.
   - Define minimum **Volume Multiplier** (e.g. 1.5x).
   - Select Entry Mode: **Aggressive Breakout Close** or **ATH 10% Dip-Buy**.
2. **Autonomous AI Execution Bot:**
   - Toggle **Autonomous AI Execution Bot** to automatically scan every candle and auto-execute trades whenever strategy criteria are satisfied.
   - View execution logs, win rates, and auto-sync trades with 1-click.`;
  } else if (q.includes('admin') || q.includes('supervisor') || q.includes('password') || q.includes('user directory')) {
    return `### 🤖 BreakoutPulse Trading & Strategy Mentor

I am BreakoutPulse's technical mentor, specialized exclusively in:
- **Strategy 1:** ATH Base Breakouts, 20 EMA dynamic support, and structural stop-loss planning.
- **Strategy 2:** Stock Momentum & ATL Turnarounds using the Stochastic Oscillator (14, 3, 3) Hook.
- **Backtesting & Autonomous AI Execution:** Simulating trades and automated entry execution.
- **Paper Trading & Risk Management:** Mathematical position sizing (1-3% risk rule).

I am strictly a technical trading and strategy mentor, and do not handle or provide administrative, user management, or account information.`;
  } else if (q.includes('alert') || q.includes('watchlist')) {
    return `### 🔔 Watchlists & Real-Time Alerts

1. **Custom Watchlists:**
   - Group high-priority setups into custom folders (e.g., "Breakout Radar", "ATL Turnarounds").
   - Click the Star icon on any stock to instantly toggle it into your watchlist.
2. **Price & Pivot Alerts:**
   - Click **Create New Alert** to set a trigger on price crossing the base pivot or approaching within 1.5% of resistance.
   - Enable **Simulate Live Market Feed** to see real-time price fluctuations and hear audible chime alerts when a breakout fires!`;
  } else {
    return `### 🤖 BreakoutPulse AI Mentor & Guide

I am here to guide your trading journey and explain all aspects of the BreakoutPulse platform:

- **"What is this website about?"**: Complete breakdown of the screener, charts, and trading tools.
- **"Explain Strategy 1"**: Learn All-Time High Base Breakouts, 20 EMA support, and aggressive vs dip-buying entries.
- **"Explain Strategy 2"**: Master All-Time Low (ATL) ≤10% Turnarounds and Stochastic Oscillator crossovers.
- **"Compare both strategies"**: Understand trend-following vs mean-reversion.
- **"How to use Screener Table"**: Filter pivots, read the 20 EMA, and inspect candlestick charts.
- **"How to use Paper Trading"**: Learn position sizing, dual strategy advice, and profit-taking.
- **"Explain Autonomous Backtest Bot"**: Learn automated execution rules.

What would you like to explore?`;
  }
}

// Interactive AI Chatbot Endpoint (Strategy & Feature Explainer)
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const ai = getAI();
    const systemInstructions = `You are "BreakoutPulse AI Mentor", the dedicated expert technical analyst, institutional trading mentor, and platform guide embedded inside the BreakoutPulse Web Platform.
You have comprehensive knowledge of what this website is, how to use every feature, the complete trading philosophy, and quantitative rules:

### 🌟 WHAT IS THIS WEBSITE ABOUT?
BreakoutPulse is an institutional-grade swing trading, quantitative screening, paper trading, and strategy validation terminal. It is built to eliminate emotional trading by scanning the stock market for two high-probability setups:
1. **ATH Base Breakouts & 10% Dip-Buying (≤10% to ATH):** Catching market leaders in explosive price discovery as they break out of tight consolidations supported by the dynamic 20 EMA and institutional volume expansion (e.g. CORDEL, TRENT, DIXON, RELIANCE).
   - Aggressive breakout entry: After a strong candle closes above horizontal resistance, enter around the breakout area rather than buying after a huge extension.
   - Dip-buying entry: Adding positions when a quality asset pulls back roughly 10% from its all-time high to 20 EMA support.
   - Structural stop-loss: Placed below the recent higher low / base consolidation structure rather than an arbitrary tight stop immediately below resistance.
2. **ATL Turnarounds (≤10% to ATL):** Capturing deep cyclical mean-reversion reversals using the Stock Momentum Oscillator (14, 3, 3) Hook (< 35 oversold cross) with tight asymmetrical risk/reward and 20 EMA reclaims.

### 🧭 COMPLETE STEP-BY-STEP GUIDE: HOW TO USE THIS WEBSITE
1. **Live Real-Time Market Ticker:** At the very top bar, monitor real-time stock prices (with under 5-second tick delay), distance to ATH, and the overall Market Pulse (Bullish vs Bearish Day Regime).
2. **Interactive Screener & Candlestick Charts (Tab 1):**
   - Filter stocks by preset conditions: All Active Stocks, Nearest to Pivot (≤3%), ATH ≤10%, ATL ≤10%, or Dual Confluence.
   - [D] Delayed Data Indicator: Displays official exchange feed latency (15-min delayed feed from NSE). Clicking/hovering shows the exact delay and timestamp.
   - Candlestick chart includes 20 EMA overlay (dynamic trailing support), horizontal base pivot ceiling, and 1.5x volume expansion threshold.
   - Switch between **1D (Daily)** for swing trading and **1W (Weekly)** for institutional position trading.
3. **Dual Condition Hub (Tab 2):**
   - Confluence scanner that visualizes Category 1 (Base Breakouts) vs Category 2 (Stochastic Momentum) vs Both.
4. **Stock Momentum Screener (Tab 3):**
   - Deep dive into Stochastic (14, 3, 3) %K and %D crossovers, oversold hooks (< 35), and 20 EMA reclaims.
5. **Real-Time Paper Trading Terminal (Tab 4):**
   - Practice trading risk-free with virtual capital.
   - Dynamic Advice Engine: When selecting a stock, evaluates both strategies. If BOTH satisfy, delivers both advice plans side-by-side. If only ONE satisfies, shows only that single advice.
   - Automatically sizes positions by 1-3% portfolio risk using the structural stop-loss.
6. **Strategy Backtester & Autonomous AI Execution Engine (Tab 5):**
   - Allows stress-testing breakout parameters across historical candles.
   - Features the **Autonomous AI Execution Bot** which can execute trades automatically when entry conditions are met.
7. **Custom Watchlists & Real-Time Alerts (Tab 6):**
   - Create custom watchlist folders, star your favorite stocks, and set price/pivot alert triggers with audible chimes.

CRITICAL INSTRUCTION: You are strictly a technical analysis, trading strategy, and platform usage mentor. NEVER mention, expose, or discuss any administrative credentials, passwords, user directories, Master IDs, supervisor alerts, or account administration. If asked about admin or supervisor topics, politely state that you are exclusively a technical trading and strategy mentor.

Provide crisp, structured, professional, and directly actionable guidance. Use bold text, bullet points, and numbered lists where appropriate.`;

    // Check in-memory chat cache first
    const normalizedKey = message.trim().toLowerCase();
    const cachedReply = chatCache.get(normalizedKey);
    if (cachedReply && Date.now() - cachedReply.cachedAt < CHAT_CACHE_TTL_MS) {
      return res.json({ reply: cachedReply.reply });
    }

    const fullPrompt = `${systemInstructions}\n\nUser Question: ${message}`;
    const text = await callGeminiSafely(fullPrompt);

    const reply = text || generateAlgorithmicChatReply(message);
    chatCache.set(normalizedKey, { reply, cachedAt: Date.now() });

    return res.json({ reply });
  } catch (error: any) {
    const fallback = generateAlgorithmicChatReply(req.body?.message || '');
    return res.json({ reply: fallback });
  }
});

function promptOrContents(message: string, history: any[], systemInstructions: string) {
  const prompt = `${systemInstructions}\n\nUser Question: ${message}`;
  return prompt;
}

// In-Memory Direct Message Store for Daksh (Empty by default, no fake/random names)
interface DirectMessageRecord {
  id: string;
  senderName: string;
  senderEmail: string;
  category: string;
  message: string;
  createdAt: string;
  status: 'delivered' | 'saved';
}

const directMessagesForDaksh: DirectMessageRecord[] = [];

// Endpoint: Send direct message to Daksh without user opening Gmail
app.post('/api/send-message-daksh', async (req, res) => {
  try {
    const { name, email, category, message } = req.body;
    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ error: 'Message content is required.' });
    }

    const trimmedName = (name && typeof name === 'string') ? name.trim() : '';
    const trimmedEmail = (email && typeof email === 'string') ? email.trim() : '';

    const newMessage: DirectMessageRecord = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      senderName: trimmedName,
      senderEmail: trimmedEmail,
      category: category || 'General Message',
      message: message.trim(),
      createdAt: new Date().toISOString(),
      status: 'saved',
    };

    directMessagesForDaksh.unshift(newMessage);

    // Forward directly to dakshphosamani@gmail.com via FormSubmit AJAX service
    try {
      const forwardRes = await fetch('https://formsubmit.co/ajax/dakshphosamani@gmail.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          name: newMessage.senderName || 'Sender',
          email: newMessage.senderEmail || 'dakshphosamani@gmail.com',
          _subject: `[BreakoutPulse Direct Message] from ${newMessage.senderName || 'Visitor'} (${newMessage.category})`,
          message: newMessage.message,
          timestamp: newMessage.createdAt,
          _replyto: newMessage.senderEmail || undefined,
          targetEmail: 'dakshphosamani@gmail.com',
        }),
      });

      if (forwardRes.ok) {
        newMessage.status = 'delivered';
      }
    } catch (deliveryErr) {
      console.warn('[DirectMessage] Forwarding error:', deliveryErr);
    }

    return res.json({
      success: true,
      message: 'Message delivered directly to Daksh (dakshphosamani@gmail.com)!',
      data: newMessage,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to send message' });
  }
});

// Endpoint: Master Daksh view all messages sent by individuals
app.get('/api/messages-daksh', (_req, res) => {
  return res.json({
    messages: directMessagesForDaksh,
    count: directMessagesForDaksh.length,
    recipient: 'dakshphosamani@gmail.com',
  });
});

// Endpoint: Master Daksh delete message
app.delete('/api/messages-daksh/:id', (req, res) => {
  const { id } = req.params;
  const index = directMessagesForDaksh.findIndex((m) => m.id === id);
  if (index !== -1) {
    directMessagesForDaksh.splice(index, 1);
    return res.json({ success: true, count: directMessagesForDaksh.length });
  }
  return res.status(404).json({ error: 'Message not found' });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
