export type MarketRegime = 'Bullish Day' | 'Bearish Day' | 'Neutral Day';

export type Timeframe = '1D' | '1W';

export type PatternStatus =
  | 'Breakout Confirmed'
  | 'Base Forming / Near Pivot'
  | 'Testing 20 EMA'
  | 'Consolidating in Base';

export type StochSignalType =
  | 'Bullish Crossover'
  | 'Oversold Hook'
  | 'Momentum Zone'
  | 'Neutral'
  | 'Bearish Cross';

export type StochSetupQuality =
  | 'Prime (Crossover at 20 EMA)'
  | 'Strong Momentum'
  | 'Early Turnaround'
  | 'Extended Breakout';

export interface Candle {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  ema20?: number;
  stochK?: number; // 0-100 Fast %K (14)
  stochD?: number; // 0-100 Slow %D (3 SMA of %K)
  marketRegime?: MarketRegime;
  dataDelayMinutes?: number; // e.g. 15 for 15-minute exchange feed delay
}

export interface Stock {
  id: string;
  symbol: string;
  name: string;
  exchange: 'NSE' | 'BSE' | 'INDEX';
  type: 'stock' | 'index';
  currentPrice: number;
  change: number;
  changePercent: number;
  ath: number;
  distToAth: number; // percentage <= 10%
  atl: number; // All-Time Low price
  distToAtl: number; // percentage from ATL (<= 10% = Near All-Time Low setup)
  baseResistance: number; // Horizontal line from pattern (e.g. 110.00)
  supportEma: number; // 20 EMA
  pattern: string; // e.g. "VCP / High Tight Base Breakout"
  patternConfidence: number; // 0-100%
  patternStatus: PatternStatus;
  volumeRatio: number; // Relative to 20-day avg (e.g. 2.4x)
  avgVolume20: number;
  baseLengthBars: number; // duration of base consolidation
  marketRegime: MarketRegime;
  dailyCandles: Candle[];
  weeklyCandles: Candle[];
  sector?: string;
  description?: string;
  // Stochastic Indicators & Setup Confluence
  stochK: number; // Current %K
  stochD: number; // Current %D
  stochSignal: StochSignalType;
  stochCondition: string; // e.g. "%K (78.4) crossed above %D (71.2) while holding 20 EMA"
  stochQuality: StochSetupQuality;
  isStochAtEmaSupport: boolean;
  // Real Market Data Feed Metadata
  isDelayed?: boolean;
  dataDelayMinutes?: number;
  lastTradeTime?: string;
}

export interface Watchlist {
  id: string;
  name: string;
  symbolIds: string[];
  isDefault?: boolean;
}

export interface AlertRule {
  id: string;
  symbol: string;
  type: 'breakout' | 'near_pivot' | 'ema_support' | 'volume_surge' | 'ath_proximity' | 'stoch_crossover';
  triggerPrice?: number;
  condition: string;
  createdAt: string;
  triggered: boolean;
  triggeredAt?: string;
  message: string;
}

export interface BacktestTrade {
  id: string;
  symbol: string;
  name: string;
  timeframe: Timeframe;
  entryDate: string;
  entryPrice: number;
  stopLoss: number;
  target: number;
  exitDate: string;
  exitPrice: number;
  pnlPercent: number;
  pnlAmount?: number;
  status: 'SUCCESS' | 'FAILED';
  marketRegime: MarketRegime;
  holdingBars: number;
  exitReason: 'Target Hit' | 'Trailing Stop' | 'Stop Loss Hit' | 'Fakeout Breakdown' | 'Fakeout Immediate Cut (❌)';
  patternNotes: string;
  entryType?: 'Aggressive Breakout' | 'ATH 10% Dip-Buy' | 'Dual Confluence' | 'Retest & Bounce';
  patternStage?: 'BREAKOUT_ACTIVE' | 'RETEST_BOUNCE' | 'FAKEOUT_FAILED';
  isAutoExecuted?: boolean;
  stochAtEntry?: {
    k: number;
    d: number;
    signal: string;
  };
}

export interface BacktestStrategyConfig {
  stopLossPercent: number; // e.g. 5%
  targetPercent: number; // e.g. 15%
  volumeMultiplier: number; // e.g. 1.5x
  maxDistToAth: number; // e.g. 10%
  timeframe: Timeframe; // '1D' | '1W'
  marketRegimeFilter: 'ALL' | 'BULLISH_ONLY' | 'NON_BEARISH';
  requireEmaSupport: boolean;
  maxHoldingBars: number;
  requireStochBullish?: boolean; // If true, requires %K >= %D at breakout bar
  stochMaxK?: number; // e.g. 85 (avoid entering hyper-overbought)
  entryApproach?: 'AGGRESSIVE_BREAKOUT' | 'DIP_BUYING_PULLBACK' | 'RETEST_BOUNCE' | 'BOTH';
  useStructuralStopLoss?: boolean;
  fakeoutImmediateCut?: boolean; // Instantly cut trade if price drops back below broken resistance ceiling
  requireRetestBounce?: boolean; // Require explicit pullback & green bounce off broken resistance
}

export interface BacktestMetrics {
  totalTrades: number;
  successfulTrades: number;
  failedTrades: number;
  winRate: number;
  profitFactor: number;
  netPnlPercent: number;
  maxDrawdown: number;
  avgWinPercent: number;
  avgLossPercent: number;
  bullishDayWinRate: number;
  bearishDayWinRate: number;
  neutralDayWinRate: number;
  bullishTradesCount: number;
  bearishTradesCount: number;
  stochConfirmedWinRate?: number;
  equityCurve: { date: string; equity: number }[];
}

export interface AiSetupAnalysis {
  analysis: string;
  confidence: number;
  setupGrade: string;
  keyLevels: {
    resistance: number;
    supportEma: number;
    stopLoss: string;
    target1: string;
    target2: string;
  };
}

export interface UserProfile {
  id: string;
  name: string;
  gmail: string;
  password?: string;
  isMasterAdmin?: boolean;
  isMasterUser?: boolean;
  hasCompletedOnboarding?: boolean;
  experience: 'Beginner' | 'Intermediate' | 'Advanced Swing Trader';
  initialCapital: number;
  riskPerTradePercent: number;
  preferredTimeframe: '1D' | '1W';
  savedAt: string;
  lastActive?: string;
  isBlocked?: boolean;
}

export interface SignupNotification {
  id: string;
  userEmail: string;
  userName: string;
  permanentPassword?: string;
  initialCapital: number;
  experience: string;
  timestamp: string;
  read: boolean;
}

export interface UserActivityItem {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  action: 'LOGIN' | 'PAPER_TRADE_BUY' | 'PAPER_TRADE_SELL' | 'WATCHLIST_ADD' | 'ALERT_CREATED' | 'SCAN_EXECUTED';
  details: string;
  timestamp: string;
  symbol?: string;
  amount?: number;
}

export interface GlobalUserTradeRecord extends PaperTradeRecord {
  userEmail: string;
  userName: string;
  userId: string;
}

export interface PaperPosition {
  id: string;
  symbol: string;
  name: string;
  side: 'BUY' | 'SHORT';
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  stopLoss: number;
  targetPrice: number;
  entryDate: string;
  unrealizedPnl: number;
  unrealizedPnlPercent: number;
  investedAmount: number;
  setupNote?: string;
}

export interface PaperTradeRecord {
  id: string;
  symbol: string;
  name: string;
  side: 'BUY' | 'SHORT';
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  entryDate: string;
  exitDate: string;
  netPnl: number;
  netPnlPercent: number;
  outcome: 'PROFIT' | 'LOSS';
  exitReason: 'Target Reached' | 'Stop Loss Hit' | 'Manual Exit' | 'Trail Stop';
}
