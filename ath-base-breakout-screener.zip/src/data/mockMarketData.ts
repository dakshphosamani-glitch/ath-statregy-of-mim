import { Stock, Candle, MarketRegime, StochSignalType, StochSetupQuality } from '../types';
import { NSE_EXPANDED_DATA, createStockFromNseMeta } from './nseStockUniverse';

// Helper to compute Exponential Moving Average
function calculateEMA(values: number[], period: number = 20): number[] {
  const k = 2 / (period + 1);
  const emaArray: number[] = [];
  let prevEma = values[0];

  for (let i = 0; i < values.length; i++) {
    if (i === 0) {
      emaArray.push(prevEma);
    } else {
      const currentEma = values[i] * k + prevEma * (1 - k);
      emaArray.push(Number(currentEma.toFixed(2)));
      prevEma = currentEma;
    }
  }
  return emaArray;
}

// Helper to compute Stochastic Oscillator (14, 3)
function calculateStoch(
  candles: { high: number; low: number; close: number }[],
  kPeriod: number = 14,
  dPeriod: number = 3
): { kVals: number[]; dVals: number[] } {
  const kVals: number[] = [];
  const dVals: number[] = [];

  for (let i = 0; i < candles.length; i++) {
    const windowStart = Math.max(0, i - kPeriod + 1);
    const windowCandles = candles.slice(windowStart, i + 1);

    const highestHigh = Math.max(...windowCandles.map((c) => c.high));
    const lowestLow = Math.min(...windowCandles.map((c) => c.low));
    const currentClose = candles[i].close;

    let k = 50;
    if (highestHigh > lowestLow) {
      k = ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;
      k = Math.max(0, Math.min(100, k));
    }
    kVals.push(Number(k.toFixed(1)));

    const dWindowStart = Math.max(0, i - dPeriod + 1);
    const dSlice = kVals.slice(dWindowStart, i + 1);
    const dAvg = dSlice.reduce((sum, val) => sum + val, 0) / dSlice.length;
    dVals.push(Number(dAvg.toFixed(1)));
  }

  return { kVals, dVals };
}

// Dynamically align candle dates so the most recent candle corresponds to today's trading session
export function alignCandleDates<T extends { date: string }>(raw: T[]): T[] {
  if (raw.length === 0) return raw;
  const today = new Date();

  const formatDate = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const dates: string[] = [];
  let cur = new Date(today);
  while (dates.length < raw.length) {
    const dayOfWeek = cur.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      dates.unshift(formatDate(cur));
    }
    cur.setDate(cur.getDate() - 1);
  }

  return raw.map((item, idx) => ({
    ...item,
    date: dates[idx] || item.date,
  }));
}

// Generate realistic candles with calculated 20 EMA, Stochastics, and market regimes
function processCandles(
  raw: {
    date: string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    marketRegime?: MarketRegime;
  }[]
): Candle[] {
  const alignedRaw = alignCandleDates(raw);
  const closes = alignedRaw.map((c) => c.close);
  const emas = calculateEMA(closes, 20);
  const { kVals, dVals } = calculateStoch(alignedRaw, 14, 3);

  return alignedRaw.map((c, i) => {
    let regime: MarketRegime = c.marketRegime || 'Neutral Day';
    if (!c.marketRegime) {
      const changePct = ((c.close - c.open) / c.open) * 100;
      if (changePct > 0.4) regime = 'Bullish Day';
      else if (changePct < -0.4) regime = 'Bearish Day';
      else regime = 'Neutral Day';
    }
    return {
      ...c,
      ema20: emas[i],
      stochK: kVals[i],
      stochD: dVals[i],
      marketRegime: regime,
      dataDelayMinutes: 15,
    };
  });
}

// 1. AUROPHARMA (Aurobindo Pharma Limited) - Real NSE Momentum Leader strictly at ATH
const auropharmaDailyRaw = [
  { date: '2026-08-28', open: 1612.0, high: 1635.0, low: 1604.0, close: 1622.0, volume: 680000, marketRegime: 'Neutral Day' as MarketRegime },
  { date: '2026-08-29', open: 1622.0, high: 1640.0, low: 1615.0, close: 1630.0, volume: 720000, marketRegime: 'Neutral Day' as MarketRegime },
  { date: '2026-09-01', open: 1630.0, high: 1645.0, low: 1620.0, close: 1638.0, volume: 750000, marketRegime: 'Bullish Day' as MarketRegime },
  { date: '2026-09-02', open: 1638.0, high: 1650.0, low: 1628.0, close: 1642.0, volume: 810000, marketRegime: 'Neutral Day' as MarketRegime },
  { date: '2026-09-03', open: 1656.1, high: 1666.6, low: 1626.6, close: 1637.3, volume: 920206, marketRegime: 'Neutral Day' as MarketRegime },
  { date: '2026-09-04', open: 1637.3, high: 1661.5, low: 1622.6, close: 1653.1, volume: 573938, marketRegime: 'Bullish Day' as MarketRegime },
  { date: '2026-09-07', open: 1646.0, high: 1668.0, low: 1646.0, close: 1660.0, volume: 536717, marketRegime: 'Bullish Day' as MarketRegime },
  { date: '2026-09-08', open: 1660.5, high: 1698.8, low: 1655.0, close: 1692.0, volume: 1055813, marketRegime: 'Bullish Day' as MarketRegime },
  { date: '2026-09-09', open: 1685.0, high: 1704.0, low: 1672.0, close: 1698.9, volume: 600583, marketRegime: 'Bullish Day' as MarketRegime },
  { date: '2026-09-10', open: 1693.4, high: 1693.4, low: 1655.0, close: 1668.4, volume: 798368, marketRegime: 'Bearish Day' as MarketRegime },
  { date: '2026-09-11', open: 1666.7, high: 1681.4, low: 1655.5, close: 1679.8, volume: 494251, marketRegime: 'Bullish Day' as MarketRegime },
  { date: '2026-09-14', open: 1679.8, high: 1679.8, low: 1679.8, close: 1679.8, volume: 100000, marketRegime: 'Neutral Day' as MarketRegime },
  { date: '2026-09-15', open: 1688.0, high: 1688.0, low: 1642.1, close: 1660.0, volume: 438757, marketRegime: 'Bearish Day' as MarketRegime },
  { date: '2026-09-16', open: 1657.1, high: 1657.1, low: 1623.0, close: 1643.0, volume: 522849, marketRegime: 'Bearish Day' as MarketRegime },
  { date: '2026-09-17', open: 1634.0, high: 1692.3, low: 1634.0, close: 1690.0, volume: 758827, marketRegime: 'Bullish Day' as MarketRegime },
  { date: '2026-09-18', open: 1683.2, high: 1734.0, low: 1676.1, close: 1734.0, volume: 1209478, marketRegime: 'Bullish Day' as MarketRegime },
  { date: '2026-09-21', open: 1709.8, high: 1738.9, low: 1706.4, close: 1713.4, volume: 902487, marketRegime: 'Neutral Day' as MarketRegime },
  { date: '2026-09-22', open: 1718.3, high: 1719.0, low: 1689.3, close: 1700.0, volume: 869831, marketRegime: 'Neutral Day' as MarketRegime },
  { date: '2026-09-23', open: 1700.0, high: 1724.7, low: 1692.6, close: 1721.5, volume: 1350000, marketRegime: 'Bullish Day' as MarketRegime },
];

const auropharmaWeeklyRaw = [
  { date: '2026-08-03', open: 1540.0, high: 1590.0, low: 1520.0, close: 1575.0, volume: 3800000 },
  { date: '2026-08-10', open: 1575.0, high: 1620.0, low: 1560.0, close: 1605.0, volume: 4200000 },
  { date: '2026-08-17', open: 1605.0, high: 1640.0, low: 1590.0, close: 1625.0, volume: 4600000 },
  { date: '2026-08-24', open: 1625.0, high: 1660.0, low: 1610.0, close: 1640.0, volume: 4100000 },
  { date: '2026-08-31', open: 1640.0, high: 1698.8, low: 1622.6, close: 1692.0, volume: 5400000 },
  { date: '2026-09-07', open: 1685.0, high: 1704.0, low: 1642.1, close: 1679.8, volume: 4900000 },
  { date: '2026-09-14', open: 1657.1, high: 1738.9, low: 1623.0, close: 1721.5, volume: 6800000 },
];

// Base raw stock items
const RAW_INITIAL_STOCKS = [
  {
    id: 'auropharma',
    symbol: 'AUROPHARMA',
    name: 'Aurobindo Pharma Limited',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 1721.50,
    change: 187.30,
    changePercent: 12.21,
    ath: 1738.90,
    distToAth: 1.00, // 1.00% below ATH (Strictly <= 10%)
    atl: 480.00,
    distToAtl: 258.65,
    baseResistance: 1704.00, // exact horizontal pivot
    supportEma: 1685.00, // 20 EMA
    pattern: 'High Tight Base Breakout (20 EMA Support)',
    patternConfidence: 98,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 2.45,
    avgVolume20: 820000,
    baseLengthBars: 12,
    marketRegime: 'Bullish Day',
    sector: 'Pharmaceuticals & Healthcare',
    description: 'Nifty 100 pharma heavyweight breaking out directly at All-Time Highs (₹1,738.90), riding its dynamic 20 EMA with aggressive institutional volume accumulation.',
    dailyCandles: processCandles(auropharmaDailyRaw),
    weeklyCandles: processCandles(auropharmaWeeklyRaw),
    stochK: 82.5,
    stochD: 74.0,
    stochSignal: 'Bullish Crossover' as StochSignalType,
    stochCondition: 'Golden Stochastic Crossover confirmed right at 20 EMA cushion into fresh ATH breakout',
    stochQuality: 'Prime (Crossover at 20 EMA)' as StochSetupQuality,
    isStochAtEmaSupport: true,
  },
  {
    id: 'tcs',
    symbol: 'TCS',
    name: 'Tata Consultancy Services Limited',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 4280.0,
    change: 74.0,
    changePercent: 1.76,
    ath: 4500.0,
    distToAth: 4.89,
    atl: 2950.0,
    distToAtl: 45.08,
    baseResistance: 4220.0,
    supportEma: 4160.0,
    pattern: 'Multi-Week Cup & Handle Base',
    patternConfidence: 93,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 1.95,
    avgVolume20: 2800000,
    baseLengthBars: 11,
    marketRegime: 'Bullish Day',
    sector: 'Information Technology',
    description: 'IT bellwether clearing key 4,220 pivot line with solid institutional accumulation across large cap tech.',
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 4050, high: 4110, low: 4030, close: 4095, volume: 2200000 },
      { date: '2026-08-19', open: 4100, high: 4145, low: 4085, close: 4130, volume: 2600000 },
      { date: '2026-08-20', open: 4135, high: 4175, low: 4120, close: 4160, volume: 2900000 },
      { date: '2026-08-21', open: 4162, high: 4180, low: 4140, close: 4155, volume: 2100000 },
      { date: '2026-08-22', open: 4150, high: 4165, low: 4125, close: 4140, volume: 1850000 },
      { date: '2026-08-25', open: 4135, high: 4155, low: 4120, close: 4132, volume: 1750000 },
      { date: '2026-08-26', open: 4130, high: 4160, low: 4122, close: 4148, volume: 1950000 },
      { date: '2026-08-27', open: 4150, high: 4175, low: 4138, close: 4165, volume: 2250000 },
      { date: '2026-08-28', open: 4168, high: 4190, low: 4155, close: 4180, volume: 2450000 },
      { date: '2026-08-29', open: 4182, high: 4205, low: 4170, close: 4195, volume: 2650000 },
      { date: '2026-09-01', open: 4196, high: 4200, low: 4168, close: 4175, volume: 1950000 },
      { date: '2026-09-02', open: 4172, high: 4210, low: 4165, close: 4202, volume: 2500000 },
      { date: '2026-09-03', open: 4210, high: 4305, low: 4200, close: 4280, volume: 5460000, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 3950, high: 4060, low: 3920, close: 4040, volume: 10500000 },
      { date: '2026-08-10', open: 4045, high: 4120, low: 4010, close: 4090, volume: 11800000 },
      { date: '2026-08-17', open: 4095, high: 4180, low: 4060, close: 4155, volume: 13200000 },
      { date: '2026-08-24', open: 4150, high: 4205, low: 4120, close: 4195, volume: 11400000 },
      { date: '2026-08-31', open: 4196, high: 4305, low: 4168, close: 4280, volume: 16200000 },
    ]),
  },
  {
    id: 'trent',
    symbol: 'TRENT',
    name: 'Trent Limited (Tata Retail)',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 7780.0,
    change: 145.0,
    changePercent: 1.90,
    ath: 7920.0,
    distToAth: 1.76,
    baseResistance: 7680.0,
    supportEma: 7450.0,
    pattern: 'Ascending High Base Breakout',
    patternConfidence: 96,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 2.15,
    avgVolume20: 820000,
    baseLengthBars: 12,
    marketRegime: 'Bullish Day',
    sector: 'Retail & Fashion (Zudio / Westside)',
    description: 'Market leader in consumer retail exhibiting textbook volatility contraction base above 20 EMA, breaking to multi-month highs.',
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 7100, high: 7350, low: 7050, close: 7320, volume: 850000 },
      { date: '2026-08-19', open: 7330, high: 7520, low: 7280, close: 7480, volume: 1100000 },
      { date: '2026-08-20', open: 7500, high: 7680, low: 7420, close: 7650, volume: 1250000 },
      { date: '2026-08-21', open: 7660, high: 7700, low: 7540, close: 7620, volume: 890000 },
      { date: '2026-08-22', open: 7610, high: 7660, low: 7480, close: 7520, volume: 720000 },
      { date: '2026-08-25', open: 7530, high: 7600, low: 7440, close: 7490, volume: 680000 },
      { date: '2026-08-26', open: 7490, high: 7580, low: 7460, close: 7550, volume: 640000 },
      { date: '2026-08-27', open: 7560, high: 7640, low: 7510, close: 7610, volume: 780000 },
      { date: '2026-08-28', open: 7620, high: 7680, low: 7560, close: 7660, volume: 890000 },
      { date: '2026-08-29', open: 7670, high: 7710, low: 7620, close: 7680, volume: 950000 },
      { date: '2026-09-01', open: 7680, high: 7700, low: 7590, close: 7640, volume: 710000 },
      { date: '2026-09-02', open: 7650, high: 7720, low: 7610, close: 7690, volume: 920000 },
      { date: '2026-09-03', open: 7700, high: 7850, low: 7680, close: 7780, volume: 1760000, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 6850, high: 7150, low: 6780, close: 7080, volume: 3800000 },
      { date: '2026-08-10', open: 7090, high: 7420, low: 7020, close: 7360, volume: 4400000 },
      { date: '2026-08-17', open: 7370, high: 7700, low: 7280, close: 7620, volume: 5100000 },
      { date: '2026-08-24', open: 7610, high: 7710, low: 7440, close: 7680, volume: 3900000 },
      { date: '2026-08-31', open: 7680, high: 7850, low: 7590, close: 7780, volume: 5600000 },
    ]),
  },
  {
    id: 'dixon',
    symbol: 'DIXON',
    name: 'Dixon Technologies (India) Ltd',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 15480.0,
    change: 380.0,
    changePercent: 2.52,
    ath: 15950.0,
    distToAth: 2.95,
    baseResistance: 15200.0,
    supportEma: 14750.0,
    pattern: 'VCP High Base Breakout',
    patternConfidence: 95,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 2.40,
    avgVolume20: 340000,
    baseLengthBars: 10,
    marketRegime: 'Bullish Day',
    sector: 'Electronic Manufacturing Services',
    description: 'Leading EMS player in smartphones and home appliances, breaking out of a 10-day base at 15,200 with 2.4x volume surge.',
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 14100, high: 14600, low: 13950, close: 14520, volume: 310000 },
      { date: '2026-08-19', open: 14550, high: 14950, low: 14400, close: 14880, volume: 420000 },
      { date: '2026-08-20', open: 14900, high: 15220, low: 14780, close: 15150, volume: 480000 },
      { date: '2026-08-21', open: 15160, high: 15250, low: 14900, close: 15080, volume: 350000 },
      { date: '2026-08-22', open: 15060, high: 15150, low: 14800, close: 14920, volume: 290000 },
      { date: '2026-08-25', open: 14900, high: 15050, low: 14720, close: 14850, volume: 270000 },
      { date: '2026-08-26', open: 14860, high: 15080, low: 14800, close: 15010, volume: 280000 },
      { date: '2026-08-27', open: 15020, high: 15180, low: 14950, close: 15120, volume: 330000 },
      { date: '2026-08-28', open: 15130, high: 15220, low: 15020, close: 15180, volume: 360000 },
      { date: '2026-08-29', open: 15190, high: 15260, low: 15100, close: 15210, volume: 390000 },
      { date: '2026-09-01', open: 15220, high: 15240, low: 15050, close: 15140, volume: 295000 },
      { date: '2026-09-02', open: 15150, high: 15280, low: 15100, close: 15230, volume: 380000 },
      { date: '2026-09-03', open: 15250, high: 15600, low: 15200, close: 15480, volume: 816000, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 13600, high: 14250, low: 13400, close: 14120, volume: 1450000 },
      { date: '2026-08-10', open: 14150, high: 14800, low: 13950, close: 14650, volume: 1680000 },
      { date: '2026-08-17', open: 14660, high: 15250, low: 14400, close: 15080, volume: 1950000 },
      { date: '2026-08-24', open: 15060, high: 15260, low: 14720, close: 15210, volume: 1620000 },
      { date: '2026-08-31', open: 15220, high: 15600, low: 15050, close: 15480, volume: 2450000 },
    ]),
  },
  {
    id: 'hal',
    symbol: 'HAL',
    name: 'Hindustan Aeronautics Limited',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 5210.0,
    change: 112.0,
    changePercent: 2.20,
    ath: 5490.0,
    distToAth: 5.10,
    baseResistance: 5120.0,
    supportEma: 4940.0,
    pattern: 'Ascending Triangle / 20 EMA Ride',
    patternConfidence: 91,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 2.10,
    avgVolume20: 1950000,
    baseLengthBars: 14,
    marketRegime: 'Bullish Day',
    sector: 'Defense & Aerospace',
    description: 'Defense powerhouse clearing 5,120 horizontal resistance ceiling, having bounced 4 consecutive times off the rising 20 EMA.',
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 4750, high: 4920, low: 4710, close: 4890, volume: 1850000 },
      { date: '2026-08-19', open: 4900, high: 5060, low: 4860, close: 5020, volume: 2250000 },
      { date: '2026-08-20', open: 5030, high: 5140, low: 4980, close: 5110, volume: 2600000 },
      { date: '2026-08-21', open: 5120, high: 5150, low: 5020, close: 5060, volume: 1950000 },
      { date: '2026-08-22', open: 5050, high: 5100, low: 4950, close: 4980, volume: 1600000 },
      { date: '2026-08-25', open: 4970, high: 5040, low: 4920, close: 4960, volume: 1520000 },
      { date: '2026-08-26', open: 4960, high: 5060, low: 4940, close: 5020, volume: 1710000 },
      { date: '2026-08-27', open: 5030, high: 5110, low: 4980, close: 5080, volume: 1890000 },
      { date: '2026-08-28', open: 5090, high: 5130, low: 5040, close: 5110, volume: 2010000 },
      { date: '2026-08-29', open: 5120, high: 5140, low: 5060, close: 5100, volume: 1980000 },
      { date: '2026-09-01', open: 5100, high: 5120, low: 5010, close: 5050, volume: 1620000 },
      { date: '2026-09-02', open: 5060, high: 5130, low: 5040, close: 5110, volume: 2100000 },
      { date: '2026-09-03', open: 5120, high: 5260, low: 5100, close: 5210, volume: 4095000, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 4600, high: 4820, low: 4550, close: 4780, volume: 7800000 },
      { date: '2026-08-10', open: 4790, high: 5080, low: 4720, close: 5010, volume: 8900000 },
      { date: '2026-08-17', open: 5020, high: 5150, low: 4950, close: 5060, volume: 9600000 },
      { date: '2026-08-24', open: 5050, high: 5140, low: 4920, close: 5100, volume: 8400000 },
      { date: '2026-08-31', open: 5100, high: 5260, low: 5010, close: 5210, volume: 11800000 },
    ]),
  },
  {
    id: 'bhartiartl',
    symbol: 'BHARTIARTL',
    name: 'Bharti Airtel Limited',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 1752.0,
    change: 28.5,
    changePercent: 1.65,
    ath: 1765.0,
    distToAth: 0.74,
    baseResistance: 1735.0,
    supportEma: 1690.0,
    pattern: 'Flat Base Near ATH',
    patternConfidence: 93,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 1.88,
    avgVolume20: 4200000,
    baseLengthBars: 15,
    marketRegime: 'Bullish Day',
    sector: 'Telecommunications',
    description: 'India telecom giant completing a 3-week flat base just 0.7% under its all-time high, riding its 20 EMA cleanly.',
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 1650, high: 1690, low: 1640, close: 1682, volume: 3800000 },
      { date: '2026-08-19', open: 1685, high: 1720, low: 1675, close: 1712, volume: 4400000 },
      { date: '2026-08-20', open: 1715, high: 1740, low: 1700, close: 1732, volume: 4900000 },
      { date: '2026-08-21', open: 1734, high: 1738, low: 1718, close: 1728, volume: 3900000 },
      { date: '2026-08-22', open: 1726, high: 1735, low: 1710, close: 1718, volume: 3400000 },
      { date: '2026-08-25', open: 1716, high: 1730, low: 1705, close: 1712, volume: 3200000 },
      { date: '2026-08-26', open: 1714, high: 1728, low: 1708, close: 1722, volume: 3500000 },
      { date: '2026-08-27', open: 1724, high: 1736, low: 1718, close: 1730, volume: 3950000 },
      { date: '2026-08-28', open: 1732, high: 1738, low: 1724, close: 1734, volume: 4100000 },
      { date: '2026-08-29', open: 1735, high: 1742, low: 1728, close: 1735, volume: 4300000 },
      { date: '2026-09-01', open: 1736, high: 1739, low: 1722, close: 1726, volume: 3500000 },
      { date: '2026-09-02', open: 1728, high: 1738, low: 1724, close: 1734, volume: 4200000 },
      { date: '2026-09-03', open: 1736, high: 1760, low: 1732, close: 1752, volume: 7896000, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 1580, high: 1640, low: 1560, close: 1625, volume: 18000000 },
      { date: '2026-08-10', open: 1630, high: 1700, low: 1615, close: 1680, volume: 21000000 },
      { date: '2026-08-17', open: 1682, high: 1740, low: 1670, close: 1728, volume: 23500000 },
      { date: '2026-08-24', open: 1726, high: 1742, low: 1705, close: 1735, volume: 19800000 },
      { date: '2026-08-31', open: 1736, high: 1760, low: 1722, close: 1752, volume: 27500000 },
    ]),
  },
  {
    id: 'reliance',
    symbol: 'RELIANCE',
    name: 'Reliance Industries Limited',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 3095.0,
    change: 18.0,
    changePercent: 0.58,
    ath: 3217.0,
    distToAth: 3.79,
    baseResistance: 3120.0,
    supportEma: 3040.0,
    pattern: 'Base Coiling Under Pivot',
    patternConfidence: 89,
    patternStatus: 'Base Forming / Near Pivot',
    volumeRatio: 1.25,
    avgVolume20: 5500000,
    baseLengthBars: 18,
    marketRegime: 'Neutral Day',
    sector: 'Conglomerate / Energy & Retail',
    description: 'India most valued company tightening inside a high consolidation bracket, testing the 3,120 pivot level.',
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 2980, high: 3040, low: 2960, close: 3025, volume: 5100000 },
      { date: '2026-08-19', open: 3030, high: 3080, low: 3010, close: 3065, volume: 5800000 },
      { date: '2026-08-20', open: 3070, high: 3110, low: 3050, close: 3095, volume: 6200000 },
      { date: '2026-08-21', open: 3100, high: 3125, low: 3075, close: 3090, volume: 5300000 },
      { date: '2026-08-22', open: 3085, high: 3105, low: 3060, close: 3075, volume: 4600000 },
      { date: '2026-08-25', open: 3070, high: 3090, low: 3045, close: 3060, volume: 4400000 },
      { date: '2026-08-26', open: 3065, high: 3085, low: 3050, close: 3078, volume: 4800000 },
      { date: '2026-08-27', open: 3080, high: 3105, low: 3065, close: 3090, volume: 5100000 },
      { date: '2026-08-28', open: 3092, high: 3115, low: 3078, close: 3098, volume: 5400000 },
      { date: '2026-08-29', open: 3100, high: 3120, low: 3085, close: 3105, volume: 5600000 },
      { date: '2026-09-01', open: 3102, high: 3115, low: 3070, close: 3080, volume: 4700000 },
      { date: '2026-09-02', open: 3082, high: 3100, low: 3075, close: 3092, volume: 5200000 },
      { date: '2026-09-03', open: 3095, high: 3118, low: 3085, close: 3095, volume: 6875000, marketRegime: 'Neutral Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 2890, high: 2980, low: 2850, close: 2960, volume: 24000000 },
      { date: '2026-08-10', open: 2965, high: 3050, low: 2940, close: 3020, volume: 27000000 },
      { date: '2026-08-17', open: 3025, high: 3125, low: 3010, close: 3090, volume: 29500000 },
      { date: '2026-08-24', open: 3085, high: 3120, low: 3045, close: 3105, volume: 26000000 },
      { date: '2026-08-31', open: 3102, high: 3120, low: 3070, close: 3095, volume: 28500000 },
    ]),
  },
  {
    id: 'lt',
    symbol: 'LT',
    name: 'Larsen & Toubro Limited',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 3680.0,
    change: 48.5,
    changePercent: 1.33,
    ath: 3960.0,
    distToAth: 7.07,
    atl: 1200.0,
    distToAtl: 206.6,
    baseResistance: 3650.0,
    supportEma: 3580.0,
    pattern: 'Ascending Base Breakout (20 EMA Support)',
    patternConfidence: 94,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 2.15,
    avgVolume20: 2800000,
    baseLengthBars: 14,
    marketRegime: 'Bullish Day',
    sector: 'Infrastructure & Engineering',
    description: 'India largest engineering conglomerate breaking out above ₹3,650 resistance with 20 EMA cushion and capital expenditure tailwinds.',
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 3520.0, high: 3560.0, low: 3505.0, close: 3545.0, volume: 2200000 },
      { date: '2026-08-19', open: 3550.0, high: 3585.0, low: 3530.0, close: 3570.0, volume: 2400000 },
      { date: '2026-08-20', open: 3570.0, high: 3610.0, low: 3555.0, close: 3595.0, volume: 2900000 },
      { date: '2026-08-21', open: 3600.0, high: 3630.0, low: 3580.0, close: 3615.0, volume: 2600000 },
      { date: '2026-08-22', open: 3615.0, high: 3640.0, low: 3590.0, close: 3625.0, volume: 2300000 },
      { date: '2026-08-25', open: 3620.0, high: 3650.0, low: 3600.0, close: 3635.0, volume: 2500000 },
      { date: '2026-08-26', open: 3630.0, high: 3655.0, low: 3610.0, close: 3640.0, volume: 2700000 },
      { date: '2026-08-27', open: 3640.0, high: 3660.0, low: 3620.0, close: 3645.0, volume: 2800000 },
      { date: '2026-08-28', open: 3645.0, high: 3655.0, low: 3630.0, close: 3648.0, volume: 2600000 },
      { date: '2026-08-29', open: 3650.0, high: 3665.0, low: 3635.0, close: 3652.0, volume: 2900000 },
      { date: '2026-09-01', open: 3655.0, high: 3670.0, low: 3640.0, close: 3658.0, volume: 3100000 },
      { date: '2026-09-02', open: 3660.0, high: 3685.0, low: 3645.0, close: 3670.0, volume: 3500000 },
      { date: '2026-09-03', open: 3670.0, high: 3705.0, low: 3655.0, close: 3680.0, volume: 6020000, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 3450.0, high: 3530.0, low: 3420.0, close: 3510.0, volume: 11000000 },
      { date: '2026-08-10', open: 3515.0, high: 3590.0, low: 3490.0, close: 3565.0, volume: 12500000 },
      { date: '2026-08-17', open: 3570.0, high: 3645.0, low: 3540.0, close: 3620.0, volume: 14000000 },
      { date: '2026-08-24', open: 3625.0, high: 3665.0, low: 3590.0, close: 3645.0, volume: 13200000 },
      { date: '2026-08-31', open: 3650.0, high: 3705.0, low: 3635.0, close: 3680.0, volume: 18500000 },
    ]),
  },
  {
    id: 'suzlon',
    symbol: 'SUZLON',
    name: 'Suzlon Energy Limited',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 78.40,
    change: 2.90,
    changePercent: 3.84,
    ath: 86.00,
    distToAth: 8.84,
    atl: 6.80,
    distToAtl: 1052.94,
    baseResistance: 76.50,
    supportEma: 73.20,
    pattern: 'Multi-Year Turnaround High Base',
    patternConfidence: 94,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 2.85,
    avgVolume20: 75000000,
    baseLengthBars: 14,
    marketRegime: 'Bullish Day',
    sector: 'Renewable & Green Energy',
    description: 'Renewable energy turnaround powerhouse breaking above its ₹76.50 base ceiling, holding firmly above its 20 EMA.',
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 68.5, high: 71.2, low: 67.8, close: 70.4, volume: 58000000 },
      { date: '2026-08-19', open: 70.8, high: 73.5, low: 70.2, close: 72.8, volume: 64000000 },
      { date: '2026-08-20', open: 73.2, high: 75.8, low: 72.6, close: 74.9, volume: 72000000 },
      { date: '2026-08-21', open: 75.2, high: 76.2, low: 73.8, close: 74.5, volume: 56000000 },
      { date: '2026-08-22', open: 74.2, high: 75.4, low: 73.0, close: 73.8, volume: 49000000 },
      { date: '2026-08-25', open: 73.5, high: 74.8, low: 72.8, close: 73.4, volume: 45000000 },
      { date: '2026-08-26', open: 73.2, high: 75.0, low: 72.9, close: 74.2, volume: 51000000 },
      { date: '2026-08-27', open: 74.5, high: 75.8, low: 73.8, close: 75.1, volume: 59000000 },
      { date: '2026-08-28', open: 75.2, high: 76.5, low: 74.6, close: 75.8, volume: 68000000 },
      { date: '2026-08-29', open: 76.0, high: 76.8, low: 75.2, close: 76.2, volume: 71000000 },
      { date: '2026-09-01', open: 76.4, high: 76.6, low: 74.8, close: 75.5, volume: 54000000 },
      { date: '2026-09-02', open: 75.2, high: 76.8, low: 75.0, close: 76.4, volume: 69000000 },
      { date: '2026-09-03', open: 76.8, high: 79.5, low: 76.2, close: 78.4, volume: 168000000, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 62.0, high: 67.5, low: 61.2, close: 66.8, volume: 280000000 },
      { date: '2026-08-10', open: 67.0, high: 72.4, low: 66.2, close: 71.0, volume: 320000000 },
      { date: '2026-08-17', open: 71.2, high: 76.2, low: 69.8, close: 74.5, volume: 380000000 },
      { date: '2026-08-24', open: 74.0, high: 76.8, low: 72.8, close: 76.2, volume: 295000000 },
      { date: '2026-08-31', open: 76.4, high: 79.5, low: 74.8, close: 78.4, volume: 460000000 },
    ]),
  },
  {
    id: 'kalyankjil',
    symbol: 'KALYANKJIL',
    name: 'Kalyan Jewellers India Limited',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 764.50,
    change: 18.20,
    changePercent: 2.44,
    ath: 785.00,
    distToAth: 2.61, // <= 10% to ATH
    baseResistance: 755.00,
    supportEma: 738.00,
    pattern: 'Stoch Oversold Hook at 20 EMA',
    patternConfidence: 95,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 2.30,
    avgVolume20: 3850000,
    baseLengthBars: 9,
    marketRegime: 'Bullish Day',
    sector: 'Consumer Discretionary / Jewellery',
    description: 'Jewellery retail leader showing textbook Stochastic oversold hook (%K hooked up from 28 to 58) precisely at the rising 20 EMA dynamic support, breaking above 755 pivot.',
    stochK: 64.2,
    stochD: 52.8,
    stochSignal: 'Oversold Hook' as StochSignalType,
    stochCondition: 'Stochastic %K surged out of oversold (<30) zone right off the 20 EMA support',
    stochQuality: 'Prime (Crossover at 20 EMA)' as StochSetupQuality,
    isStochAtEmaSupport: true,
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 710, high: 730, low: 705, close: 728, volume: 3200000 },
      { date: '2026-08-19', open: 728, high: 748, low: 724, close: 744, volume: 3600000 },
      { date: '2026-08-20', open: 745, high: 755, low: 738, close: 752, volume: 4100000 },
      { date: '2026-08-21', open: 752, high: 756, low: 742, close: 748, volume: 3100000 },
      { date: '2026-08-22', open: 746, high: 750, low: 736, close: 740, volume: 2800000 },
      { date: '2026-08-25', open: 738, high: 744, low: 734, close: 736, volume: 2500000 },
      { date: '2026-08-26', open: 735, high: 742, low: 732, close: 739, volume: 2700000 },
      { date: '2026-08-27', open: 740, high: 748, low: 736, close: 745, volume: 3300000 },
      { date: '2026-08-28', open: 746, high: 752, low: 742, close: 749, volume: 3600000 },
      { date: '2026-08-29', open: 749, high: 754, low: 745, close: 751, volume: 3800000 },
      { date: '2026-09-01', open: 750, high: 753, low: 744, close: 747, volume: 2900000 },
      { date: '2026-09-02', open: 746, high: 754, low: 745, close: 752, volume: 3700000 },
      { date: '2026-09-03', open: 753, high: 772, low: 750, close: 764.5, volume: 8855000, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 660, high: 705, low: 650, close: 695, volume: 14500000 },
      { date: '2026-08-10', open: 696, high: 735, low: 690, close: 726, volume: 16800000 },
      { date: '2026-08-17', open: 728, high: 756, low: 722, close: 748, volume: 18200000 },
      { date: '2026-08-24', open: 746, high: 754, low: 732, close: 751, volume: 15400000 },
      { date: '2026-08-31', open: 750, high: 772, low: 744, close: 764.5, volume: 21500000 },
    ]),
  },
  {
    id: 'cdsl',
    symbol: 'CDSL',
    name: 'Central Depository Services (India) Ltd',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 1620.00,
    change: 34.00,
    changePercent: 2.14,
    ath: 1680.00,
    distToAth: 3.57, // <= 10% to ATH
    baseResistance: 1590.00,
    supportEma: 1545.00,
    pattern: 'Ascending Base / Stoch 50 Rebound',
    patternConfidence: 93,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 2.05,
    avgVolume20: 1650000,
    baseLengthBars: 11,
    marketRegime: 'Bullish Day',
    sector: 'Capital Markets Infrastructure',
    description: 'Beneficiary of rapid demat account growth, coiling right under 1,590 pivot with Stochastic 50-line bounce supporting the move.',
    stochK: 71.5,
    stochD: 63.2,
    stochSignal: 'Momentum Zone' as StochSignalType,
    stochCondition: 'Stochastic bounced from 50 midline directly on 20 EMA test',
    stochQuality: 'Strong Momentum' as StochSetupQuality,
    isStochAtEmaSupport: true,
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 1480, high: 1525, low: 1460, close: 1515, volume: 1450000 },
      { date: '2026-08-19', open: 1520, high: 1560, low: 1505, close: 1550, volume: 1850000 },
      { date: '2026-08-20', open: 1555, high: 1595, low: 1535, close: 1580, volume: 2100000 },
      { date: '2026-08-21', open: 1582, high: 1592, low: 1560, close: 1572, volume: 1600000 },
      { date: '2026-08-22', open: 1570, high: 1585, low: 1545, close: 1555, volume: 1350000 },
      { date: '2026-08-25', open: 1550, high: 1565, low: 1538, close: 1548, volume: 1250000 },
      { date: '2026-08-26', open: 1546, high: 1568, low: 1540, close: 1560, volume: 1380000 },
      { date: '2026-08-27', open: 1562, high: 1580, low: 1552, close: 1574, volume: 1520000 },
      { date: '2026-08-28', open: 1575, high: 1588, low: 1565, close: 1580, volume: 1620000 },
      { date: '2026-08-29', open: 1581, high: 1592, low: 1570, close: 1585, volume: 1710000 },
      { date: '2026-09-01', open: 1586, high: 1590, low: 1568, close: 1575, volume: 1420000 },
      { date: '2026-09-02', open: 1574, high: 1590, low: 1570, close: 1584, volume: 1690000 },
      { date: '2026-09-03', open: 1585, high: 1635, low: 1580, close: 1620, volume: 3382500, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 1390, high: 1460, low: 1370, close: 1445, volume: 6800000 },
      { date: '2026-08-10', open: 1450, high: 1530, low: 1435, close: 1510, volume: 7900000 },
      { date: '2026-08-17', open: 1515, high: 1595, low: 1490, close: 1572, volume: 8800000 },
      { date: '2026-08-24', open: 1570, high: 1592, low: 1538, close: 1585, volume: 7200000 },
      { date: '2026-08-31', open: 1586, high: 1635, low: 1568, close: 1620, volume: 10500000 },
    ]),
  },
  {
    id: 'bel',
    symbol: 'BEL',
    name: 'Bharat Electronics Limited',
    exchange: 'NSE',
    type: 'stock',
    currentPrice: 336.50,
    change: 8.10,
    changePercent: 2.47,
    ath: 340.50,
    distToAth: 1.17, // <= 10% to ATH
    baseResistance: 328.00,
    supportEma: 318.00,
    pattern: 'High Tight Base / Stoch Bullish Expansion',
    patternConfidence: 95,
    patternStatus: 'Breakout Confirmed',
    volumeRatio: 2.45,
    avgVolume20: 18500000,
    baseLengthBars: 12,
    marketRegime: 'Bullish Day',
    sector: 'Defense Electronics',
    description: 'Defense radar and electronics giant breaking above 328 pivot just 1.17% from its ATH, supported by strong Stochastic expansion (%K: 86.4).',
    stochK: 87.2,
    stochD: 76.5,
    stochSignal: 'Bullish Crossover' as StochSignalType,
    stochCondition: 'Aggressive Stoch momentum acceleration into breakout with 2.45x volume',
    stochQuality: 'Extended Breakout' as StochSetupQuality,
    isStochAtEmaSupport: true,
    dailyCandles: processCandles([
      { date: '2026-08-18', open: 302, high: 315, low: 299, close: 312, volume: 16500000 },
      { date: '2026-08-19', open: 313, high: 324, low: 310, close: 321, volume: 21000000 },
      { date: '2026-08-20', open: 322, high: 329, low: 318, close: 327, volume: 24000000 },
      { date: '2026-08-21', open: 328, high: 330, low: 322, close: 326, volume: 18000000 },
      { date: '2026-08-22', open: 325, high: 328, low: 320, close: 322, volume: 15000000 },
      { date: '2026-08-25', open: 321, high: 325, low: 318, close: 320, volume: 14000000 },
      { date: '2026-08-26', open: 320, high: 326, low: 319, close: 323, volume: 15500000 },
      { date: '2026-08-27', open: 324, high: 327, low: 321, close: 325, volume: 17000000 },
      { date: '2026-08-28', open: 326, high: 329, low: 323, close: 327, volume: 18500000 },
      { date: '2026-08-29', open: 327, high: 330, low: 325, close: 328, volume: 19000000 },
      { date: '2026-09-01', open: 328, high: 329, low: 323, close: 325, volume: 15000000 },
      { date: '2026-09-02', open: 324, high: 329, low: 324, close: 327, volume: 19500000 },
      { date: '2026-09-03', open: 328, high: 339, low: 327, close: 336.5, volume: 45325000, marketRegime: 'Bullish Day' as MarketRegime },
    ]),
    weeklyCandles: processCandles([
      { date: '2026-08-03', open: 285, high: 304, low: 280, close: 298, volume: 75000000 },
      { date: '2026-08-10', open: 300, high: 318, low: 295, close: 314, volume: 86000000 },
      { date: '2026-08-17', open: 315, high: 330, low: 310, close: 326, volume: 98000000 },
      { date: '2026-08-24', open: 325, high: 330, low: 318, close: 328, volume: 82000000 },
      { date: '2026-08-31', open: 328, high: 339, low: 323, close: 336.5, volume: 124000000 },
    ]),
  },
];

// Helper to guarantee every stock has complete Stochastic & pattern fields
function enrichStockWithStochMetrics(rawStock: any): Stock {
  const candles = rawStock.dailyCandles || [];
  const lastCandle = candles[candles.length - 1];
  const prevCandle = candles[candles.length - 2];
  const k = rawStock.stochK ?? lastCandle?.stochK ?? 75.0;
  const d = rawStock.stochD ?? lastCandle?.stochD ?? 68.0;
  const prevK = prevCandle?.stochK ?? 60.0;
  const prevD = prevCandle?.stochD ?? 62.0;

  const isCross = (prevK <= prevD && k > d) || (k > d && k <= 85);
  let signal: StochSignalType = rawStock.stochSignal;
  let quality: StochSetupQuality = rawStock.stochQuality;
  let cond = rawStock.stochCondition;

  const candleHighs = candles.map((c: any) => c.high || 0);
  const candleLows = candles.map((c: any) => c.low || rawStock.currentPrice);
  const maxCandleHigh = candleHighs.length > 0 ? Math.max(...candleHighs) : rawStock.currentPrice;
  const minCandleLow = candleLows.length > 0 ? Math.min(...candleLows) : rawStock.currentPrice;

  const ath = Math.max(rawStock.ath || 0, maxCandleHigh, rawStock.currentPrice);
  const fallbackAtl = Number((rawStock.currentPrice * 0.42).toFixed(2));
  const baseAtl = rawStock.atl !== undefined ? rawStock.atl : fallbackAtl;
  const atl = Math.min(baseAtl, minCandleLow);

  const distToAth = Math.max(0, Number((((ath - rawStock.currentPrice) / ath) * 100).toFixed(2)));
  const distToAtl = atl > 0 ? Math.max(0, Number((((rawStock.currentPrice - atl) / rawStock.currentPrice) * 100).toFixed(2))) : 0;
  const atEma = rawStock.currentPrice >= rawStock.supportEma * 0.985;

  if (!signal) {
    if (isCross && atEma && distToAth <= 5) {
      signal = 'Bullish Crossover';
      quality = 'Prime (Crossover at 20 EMA)';
      cond = `%K (${k}) crossed above %D (${d}) directly at 20 EMA support near ATH (${distToAth}% to ATH)`;
    } else if (k < 35 && k > d) {
      signal = 'Oversold Hook';
      quality = 'Early Turnaround';
      cond = `Stochastic hooked up from oversold region (%K: ${k}) while holding above 20 EMA`;
    } else if (k >= 50 && k <= 82 && k > d) {
      signal = 'Momentum Zone';
      quality = 'Strong Momentum';
      cond = `Strong momentum expansion in 50-80 zone (%K ${k} > %D ${d}) driving base breakout`;
    } else if (k > 82) {
      signal = 'Bullish Crossover';
      quality = 'Extended Breakout';
      cond = `Overbought momentum expansion (%K: ${k}, %D: ${d}) with volume surge`;
    } else {
      signal = k < d ? 'Bearish Cross' : 'Neutral';
      quality = 'Early Turnaround';
      cond = `Stochastic consolidating (%K: ${k}, %D: ${d}) near 20 EMA base`;
    }
  }

  if (!quality) quality = 'Prime (Crossover at 20 EMA)';
  if (!cond) cond = `%K (${k}) > %D (${d}) confirming 10% strategy momentum`;

  return {
    ...rawStock,
    type: 'stock',
    ath,
    distToAth,
    atl,
    distToAtl,
    stochK: k,
    stochD: d,
    stochSignal: signal,
    stochCondition: cond,
    stochQuality: quality,
    isStochAtEmaSupport: rawStock.isStochAtEmaSupport ?? atEma,
    isDelayed: true,
    dataDelayMinutes: 15,
    lastTradeTime: rawStock.lastTradeTime || '15:30:00 IST (NSE Session Close)',
  };
}

const existingSymbols = new Set(RAW_INITIAL_STOCKS.map((s) => s.symbol));
const additionalStocks: Stock[] = NSE_EXPANDED_DATA
  .filter((item) => !existingSymbols.has(item.symbol))
  .map(createStockFromNseMeta);

const baseStocks: Stock[] = RAW_INITIAL_STOCKS.map(enrichStockWithStochMetrics);

// Only include stocks that have verified real exchange feeds (e.g., ZOMATO, TATAMOTORS, LTIM are removed)
export const UNVERIFIED_SYMBOLS = new Set(['ZOMATO', 'TATAMOTORS', 'LTIM']);

// Filter exclusively for stocks (no indices) and ensure unique stock IDs with verified real-time feeds
const seenStockIds = new Set<string>();
export const INITIAL_STOCKS: Stock[] = [...baseStocks, ...additionalStocks]
  .filter((s) => s.type === 'stock')
  .filter((s) => !UNVERIFIED_SYMBOLS.has(s.symbol.toUpperCase()))
  .filter((s) => {
    if (seenStockIds.has(s.id)) return false;
    seenStockIds.add(s.id);
    return true;
  });

// Candidate database for the 10% ATH Strategy & Momentum Scanner:
// Allows testing and scanning verified stocks in the market
export interface ScanCandidate {
  symbol: string;
  name: string;
  exchange: 'NSE' | 'BSE';
  currentPrice: number;
  ath: number;
  atl?: number;
  baseResistance: number;
  supportEma: number;
  stochK: number;
  stochD: number;
  sector: string;
  category: 'Matches Both (ATH + Stoch)' | 'Near ATH Only' | 'Near ATL Reversal (<10%)' | 'Overextended / Far from ATH' | 'Below 20 EMA';
}

export const MARKET_SCAN_UNIVERSE: ScanCandidate[] = [
  {
    symbol: 'IDEA',
    name: 'Vodafone Idea Limited',
    exchange: 'NSE',
    currentPrice: 7.85,
    ath: 38.5,
    atl: 7.20,
    baseResistance: 8.10,
    supportEma: 7.60,
    stochK: 68.0,
    stochD: 59.0,
    sector: 'Telecom Infrastructure',
    category: 'Near ATL Reversal (<10%)',
  },
  {
    symbol: 'YESBANK',
    name: 'Yes Bank Limited',
    exchange: 'NSE',
    currentPrice: 19.45,
    ath: 82.5,
    atl: 18.20,
    baseResistance: 19.80,
    supportEma: 19.10,
    stochK: 62.4,
    stochD: 54.0,
    sector: 'Private Banking',
    category: 'Near ATL Reversal (<10%)',
  },
  {
    symbol: 'PAYTM',
    name: 'One97 Communications Limited',
    exchange: 'NSE',
    currentPrice: 382.5,
    ath: 1961.0,
    atl: 355.0,
    baseResistance: 395.0,
    supportEma: 374.0,
    stochK: 77.5,
    stochD: 68.2,
    sector: 'Fintech & Digital Payments',
    category: 'Near ATL Reversal (<10%)',
  },
  {
    symbol: 'INFY',
    name: 'Infosys Limited',
    exchange: 'NSE',
    currentPrice: 1910.0,
    ath: 1953.0,
    baseResistance: 1890.0,
    supportEma: 1860.0,
    stochK: 68.4,
    stochD: 61.0,
    sector: 'IT Consulting & Software',
    category: 'Matches Both (ATH + Stoch)',
  },
  {
    symbol: 'ITC',
    name: 'ITC Limited',
    exchange: 'NSE',
    currentPrice: 512.0,
    ath: 520.0,
    baseResistance: 505.0,
    supportEma: 496.0,
    stochK: 79.2,
    stochD: 71.8,
    sector: 'FMCG Conglomerate',
    category: 'Matches Both (ATH + Stoch)',
  },
  {
    symbol: 'HDFCBANK',
    name: 'HDFC Bank Limited',
    exchange: 'NSE',
    currentPrice: 1642.00,
    ath: 1794.00,
    baseResistance: 1660.00,
    supportEma: 1630.00,
    stochK: 81.0,
    stochD: 73.4,
    sector: 'Banking & Financial Services',
    category: 'Matches Both (ATH + Stoch)',
  },
  {
    symbol: 'ICICIBANK',
    name: 'ICICI Bank Limited',
    exchange: 'NSE',
    currentPrice: 1220.00,
    ath: 1258.00,
    baseResistance: 1215.00,
    supportEma: 1195.00,
    stochK: 84.2,
    stochD: 76.0,
    sector: 'Private Banking',
    category: 'Matches Both (ATH + Stoch)',
  },
  {
    symbol: 'SBIN',
    name: 'State Bank of India',
    exchange: 'NSE',
    currentPrice: 792.0,
    ath: 912.0,
    baseResistance: 820.0,
    supportEma: 815.0,
    stochK: 38.0,
    stochD: 44.5,
    sector: 'Public Sector Banking',
    category: 'Overextended / Far from ATH', // 13.1% to ATH (>10%)
  },
  {
    symbol: 'WIPRO',
    name: 'Wipro Limited',
    exchange: 'NSE',
    currentPrice: 525.0,
    ath: 726.0,
    baseResistance: 540.0,
    supportEma: 538.0,
    stochK: 31.0,
    stochD: 36.5,
    sector: 'IT Services',
    category: 'Overextended / Far from ATH', // 27.6% to ATH
  },
  {
    symbol: 'BAJFINANCE',
    name: 'Bajaj Finance Limited',
    exchange: 'NSE',
    currentPrice: 7150.0,
    ath: 8190.0,
    baseResistance: 7300.0,
    supportEma: 7080.0,
    stochK: 65.0,
    stochD: 59.0,
    sector: 'Non-Banking Financials',
    category: 'Overextended / Far from ATH', // 12.7% to ATH
  },
];
