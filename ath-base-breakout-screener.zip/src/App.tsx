import { useState, useEffect, useRef } from 'react';
import { Stock, Timeframe, Watchlist, AlertRule, UserProfile } from './types';
import { INITIAL_STOCKS } from './data/mockMarketData';
import { soundEffects } from './utils/audioAlert';
import Header, { ActiveTabType } from './components/Header';
import TradingChart from './components/TradingChart';
import ScreenerTable from './components/ScreenerTable';
import DualConditionScreener from './components/DualConditionScreener';
import StochScreener from './components/StochScreener';
import PaperTrading from './components/PaperTrading';
import BacktestEngine from './components/BacktestEngine';
import WatchlistsAndAlerts from './components/WatchlistsAndAlerts';
import AiSetupModal from './components/AiSetupModal';
import OnboardingScreen from './components/OnboardingScreen';
import MasterAdminDashboard from './components/MasterAdminDashboard';
import MasterAdminSideColumn from './components/MasterAdminSideColumn';
import MasterIdAdminModal from './components/MasterIdAdminModal';
import AiChatbot from './components/AiChatbot';
import CreatorFooter from './components/CreatorFooter';
import { getBestStrategyStock, rankStocksByStrategy, evaluateStockStrategies } from './utils/strategyRanking';
import { 
  Sparkles, 
  HelpCircle, 
  Layers, 
  CheckCircle2, 
  TrendingUp, 
  X, 
  ExternalLink,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Flame,
  Info,
  ShieldCheck,
  Bot,
  Trophy,
  Lock
} from 'lucide-react';

const INITIAL_WATCHLISTS: Watchlist[] = [
  {
    id: 'radar',
    name: 'My Breakout Radar',
    symbolIds: ['auropharma', 'trent', 'dixon', 'hal', 'kaynes'],
    isDefault: true,
  },
  {
    id: 'atlturnaround',
    name: 'ATL 10% Turnaround Setups',
    symbolIds: ['cdsl', 'zomato', 'mazdock'],
    isDefault: false,
  },
  {
    id: 'largecaps',
    name: 'Mega-Cap Momentum',
    symbolIds: ['reliance', 'bhartiartl', 'lt'],
    isDefault: false,
  },
];

const INITIAL_ALERTS: AlertRule[] = [
  {
    id: 'alert-auro-1',
    symbol: 'AUROPHARMA',
    type: 'breakout',
    triggerPrice: 1704.00,
    condition: 'Price crosses above base horizontal pivot ₹1,704.00 (Resistance Breakout)',
    createdAt: '2026-09-20T10:00:00Z',
    triggered: true,
    triggeredAt: '2026-09-21T09:15:22Z',
    message: 'AUROPHARMA broke out above ₹1,704.00 base resistance to ₹1,721.50 with 1.35M volume!',
  },
  {
    id: 'alert-rel-1',
    symbol: 'RELIANCE',
    type: 'breakout',
    triggerPrice: 3020,
    condition: 'Stock breaks above ₹3,020 base consolidation on 20 EMA',
    createdAt: '2026-09-20T11:30:00Z',
    triggered: true,
    triggeredAt: '2026-09-21T09:20:00Z',
    message: 'RELIANCE confirmed ATH base breakout to ₹3,025!',
  },
  {
    id: 'alert-trent-1',
    symbol: 'TRENT',
    type: 'near_pivot',
    triggerPrice: 7680,
    condition: 'Price enters within 1.5% of ₹7,680 pivot resistance',
    createdAt: '2026-09-21T08:00:00Z',
    triggered: false,
    message: 'TRENT coiling right under pivot resistance',
  },
  {
    id: 'alert-dixon-1',
    symbol: 'DIXON',
    type: 'volume_surge',
    triggerPrice: 15200,
    condition: 'Relative volume exceeds 2.0x on base breakout',
    createdAt: '2026-09-21T08:30:00Z',
    triggered: false,
    message: 'DIXON volume surge on breakout bar',
  },
];

const LOCAL_STORAGE_USER_KEY = 'breakout_screener_user_profile';

export default function App() {
  const [stocks, setStocks] = useState<Stock[]>(INITIAL_STOCKS);
  // Dynamically select the stock that best satisfies the 2 strategies (ATH Breakout vs. ATL Turnaround)
  const [selectedStock, setSelectedStock] = useState<Stock>(() => getBestStrategyStock(INITIAL_STOCKS));
  const hasUserManuallySelectedStockRef = useRef(false);
  const [isFetchingRealData, setIsFetchingRealData] = useState<boolean>(false);
  const [timeframe, setTimeframe] = useState<Timeframe>('1D');
  const [activeTab, setActiveTab] = useState<ActiveTabType>('screener');
  
  // User Profile & Onboarding State
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const [hasOnboarded, setHasOnboarded] = useState<boolean>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return Boolean(parsed?.hasCompletedOnboarding);
      } catch (e) {
        return false;
      }
    }
    return false;
  });

  const [isEditingProfile, setIsEditingProfile] = useState(false);
  
  // Master user detection (dakshphosamani@gmail.com)
  const isMaster = Boolean(
    userProfile?.isMasterUser ||
    userProfile?.gmail?.toLowerCase() === 'dakshphosamani@gmail.com'
  );

  // Watchlists & Alerts state
  const [watchlists, setWatchlists] = useState<Watchlist[]>(INITIAL_WATCHLISTS);
  const [activeWatchlistId, setActiveWatchlistId] = useState<string>('radar');
  const [alerts, setAlerts] = useState<AlertRule[]>(INITIAL_ALERTS);
  const [isSoundEnabled, setIsSoundEnabled] = useState(soundEffects.isEnabled());

  // Modals & Chatbot state
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isStrategyExplainerOpen, setIsStrategyExplainerOpen] = useState(false);
  const [isAiChatbotOpen, setIsAiChatbotOpen] = useState(false);
  const [isIdAdminOpen, setIsIdAdminOpen] = useState(false);

  // User Dropdown Option: Hide all stocks on starting page by default until clicked
  const [isStocksDropdownOpen, setIsStocksDropdownOpen] = useState(false);

  // Active toast banner for recent alert
  const [activeToast, setActiveToast] = useState<string | null>(null);

  const selectedStockRef = useRef<Stock>(selectedStock);
  useEffect(() => {
    selectedStockRef.current = selectedStock;
  }, [selectedStock]);

  // Fetch authentic real market data from Indian exchange / TrueData backend
  const fetchRealStockData = async (sym: string) => {
    setIsFetchingRealData(true);
    try {
      const res = await fetch(`/api/market-quote/${encodeURIComponent(sym)}`);
      if (res.ok) {
        const data = await res.json();
        setStocks((prev) => {
          return prev.map((s) => {
            if (s.symbol.toUpperCase() === sym.toUpperCase()) {
              const newPrice = data.currentPrice || s.currentPrice;
              const newAth = data.ath || s.ath;
              const newAtl = data.atl || s.atl;
              const newDistToAth = Number(Math.max(0, ((newAth - newPrice) / newAth) * 100).toFixed(2));
              const newDistToAtl = newAtl ? Number(Math.max(0, ((newPrice - newAtl) / newPrice) * 100).toFixed(2)) : s.distToAtl;
              const updatedStock = {
                ...s,
                currentPrice: newPrice,
                change: data.change !== undefined ? data.change : s.change,
                changePercent: data.changePercent !== undefined ? data.changePercent : s.changePercent,
                ath: newAth,
                atl: newAtl,
                distToAth: newDistToAth,
                distToAtl: newDistToAtl,
                baseResistance: data.baseResistance || s.baseResistance,
                supportEma: data.supportEma || s.supportEma,
                stochK: data.stochK !== undefined ? data.stochK : s.stochK,
                stochD: data.stochD !== undefined ? data.stochD : s.stochD,
                volumeRatio: data.volumeRatio || s.volumeRatio,
                dailyCandles: data.dailyCandles && data.dailyCandles.length > 0 ? data.dailyCandles : s.dailyCandles,
                weeklyCandles: data.weeklyCandles && data.weeklyCandles.length > 0 ? data.weeklyCandles : s.weeklyCandles,
                lastTradeTime: data.lastTradeTime || s.lastTradeTime,
                isDelayed: true,
                dataDelayMinutes: 15,
                exchange: data.exchange || s.exchange,
              };

              // If this is currently the focused stock, update its data without switching stocks
              if (selectedStockRef.current && selectedStockRef.current.symbol.toUpperCase() === sym.toUpperCase()) {
                setSelectedStock(updatedStock);
              }

              return updatedStock;
            }
            return s;
          });
        });
      }
    } catch {
      // ignore transient network glitch
    } finally {
      setIsFetchingRealData(false);
    }
  };

  // Fetch authentic real delayed quotes periodically (Batch update, no continuous jumping)
  useEffect(() => {
    let isCancelled = false;

    async function syncRealMarketQuotes() {
      try {
        const currentSym = selectedStockRef.current?.symbol;
        if (currentSym) {
          await fetchRealStockData(currentSym);
        }

        const universeSymbols = ['CORDEL', 'TRENT', 'DIXON', 'AUROPHARMA', 'HAL', 'RELIANCE'];
        const quotePromises = universeSymbols.map((sym) =>
          fetch(`/api/market-quote/${encodeURIComponent(sym)}`)
            .then((r) => (r.ok ? r.json() : null))
            .catch(() => null)
        );

        const results = await Promise.allSettled(quotePromises);
        if (isCancelled) return;

        setStocks((prev) => {
          const map = new Map<string, any>();
          for (const res of results) {
            if (res.status === 'fulfilled' && res.value?.symbol) {
              map.set(res.value.symbol.toUpperCase(), res.value);
            }
          }

          return prev.map((s) => {
            const data = map.get(s.symbol.toUpperCase());
            if (!data) return s;
            const newPrice = data.currentPrice || s.currentPrice;
            const newAth = data.ath || s.ath;
            const newAtl = data.atl || s.atl;
            const newDistToAth = Number(Math.max(0, ((newAth - newPrice) / newAth) * 100).toFixed(2));
            const newDistToAtl = newAtl ? Number(Math.max(0, ((newPrice - newAtl) / newPrice) * 100).toFixed(2)) : s.distToAtl;
            return {
              ...s,
              currentPrice: newPrice,
              change: data.change !== undefined ? data.change : s.change,
              changePercent: data.changePercent !== undefined ? data.changePercent : s.changePercent,
              ath: newAth,
              atl: newAtl,
              distToAth: newDistToAth,
              distToAtl: newDistToAtl,
              baseResistance: data.baseResistance || s.baseResistance,
              supportEma: data.supportEma || s.supportEma,
              stochK: data.stochK !== undefined ? data.stochK : s.stochK,
              stochD: data.stochD !== undefined ? data.stochD : s.stochD,
              volumeRatio: data.volumeRatio || s.volumeRatio,
              dailyCandles: data.dailyCandles && data.dailyCandles.length > 0 ? data.dailyCandles : s.dailyCandles,
              weeklyCandles: data.weeklyCandles && data.weeklyCandles.length > 0 ? data.weeklyCandles : s.weeklyCandles,
              isDelayed: true,
              dataDelayMinutes: 15,
              lastTradeTime: data.lastTradeTime || s.lastTradeTime,
            };
          });
        });
      } catch {
        // ignore
      }
    }

    syncRealMarketQuotes();
    const interval = setInterval(syncRealMarketQuotes, 60000);
    return () => {
      isCancelled = true;
      clearInterval(interval);
    };
  }, []);

  // Explicit user selection of a stock (locks onto this stock and immediately fetches real candles)
  const handleSelectStock = (stock: Stock) => {
    hasUserManuallySelectedStockRef.current = true;
    setSelectedStock(stock);
    fetchRealStockData(stock.symbol);
  };

  // Focus only the single stock which satisfies the condition better than every stock in universe
  const handleResetToBestStrategyStock = () => {
    hasUserManuallySelectedStockRef.current = false;
    const ranked = rankStocksByStrategy(stocks);
    const best = ranked[0]?.stock || stocks[0];
    if (best) {
      setSelectedStock(best);
      fetchRealStockData(best.symbol);
      setActiveToast(`Focused on #${best.symbol} — Top #1 Setup Satisfying Conditions Better Than Every Stock`);
      setTimeout(() => setActiveToast(null), 3500);
    }
  };

  // Logout handler
  const handleLogout = () => {
    localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
    setUserProfile(null);
    setHasOnboarded(false);
    setIsEditingProfile(false);
    soundEffects.playAlertChime();
  };

  // Manual 1-click real-time sync handler (Authentic API call without any Math.random)
  const handleForceRealtimeSync = async () => {
    soundEffects.playSuccessSound();
    setActiveToast('Syncing real-time authentic quotes from Indian stock exchange API...');
    
    // Fetch for focused stock and leaders
    await fetchRealStockData(selectedStock.symbol);
    for (const s of stocks.slice(0, 6)) {
      if (s.symbol !== selectedStock.symbol) {
        fetchRealStockData(s.symbol);
      }
    }

    setActiveToast('✓ Real exchange prices & candlestick bars synced (15m delayed live feed)');
    setTimeout(() => setActiveToast(null), 3200);
  };

  // Keep selected stock synchronized with updated prices
  useEffect(() => {
    const updated = stocks.find((s) => s.id === selectedStock.id);
    if (updated) {
      setSelectedStock(updated);
    }
  }, [stocks]);

  // Watchlist helpers
  const handleCreateWatchlist = (name: string) => {
    const newWl: Watchlist = {
      id: `wl-${Date.now()}`,
      name,
      symbolIds: [selectedStock.id],
      isDefault: false,
    };
    setWatchlists([...watchlists, newWl]);
    setActiveWatchlistId(newWl.id);
  };

  const handleDeleteWatchlist = (id: string) => {
    setWatchlists(watchlists.filter((w) => w.id !== id));
    if (activeWatchlistId === id) {
      setActiveWatchlistId(watchlists[0]?.id || '');
    }
  };

  const handleToggleStockInWatchlist = (stockId: string, watchlistId: string) => {
    setWatchlists((prev) =>
      prev.map((wl) => {
        if (wl.id !== watchlistId) return wl;
        const exists = wl.symbolIds.includes(stockId);
        return {
          ...wl,
          symbolIds: exists
            ? wl.symbolIds.filter((id) => id !== stockId)
            : [...wl.symbolIds, stockId],
        };
      })
    );
  };

  const activeWatchlist = watchlists.find((w) => w.id === activeWatchlistId) || watchlists[0];

  // Alert helpers
  const handleCreateAlert = (rule: Omit<AlertRule, 'id' | 'createdAt' | 'triggered'>) => {
    const newAlert: AlertRule = {
      ...rule,
      id: `alert-${Date.now()}`,
      createdAt: new Date().toISOString(),
      triggered: false,
    };
    setAlerts([newAlert, ...alerts]);
    setActiveToast(`New alert rule created for ${rule.symbol}!`);
  };

  const handleDeleteAlert = (id: string) => {
    setAlerts(alerts.filter((a) => a.id !== id));
  };

  const handleTriggerSimulatedAlert = () => {
    soundEffects.playBreakoutFanfare();
    const mockMsg = `⚡ REAL-TIME BREAKOUT: AUROPHARMA surged past ₹1,704.00 resistance with 1.35M volume expansion!`;
    setActiveToast(mockMsg);

    setAlerts((prev) =>
      prev.map((a) => {
        if (a.symbol === 'AUROPHARMA') {
          return {
            ...a,
            triggered: true,
            triggeredAt: new Date().toISOString(),
          };
        }
        return a;
      })
    );
  };

  // 1. Mandatory Gate: First the details filling (Gmail, Name, Capital, Risk, etc.) must come at once!
  // Only once filled does the main dashboard open, meeting the user's explicit directive.
  if (!hasOnboarded || isEditingProfile) {
    return (
      <OnboardingScreen
        initialData={userProfile}
        onCancel={hasOnboarded ? () => setIsEditingProfile(false) : undefined}
        onComplete={(profile) => {
          setUserProfile(profile);
          setHasOnboarded(true);
          setIsEditingProfile(false);
          localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(profile));
          soundEffects.playAlertChime();
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#090d13] text-gray-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Header with Navigation, User Profile, and Market Tickers */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        stocks={stocks}
        alerts={alerts}
        isSimulatingMarket={isFetchingRealData}
        onToggleSimulatingMarket={handleForceRealtimeSync}
        isSoundEnabled={isSoundEnabled}
        onToggleSound={() => {
          const next = !isSoundEnabled;
          setIsSoundEnabled(next);
          soundEffects.setEnabled(next);
        }}
        onSelectStock={handleSelectStock}
        userProfile={userProfile}
        onEditProfile={() => setIsEditingProfile(true)}
        onLogout={handleLogout}
        onOpenAiChatbot={() => setIsAiChatbotOpen(true)}
        onOpenIdAdministration={() => setIsIdAdminOpen(true)}
        onForceSync={handleForceRealtimeSync}
      />

      {/* Real-time Toast Alert Notification */}
      {activeToast && (
        <div className="fixed bottom-5 right-5 z-50 max-w-md bg-[#161b22] border border-emerald-500/50 text-white p-3.5 rounded-xl shadow-2xl flex items-start gap-3 animate-in slide-in-from-bottom duration-300">
          <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 mt-0.5">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div className="flex-1 text-xs">
            <div className="font-bold text-emerald-400">Real-Time Alert Triggered</div>
            <div className="text-gray-300 mt-0.5 leading-relaxed">{activeToast}</div>
          </div>
          <button
            onClick={() => setActiveToast(null)}
            className="text-gray-500 hover:text-white p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Dynamic Strategy Blueprint Banner: Only the stock satisfying conditions better than every stock */}
      <div className="bg-gradient-to-r from-blue-950/40 via-purple-950/30 to-emerald-950/40 border-b border-[#30363d] px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <span className="px-2 py-0.5 rounded font-bold uppercase tracking-wider text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1.5 shadow-sm">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>Top Condition Leader (#1 in Universe)</span>
            </span>
            <span className="text-gray-300 font-medium">
              Focused on <strong className="text-white font-mono">{selectedStock.symbol}</strong> ({selectedStock.name}) —{' '}
              <span className="text-emerald-400 font-bold">{evaluateStockStrategies(selectedStock).badgeLabel}</span>
              {' '}<span className="text-gray-400 hidden sm:inline">(Satisfies Strategy 1 &amp; 2 better than every stock in universe)</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetToBestStrategyStock}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-all shadow-sm"
              title="Locks onto the single stock that satisfies Strategy 1 (ATH Breakout) & Strategy 2 (ATL Turnaround) better than every other stock"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Focus #1 Best Setup
            </button>
            <button
              onClick={() => setIsStrategyExplainerOpen(true)}
              className="flex items-center gap-1.5 text-blue-400 hover:text-blue-300 font-semibold px-2 py-1"
            >
              <Info className="w-3.5 h-3.5" />
              Setup Details ({selectedStock.symbol})
            </button>
          </div>
        </div>
      </div>

      {/* Main Layout Container (With Left Admin Column for Daksh) */}
      <div className="flex-1 flex overflow-hidden">
        {/* Dedicated Left Administrative Column - Exclusively for Daksh */}
        {isMaster && userProfile && (
          <MasterAdminSideColumn
            currentUser={userProfile}
            onLogout={handleLogout}
            onNavigateToTab={(tab) => setActiveTab(tab)}
            onOpenIdAdministration={() => setIsIdAdminOpen(true)}
          />
        )}

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto min-w-0">

      {/* Main App Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* VIEW 1: Screener & Interactive Charts (With 2-Option All Stocks vs Nearest Stocks) */}
        {activeTab === 'screener' && (
          <div className="space-y-6">
            {/* Interactive Candlestick Chart */}
            <TradingChart
              stock={selectedStock}
              timeframe={timeframe}
              onTimeframeChange={setTimeframe}
              onAnalyzeAi={() => setIsAiModalOpen(true)}
              onOpenPaperTrade={(stock) => {
                handleSelectStock(stock);
                setActiveTab('paper-trade');
              }}
              onRefreshRealData={() => fetchRealStockData(selectedStock.symbol)}
              isRefreshing={isFetchingRealData}
            />

            {/* Dropdown Option for All Stocks: Hidden on starting page by default, visible on click */}
            <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl overflow-hidden shadow-xl transition-all">
              {/* Dropdown Header & Trigger Bar */}
              <div
                onClick={() => setIsStocksDropdownOpen((prev) => !prev)}
                className="p-3.5 sm:p-4 bg-gradient-to-r from-[#161b22] via-[#0d1117] to-[#161b22] hover:bg-[#1a202c] transition-colors cursor-pointer flex flex-wrap items-center justify-between gap-3 select-none"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2.5 rounded-xl transition-all ${
                      isStocksDropdownOpen
                        ? 'bg-blue-600/20 text-blue-400 border border-blue-500/40'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    <Layers className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-extrabold text-sm sm:text-base text-white tracking-tight">
                        All Stocks Universe Dropdown
                      </span>
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-300 border border-blue-500/30">
                        {stocks.length} Stocks
                      </span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded-full border transition-all ${
                          isStocksDropdownOpen
                            ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40'
                            : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                        }`}
                      >
                        {isStocksDropdownOpen
                          ? '✓ All Stocks Visible (Click to Hide)'
                          : 'Hidden on Starting Page (Click to View All)'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {isStocksDropdownOpen
                        ? 'All screened stocks, pivots, ATH/ATL distances, and filters are expanded below.'
                        : 'Stocks are hidden on the starting page by default. Click this dropdown to make all stocks visible.'}
                    </p>
                  </div>
                </div>

                <div
                  className="flex items-center gap-2.5"
                  onClick={(e) => e.stopPropagation()}
                >
                  {/* Quick Dropdown Stock Selector even when table is collapsed */}
                  <div className="flex items-center gap-1.5">
                    <label className="text-[11px] text-gray-400 font-medium hidden md:inline">
                      Quick Switch:
                    </label>
                    <select
                      value={selectedStock.id}
                      onChange={(e) => {
                        const found = stocks.find((s) => s.id === e.target.value);
                        if (found) handleSelectStock(found);
                      }}
                      className="bg-[#161b22] border border-[#30363d] text-xs font-mono font-bold text-blue-300 rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-blue-500"
                    >
                      {stocks.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.symbol} — ₹{s.currentPrice.toLocaleString()} (
                          {s.distToAth <= 10
                            ? `ATH -${s.distToAth.toFixed(1)}%`
                            : `ATL +${s.distToAtl?.toFixed(1) || 0}%`}
                          )
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Dropdown Toggle Action Button */}
                  <button
                    type="button"
                    onClick={() => setIsStocksDropdownOpen((prev) => !prev)}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                      isStocksDropdownOpen
                        ? 'bg-blue-600 hover:bg-blue-500 text-white'
                        : 'bg-gradient-to-r from-emerald-600 via-teal-600 to-blue-600 hover:from-emerald-500 hover:to-blue-500 text-white'
                    }`}
                  >
                    <span>
                      {isStocksDropdownOpen
                        ? 'Hide All Stocks'
                        : 'Show All Stocks Dropdown'}
                    </span>
                    {isStocksDropdownOpen ? (
                      <ChevronUp className="w-4 h-4 text-white" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-white animate-bounce" />
                    )}
                  </button>
                </div>
              </div>

              {/* All Stocks Table: Visible ONLY when the dropdown option is clicked */}
              {isStocksDropdownOpen && (
                <div className="p-4 border-t border-[#30363d] bg-[#090d13] animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#21262d]">
                    <span className="text-xs text-gray-400">
                      Showing complete screening universe ({stocks.length} stocks). Click any stock to load on chart.
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsStocksDropdownOpen(false)}
                      className="flex items-center gap-1 text-xs text-gray-400 hover:text-white px-2.5 py-1 rounded-lg bg-[#161b22] hover:bg-[#21262d] border border-[#30363d] transition-colors"
                    >
                      <ChevronUp className="w-3.5 h-3.5 text-blue-400" />
                      <span>Collapse &amp; Hide Stocks</span>
                    </button>
                  </div>

                  <ScreenerTable
                    stocks={stocks}
                    selectedStockId={selectedStock.id}
                    onSelectStock={handleSelectStock}
                    timeframe={timeframe}
                    onTimeframeChange={setTimeframe}
                    onOpenBacktestWithStock={(stock) => {
                      handleSelectStock(stock);
                      setActiveTab('backtest');
                    }}
                    onPaperTradeStock={(stock) => {
                      handleSelectStock(stock);
                      setActiveTab('paper-trade');
                    }}
                    onAddToWatchlist={(stockId) => {
                      handleToggleStockInWatchlist(stockId, activeWatchlistId);
                      soundEffects.playAlertChime();
                    }}
                    onOpenAlertModal={(stock) => {
                      handleSelectStock(stock);
                      setActiveTab('watchlists');
                    }}
                    watchlistStockIds={activeWatchlist?.symbolIds || []}
                    isMaster={isMaster}
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* VIEW 1.5: Dual Condition Scanner (Pattern + Stochastic + Confluence) */}
        {activeTab === 'dual-condition' && (
          <DualConditionScreener
            stocks={stocks}
            selectedStockId={selectedStock.id}
            onSelectStock={handleSelectStock}
            onOpenChart={(stock) => {
              handleSelectStock(stock);
              setActiveTab('screener');
            }}
            onOpenPaperTrade={(stock) => {
              handleSelectStock(stock);
              setActiveTab('paper-trade');
            }}
            onOpenBacktest={(stock) => {
              handleSelectStock(stock);
              setActiveTab('backtest');
            }}
            onAddToWatchlist={(stockId) => {
              handleToggleStockInWatchlist(stockId, activeWatchlistId);
              soundEffects.playAlertChime();
            }}
            watchlistStockIds={activeWatchlist?.symbolIds || []}
          />
        )}

        {/* VIEW 2: Dedicated Stochastic Patterns Screener */}
        {activeTab === 'stoch' && (
          <StochScreener
            stocks={stocks}
            selectedStockId={selectedStock.id}
            onSelectStock={handleSelectStock}
            timeframe={timeframe}
            onTimeframeChange={setTimeframe}
            onOpenBacktestWithStock={(stock) => {
              handleSelectStock(stock);
              setActiveTab('backtest');
            }}
            onAddToWatchlist={(stockId) => {
              handleToggleStockInWatchlist(stockId, activeWatchlistId);
              soundEffects.playAlertChime();
            }}
            onAddStockToUniverse={(newStock) => {
              setStocks((prev) => [newStock, ...prev]);
            }}
            watchlistStockIds={activeWatchlist?.symbolIds || []}
            isMaster={isMaster}
          />
        )}

        {/* VIEW 3: Real-Time Paper Trading Terminal */}
        {activeTab === 'paper-trade' && (
          <PaperTrading
            stocks={stocks}
            userProfile={userProfile}
            selectedStockSymbol={selectedStock.symbol}
            onSelectStockForChart={(sym) => {
              const match = stocks.find((s) => s.symbol === sym);
              if (match) {
                handleSelectStock(match);
                setActiveTab('screener');
              }
            }}
            isSimulatingMarket={isFetchingRealData}
            onToggleSimulatingMarket={handleForceRealtimeSync}
          />
        )}

        {/* VIEW 4: Autonomous AI Strategy Backtester */}
        {activeTab === 'backtest' && (
          <BacktestEngine
            stocks={stocks}
            selectedStockSymbol={selectedStock.symbol}
            onSelectStockForChart={(symbol) => {
              const match = stocks.find((s) => s.symbol === symbol);
              if (match) {
                handleSelectStock(match);
                setActiveTab('screener');
              }
            }}
          />
        )}

        {/* VIEW 5: Custom Watchlists & Real-Time Alerts */}
        {activeTab === 'watchlists' && (
          <WatchlistsAndAlerts
            stocks={stocks}
            watchlists={watchlists}
            activeWatchlistId={activeWatchlistId}
            onSelectWatchlist={setActiveWatchlistId}
            onCreateWatchlist={handleCreateWatchlist}
            onDeleteWatchlist={handleDeleteWatchlist}
            onToggleStockInWatchlist={handleToggleStockInWatchlist}
            alerts={alerts}
            onCreateAlert={handleCreateAlert}
            onDeleteAlert={handleDeleteAlert}
            onTriggerSimulatedAlert={handleTriggerSimulatedAlert}
            isSimulatingMarket={isFetchingRealData}
            onToggleSimulatingMarket={handleForceRealtimeSync}
            onSelectStock={(stock) => {
              handleSelectStock(stock);
              setActiveTab('screener');
            }}
          />
        )}

        {/* VIEW 6: VIP Master Admin & User Surveillance Dashboard (Daksh: dakshphosamani@gmail.com) */}
        {activeTab === 'admin' && (
          <MasterAdminDashboard
            currentUser={userProfile || {
              id: 'master-daksh',
              name: 'Daksh Phosamani',
              gmail: 'dakshphosamani@gmail.com',
              experience: 'Advanced Swing Trader',
              initialCapital: 10000000,
              riskPerTradePercent: 1.5,
              preferredTimeframe: '1D',
              savedAt: new Date().toISOString(),
              isMasterUser: true
            }}
            stocks={stocks}
            onSelectStock={(stock) => {
              handleSelectStock(stock);
              setActiveTab('screener');
            }}
            onNavigateToTab={(tab) => setActiveTab(tab)}
          />
        )}

        {/* AI Strategy & Feature Mentor Bottom Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950/40 via-indigo-950/30 to-purple-950/40 border border-blue-500/25 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white shrink-0 shadow-lg shadow-blue-500/20">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                Have questions about the strategies or any terminal feature?
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  AI Mentor
                </span>
              </h4>
              <p className="text-xs text-gray-400 mt-0.5">
                Ask about the 10% ATH Strategy (Pullback &amp; Momentum), 10% ATL Value Turnaround, or how to execute trades.
              </p>
            </div>
          </div>
          <button
            id="btn-ask-ai-mentor-banner"
            onClick={() => setIsAiChatbotOpen(true)}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md flex items-center gap-1.5 shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ask AI Trading Mentor</span>
          </button>
        </div>

        {/* Best Highlights & Creator Profile: Daksh (Class 9th) */}
        <CreatorFooter 
          onOpenAiMentor={() => setIsAiChatbotOpen(true)}
          userProfile={userProfile}
          isMaster={isMaster}
        />
      </main>
      </div>
      </div>

      {/* Interactive AI Chatbot Window & Floating Launcher */}
      <AiChatbot
        isOpen={isAiChatbotOpen}
        onClose={() => setIsAiChatbotOpen(false)}
        onOpen={() => setIsAiChatbotOpen(true)}
        activeStockSymbol={selectedStock.symbol}
      />

      {/* AI Setup Analysis Modal */}
      <AiSetupModal
        stock={selectedStock}
        timeframe={timeframe}
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
      />

      {/* 10% Strategy Rule Explainer Modal */}
      {isStrategyExplainerOpen && (() => {
        const strategyEval = evaluateStockStrategies(selectedStock);
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl max-w-xl w-full p-5 space-y-4 shadow-2xl">
              <div className="flex items-center justify-between border-b border-[#30363d] pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">
                      10% Strategy Evaluation: {selectedStock.symbol}
                    </h3>
                    <p className="text-[11px] text-gray-400">{selectedStock.name} • {strategyEval.badgeLabel}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsStrategyExplainerOpen(false)}
                  className="text-gray-400 hover:text-white p-1 rounded-lg"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs text-gray-300">
                <div className="p-3 rounded-xl bg-[#161b22] border border-[#30363d] space-y-2">
                  <div className="font-semibold text-white flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      10% Strategy Alignment Score:
                    </span>
                    <span className="text-amber-300 font-mono font-bold text-sm bg-amber-500/15 px-2 py-0.5 rounded border border-amber-500/30">
                      {strategyEval.score} / 100
                    </span>
                  </div>
                  <ul className="space-y-1.5 list-disc list-inside text-gray-300">
                    <li>
                      <strong className="text-white">Proximity to ATH / ATL:</strong> Currently at ₹{selectedStock.currentPrice.toLocaleString()}, 
                      {strategyEval.strategy1Satisfied 
                        ? ` within ${selectedStock.distToAth}% of ATH (Target: ≤10% Mandate)`
                        : ` within ${selectedStock.distToAtl ?? 0}% of ATL (Value Turnaround)`}
                    </li>
                    <li>
                      <strong className="text-white">Base / Resistance Pivot:</strong> ₹{selectedStock.baseResistance.toLocaleString()} 
                      {selectedStock.currentPrice >= selectedStock.baseResistance ? ' (Breakout Confirmed)' : ' (Coiling Below Pivot)'}
                    </li>
                    <li>
                      <strong className="text-white">20 EMA Dynamic Support:</strong> ₹{selectedStock.supportEma.toLocaleString()} 
                      {selectedStock.currentPrice >= selectedStock.supportEma ? ' (Trading Above 20 EMA ✓)' : ' (Below 20 EMA)'}
                    </li>
                    <li>
                      <strong className="text-white">Momentum Oscillator:</strong> %K: {selectedStock.stochK} / %D: {selectedStock.stochD} ({selectedStock.stochSignal || 'Neutral'})
                    </li>
                    <li>
                      <strong className="text-white">Volume Expansion:</strong> {selectedStock.volumeRatio}x 20-day average volume
                    </li>
                  </ul>
                </div>

                <div className="p-3 rounded-xl bg-blue-950/20 border border-blue-500/30 text-blue-200">
                  <div className="font-semibold text-white">10% ATH Strategy Mandate:</div>
                  <p className="mt-1 text-[11px] leading-relaxed">
                    The screener continuously checks live quotes from Indian exchange feeds for the 10% ATH Strategy: identifying quality market leaders pulling back roughly ≤10% from their All-Time Highs and holding dynamic 20 EMA support. The terminal dynamically spotlights whichever stock ranks highest!
                  </p>
                </div>
              </div>

              <div className="flex justify-between items-center pt-2">
                <button
                  onClick={() => {
                    handleResetToBestStrategyStock();
                    setIsStrategyExplainerOpen(false);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30"
                >
                  Switch to Top Ranked Setup
                </button>
                <button
                  onClick={() => setIsStrategyExplainerOpen(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-lg bg-blue-600 text-white hover:bg-blue-500"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Master 1-Click ID Administration Modal (Daksh Only) */}
      <MasterIdAdminModal
        isOpen={isIdAdminOpen}
        onClose={() => setIsIdAdminOpen(false)}
      />

      {/* Footer */}
      <footer className="border-t border-[#30363d] bg-[#080c10] py-4 px-6 text-center text-xs text-gray-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <span>ATH Base Breakout Screener • Personal Market Strategy Laboratory</span>
          <div className="flex items-center gap-4 text-gray-400">
            <span>≤ 10% to ATH</span>
            <span>•</span>
            <span>20 EMA Dynamic Support</span>
            <span>•</span>
            <span>1D &amp; 1W Timeframes</span>
            <span>•</span>
            <span>Bullish/Bearish Day Edge</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
