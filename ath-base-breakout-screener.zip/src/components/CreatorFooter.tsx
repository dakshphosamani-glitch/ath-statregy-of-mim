import React, { useState, useEffect } from 'react';
import { 
  Mail, 
  Send, 
  Check, 
  Copy, 
  Sparkles, 
  GraduationCap, 
  Award, 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  BarChart2, 
  Wallet, 
  Heart,
  ExternalLink,
  MessageSquare,
  Code2,
  BookOpen,
  Compass,
  Lock,
  ArrowUpRight,
  ChevronRight,
  Eye,
  Sliders,
  Bell,
  Trash2,
  RefreshCw,
  Key,
  ShieldAlert,
  UserCheck
} from 'lucide-react';
import { UserProfile } from '../types';

interface CreatorFooterProps {
  onOpenAiMentor?: () => void;
  userProfile?: UserProfile | null;
  isMaster?: boolean;
}

export default function CreatorFooter({ onOpenAiMentor, userProfile, isMaster }: CreatorFooterProps) {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  
  // Contact form state
  const isMasterAccount = Boolean(
    isMaster || 
    userProfile?.isMasterUser || 
    userProfile?.gmail?.toLowerCase() === 'dakshphosamani@gmail.com'
  );

  const [senderName, setSenderName] = useState(() => userProfile?.name || '');
  const [senderEmail, setSenderEmail] = useState(() => userProfile?.gmail || '');
  const [messageCategory, setMessageCategory] = useState<'appreciation' | 'feature' | 'strategy' | 'mentorship' | 'bug' | 'general'>('appreciation');
  const [senderMessage, setSenderMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sentStatus, setSentStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [statusFeedback, setStatusFeedback] = useState('');
  const [activeTab, setActiveTab] = useState<'highlights' | 'about' | 'contact'>('highlights');

  // Master-Only Inbox State (Strictly restricted to dakshphosamani@gmail.com)
  const [isMasterInboxOpen, setIsMasterInboxOpen] = useState(false);
  const [masterMessages, setMasterMessages] = useState<any[]>([]);
  const [isLoadingMasterMessages, setIsLoadingMasterMessages] = useState(false);

  // Sync profile if it updates
  useEffect(() => {
    if (userProfile?.name && !senderName) {
      setSenderName(userProfile.name);
    }
    if (userProfile?.gmail && !senderEmail) {
      setSenderEmail(userProfile.gmail);
    }
  }, [userProfile]);

  const creatorEmail = 'dakshphosamani@gmail.com';

  const categorySubjects: Record<string, string> = {
    appreciation: '🌟 Appreciation & Encouragement for Daksh (BreakoutPulse)',
    feature: '💡 Feature Suggestion for BreakoutPulse 10% ATH Terminal',
    strategy: '📈 Question about the 10% ATH Strategy / 20 EMA Support',
    mentorship: '🤝 Tech Advice & Mentorship for 9th Grade Developer Daksh',
    bug: '🐛 Bug Report / Improvement for BreakoutPulse',
    general: '💬 Message for Daksh from BreakoutPulse User'
  };

  // Fetch messages from backend ONLY for Master Daksh
  const fetchMasterMessages = async () => {
    if (!isMasterAccount) return;
    setIsLoadingMasterMessages(true);
    try {
      const res = await fetch('/api/messages-daksh');
      if (res.ok) {
        const data = await res.json();
        setMasterMessages(data.messages || []);
      }
    } catch {
      // ignore
    } finally {
      setIsLoadingMasterMessages(false);
    }
  };

  useEffect(() => {
    if (isMasterAccount) {
      fetchMasterMessages();
    }
  }, [isMasterAccount]);

  // Master Inbox Access Click (Only available to Master Daksh)
  const handleOpenMasterInboxClick = () => {
    if (isMasterAccount) {
      fetchMasterMessages();
      setIsMasterInboxOpen(true);
    }
  };

  // Delete message from Master Inbox
  const handleDeleteMasterMessage = async (id: string) => {
    try {
      await fetch(`/api/messages-daksh/${id}`, { method: 'DELETE' });
    } catch {}
    setMasterMessages((prev) => prev.filter((m) => m.id !== id));
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(creatorEmail);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  const handleApplyTemplate = (type: 'praise' | 'feature' | 'strategy') => {
    if (type === 'praise') {
      setMessageCategory('appreciation');
      setSenderMessage(
        "Hi Daksh! I was really impressed to learn that you built BreakoutPulse while in 9th class. The terminal's 10% ATH momentum scanner and real-time charts are clean and very useful. Keep up the phenomenal work in coding and finance!"
      );
    } else if (type === 'feature') {
      setMessageCategory('feature');
      setSenderMessage(
        "Hi Daksh! Great work on BreakoutPulse. I have a feature idea for the 10% ATH Strategy Screener: it would be awesome if we could filter by average daily volume and add automated alerts for when a stock bounces off the 20 EMA."
      );
    } else if (type === 'strategy') {
      setMessageCategory('strategy');
      setSenderMessage(
        "Hi Daksh! I have a question about how you evaluate the 10% ATH setup: what is your rule for entering when a stock breaks out above its pivot versus when it dips down to test the 20 EMA?"
      );
    }
  };

  // Direct in-app send without opening Gmail or any external mail clients
  const handleSendDirectMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    const cleanName = senderName.trim() || userProfile?.name?.trim() || '';
    const cleanEmail = senderEmail.trim() || userProfile?.gmail?.trim() || '';

    if (!cleanName) {
      setStatusFeedback('Please enter your real name before sending.');
      setSentStatus('error');
      return;
    }
    if (!cleanEmail) {
      setStatusFeedback('Please enter your email address so Daksh can reply.');
      setSentStatus('error');
      return;
    }
    if (!senderMessage.trim()) {
      setStatusFeedback('Please enter your message before sending.');
      setSentStatus('error');
      return;
    }

    setIsSending(true);
    setStatusFeedback('');

    const payload = {
      name: cleanName,
      email: cleanEmail,
      category: categorySubjects[messageCategory] || 'General Message',
      message: senderMessage.trim(),
    };

    try {
      // 1. Post to backend direct endpoint
      const res = await fetch('/api/send-message-daksh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error('Backend dispatch returned error');
      }

      setSentStatus('success');
      setStatusFeedback(`Message sent directly to Master Daksh (${creatorEmail})!`);
      setSenderMessage('');
      if (isMasterAccount) {
        fetchMasterMessages();
      }
      setTimeout(() => {
        setSentStatus('idle');
        setStatusFeedback('');
      }, 7000);
    } catch (err) {
      // Fallback: Dispatch directly to FormSubmit AJAX from browser
      try {
        await fetch('https://formsubmit.co/ajax/dakshphosamani@gmail.com', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({
            name: payload.name,
            email: payload.email,
            _subject: `[BreakoutPulse Direct Note] from ${payload.name} (${payload.category})`,
            message: payload.message,
            targetEmail: 'dakshphosamani@gmail.com',
          }),
        });

        setSentStatus('success');
        setStatusFeedback(`Message sent directly to Master Daksh (${creatorEmail})!`);
        setSenderMessage('');
        if (isMasterAccount) {
          fetchMasterMessages();
        }
        setTimeout(() => {
          setSentStatus('idle');
          setStatusFeedback('');
        }, 7000);
      } catch (fallbackErr) {
        setSentStatus('error');
        setStatusFeedback('Failed to deliver message. Please check connection and try again.');
      }
    } finally {
      setIsSending(false);
    }
  };

  // Copy entire message text + email to clipboard if needed
  const handleCopyAll = () => {
    const text = `To: ${creatorEmail}\nSubject: ${categorySubjects[messageCategory]}\nFrom: ${senderName || 'Anonymous'}\nReply-To: ${senderEmail || 'Not specified'}\n\n${senderMessage}`;
    navigator.clipboard.writeText(text);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 3000);
  };

  return (
    <footer id="creator-footer" className="mt-14 pt-10 border-t border-[#30363d]/80 bg-gradient-to-b from-[#0d1117] via-[#090d13] to-[#040608] text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-12 pb-14">
        
        {/* ========================================================================= */}
        {/* SECTION 1: BEST HIGHLIGHTS & SUPERPOWERS OF BREAKOUTPULSE                 */}
        {/* ========================================================================= */}
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#30363d]/60 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <Award className="w-4 h-4" />
                </span>
                <h3 className="text-lg font-extrabold text-white tracking-tight flex items-center gap-2">
                  <span>Best Things About BreakoutPulse</span>
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 font-mono font-medium">
                    Why Traders Love It
                  </span>
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-gray-400 mt-1 max-w-2xl leading-relaxed">
                Engineered from the ground up for high-probability momentum trading. BreakoutPulse cuts out 95% of stock market noise so you can focus strictly on elite setups.
              </p>
            </div>
            
            <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1.5 rounded-xl w-fit shrink-0">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Real-Time NSE &amp; BSE Analytics Terminal</span>
            </div>
          </div>

          {/* 6 Key Best Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* 1. 10% ATH Strategy Scanner */}
            <div className="p-4 rounded-2xl bg-[#161b22]/90 border border-[#30363d] hover:border-blue-500/50 transition-all hover:shadow-lg hover:shadow-blue-950/20 space-y-2.5 group">
              <div className="flex items-center justify-between">
                <div className="w-9 h-9 rounded-xl bg-blue-500/15 text-blue-400 border border-blue-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-blue-500/10 text-blue-300 border border-blue-500/20">
                  Core Strategy #1
                </span>
              </div>
              <h4 className="text-sm font-bold text-white group-hover:text-blue-300 transition-colors">
                10% ATH Momentum Scanner
              </h4>
              <p className="text-xs text-gray-400 leading-relaxed">
                Instantly tracks top Indian stocks trading within ≤10% of their All-Time Highs while holding dynamic support above the rising 20 EMA. Pinpoints high-tight consolidations before breakouts.
              </p>
              <div className="text-[11px] font-mono text-blue-400 font-semibold pt-1 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-blue-400" />
                <span>Filters out 95% of weak laggards</span>
              </div>
            </div>

            {/* 2. Sub-5-Second Live Indian Feeds */}
            <div className="p-4 rounded-2xl bg-[#161b22]/90 border border-[#30363d] hover:border-emerald-500/50 transition-all hover:shadow-lg hover:shadow-emerald-950/20 space-y-2.5 group">
              <div className="flex items-center justify-between">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Zap className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                  Sub-5s Streaming
                </span>
              </div>
              <h4 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
                Live Real-Time Market Ticks
              </h4>
              <p className="text-xs text-gray-400 leading-relaxed">
                Connects directly to authentic Indian exchange quote feeds for Nifty 50, Next 50, and midcaps with streaming bid/ask data, volume velocity, and instant price updates during active market hours.
              </p>
              <div className="text-[11px] font-mono text-emerald-400 font-semibold pt-1 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Zero delayed quotes or stale data</span>
              </div>
            </div>

            {/* 3. Interactive Candlestick Charts */}
            <div className="p-4 rounded-2xl bg-[#161b22]/90 border border-[#30363d] hover:border-purple-500/50 transition-all hover:shadow-lg hover:shadow-purple-950/20 space-y-2.5 group">
              <div className="flex items-center justify-between">
                <div className="w-9 h-9 rounded-xl bg-purple-500/15 text-purple-400 border border-purple-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <BarChart2 className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                  Multi-Timeframe
                </span>
              </div>
              <h4 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors">
                Pro Technical Chart Terminal
              </h4>
              <p className="text-xs text-gray-400 leading-relaxed">
                Multi-timeframe charting (1D, 1W, 1M, 5m, 15m) featuring dynamic 20 EMA, 50 SMA, 200 SMA, Bollinger Bands, Volume deltas, Fibonacci retracements, and interactive trendline drawing tools.
              </p>
              <div className="text-[11px] font-mono text-purple-300 font-semibold pt-1 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-purple-300" />
                <span>TradingView-grade fluid interaction</span>
              </div>
            </div>

            {/* 4. Risk-Free Paper Trading */}
            <div className="p-4 rounded-2xl bg-[#161b22]/90 border border-[#30363d] hover:border-amber-500/50 transition-all hover:shadow-lg hover:shadow-amber-950/20 space-y-2.5 group">
              <div className="flex items-center justify-between">
                <div className="w-9 h-9 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Wallet className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  ₹10,00,000 Capital
                </span>
              </div>
              <h4 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                Real-Time Paper Trading Simulator
              </h4>
              <p className="text-xs text-gray-400 leading-relaxed">
                Practice executing live trades without risking real money. Features automatic structural stop-loss calculations anchored to swing lows, trailing targets, and realistic order book fill logic.
              </p>
              <div className="text-[11px] font-mono text-amber-300 font-semibold pt-1 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-amber-300" />
                <span>Master execution with zero financial risk</span>
              </div>
            </div>

            {/* 5. Quantitative AI Backtester */}
            <div className="p-4 rounded-2xl bg-[#161b22]/90 border border-[#30363d] hover:border-cyan-500/50 transition-all hover:shadow-lg hover:shadow-cyan-950/20 space-y-2.5 group">
              <div className="flex items-center justify-between">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Sliders className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                  Strategy Validation
                </span>
              </div>
              <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                Quantitative Backtest Engine
              </h4>
              <p className="text-xs text-gray-400 leading-relaxed">
                Stress-test the 10% ATH rules over historical candle bars across Bullish, Neutral, and Bearish regimes. Evaluates win rate, profit factor, Sharpe ratio, and maximum drawdown metrics.
              </p>
              <div className="text-[11px] font-mono text-cyan-300 font-semibold pt-1 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-cyan-300" />
                <span>Mathematical edge proven over time</span>
              </div>
            </div>

            {/* 6. Stochastic Turnaround Radar */}
            <div className="p-4 rounded-2xl bg-[#161b22]/90 border border-[#30363d] hover:border-rose-500/50 transition-all hover:shadow-lg hover:shadow-rose-950/20 space-y-2.5 group">
              <div className="flex items-center justify-between">
                <div className="w-9 h-9 rounded-xl bg-rose-500/15 text-rose-400 border border-rose-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Eye className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/20">
                  Dual Confluence
                </span>
              </div>
              <h4 className="text-sm font-bold text-white group-hover:text-rose-300 transition-colors">
                Stochastic Turnaround Radar
              </h4>
              <p className="text-xs text-gray-400 leading-relaxed">
                Secondary momentum confluence module capturing early %K &amp; %D bullish crossovers emerging from deep oversold zones (&lt;20) for early-stage rebound entries.
              </p>
              <div className="text-[11px] font-mono text-rose-300 font-semibold pt-1 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-rose-300" />
                <span>Spots reversals before the crowd reacts</span>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* SECTION 2: CREATOR SPOTLIGHT & FULL BIO (DAKSH - CLASS 9 STUDENT)         */}
        {/* ========================================================================= */}
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-blue-950/40 via-[#111722] to-indigo-950/40 border border-blue-500/30 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left 7 Columns: Creator Bio & Story */}
            <div className="lg:col-span-7 space-y-5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-bold font-mono bg-blue-500/20 text-blue-300 border border-blue-500/40 flex items-center gap-1.5 shadow-sm">
                  <GraduationCap className="w-4 h-4 text-blue-400" />
                  Class 9th Student &amp; Developer
                </span>
                <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  Young FinTech Innovator (Age 14-15)
                </span>
                <span className="px-2.5 py-1 rounded-full text-xs font-mono text-gray-400 bg-[#161b22] border border-[#30363d] flex items-center gap-1">
                  <span>🇮🇳 India</span>
                </span>
              </div>

              <div>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
                  <span>Meet the Creator: Daksh Phosamani</span>
                </h3>
                <p className="text-xs sm:text-sm text-blue-300/90 font-medium mt-1">
                  Founder &amp; Solo Architect of BreakoutPulse • 9th Grade Student Prodigy in India
                </p>
              </div>

              {/* Special Spotlight Card: What Makes Daksh Extraordinary */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-blue-500/10 to-purple-500/10 border border-amber-500/30 space-y-2 shadow-lg">
                <div className="flex items-center gap-2 text-amber-300 font-bold text-xs uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>Something Special About Daksh</span>
                </div>
                <p className="text-xs text-amber-100/90 leading-relaxed font-sans">
                  While most 14-year-olds in 9th grade spend their evenings playing video games, Daksh has dedicated countless hours after homework to mastering complex quantitative financial mathematics, technical price structures, and modern software engineering. He independently envisioned, designed, and coded the entire BreakoutPulse terminal from scratch — proving that age is never a boundary to creating institutional-grade financial technology!
                </p>
                <div className="pt-1 flex flex-wrap gap-2 text-[11px] font-mono">
                  <span className="px-2 py-0.5 rounded bg-[#161b22] text-amber-300 border border-amber-500/30">
                    ⚡ 100% Solo Built
                  </span>
                  <span className="px-2 py-0.5 rounded bg-[#161b22] text-cyan-300 border border-cyan-500/30">
                    📐 10% ATH &amp; 20 EMA Algorithm
                  </span>
                  <span className="px-2 py-0.5 rounded bg-[#161b22] text-emerald-300 border border-emerald-500/30">
                    🇮🇳 Young Indian Innovator
                  </span>
                </div>
              </div>

              {/* Detailed Biography Text */}
              <div className="space-y-3 text-xs sm:text-sm text-gray-300 leading-relaxed">
                <p>
                  Hi there! My name is <strong>Daksh</strong>, and I am currently a <strong>9th-grade student</strong> in India. Outside of my school classes, homework, and exams, my true passion is <strong>software development, mathematics, and quantitative financial markets</strong>.
                </p>
                <p>
                  I noticed how so many retail traders lose their hard-earned money chasing random hype, emotional tips, and cluttered indicators. I wanted to build a clean, institutional-grade screener that enforces strict trading discipline — filtering exclusively for stocks in high-tight momentum within <strong>≤10% of their All-Time Highs</strong> supported by the <strong>rising 20 EMA</strong>.
                </p>
                <p>
                  I taught myself modern full-stack web engineering (TypeScript, React, Tailwind CSS, real-time data streaming, and quantitative technical analysis algorithms) to create BreakoutPulse completely from scratch.
                </p>
              </div>

              {/* Personal Quote Card */}
              <div className="p-3.5 rounded-2xl bg-[#090d14] border-l-4 border-l-blue-400 border border-[#30363d] text-xs italic text-blue-200/90 leading-relaxed">
                &ldquo;I don't believe age defines what someone can build. When you are deeply curious and willing to learn the math and the code line by line, you can solve real problems for real people. BreakoutPulse is my tribute to disciplined, mathematical trading.&rdquo;
                <div className="not-italic font-bold text-white text-[11px] mt-1.5 font-mono">
                  — Daksh Phosamani, 9th Grade Developer
                </div>
              </div>

              {/* Badges of Skills & Learning */}
              <div className="pt-1">
                <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Code2 className="w-3.5 h-3.5 text-blue-400" />
                  <span>What I Study &amp; Build With:</span>
                </div>
                <div className="flex flex-wrap gap-1.5 text-xs font-mono">
                  <span className="px-2.5 py-1 rounded-lg bg-[#161b22] text-gray-300 border border-[#30363d]">
                    📚 Class 9 Mathematics &amp; Physics
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-[#161b22] text-blue-300 border border-blue-500/30">
                    ⚛️ React &amp; TypeScript
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-[#161b22] text-emerald-300 border border-emerald-500/30">
                    📈 Technical Price Action &amp; 20 EMA
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-[#161b22] text-purple-300 border border-purple-500/30">
                    🧮 Quantitative Algorithms
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-[#161b22] text-amber-300 border border-amber-500/30">
                    ⚡ NSE / BSE Market Data
                  </span>
                </div>
              </div>

              {/* Safety & Privacy Notice (User's specific condition: "except the email password any") */}
              <div className="p-3.5 rounded-2xl bg-[#0d1117]/90 border border-emerald-500/30 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <span>Privacy &amp; Security Guaranteed</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 rounded">
                      Protected
                    </span>
                  </div>
                  <p className="text-gray-400 leading-relaxed">
                    As a student developer, privacy is strictly maintained. <strong>No account passwords, sensitive secrets, or private login credentials are ever asked or disclosed</strong>. You can safely send messages and feedback directly to my verified public email.
                  </p>
                </div>
              </div>

              {/* Aspirations */}
              <div className="flex items-center gap-2 text-xs text-gray-400 pt-1">
                <Compass className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>
                  <strong>Future Goal:</strong> Aspiring to study Computer Science and Financial Engineering in college and build world-class FinTech tools!
                </span>
              </div>
            </div>

            {/* Right 5 Columns: Direct In-App Message Entry & Instant Delivery */}
            <div className="lg:col-span-5 flex flex-col gap-4 p-5 sm:p-6 rounded-3xl bg-[#0d1117]/90 border border-[#30363d] backdrop-blur-md shadow-xl">
              
              <div className="border-b border-[#30363d] pb-3">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-white font-bold text-sm">
                    <Mail className="w-4 h-4 text-blue-400" />
                    <span>Send Message to Daksh</span>
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                    Direct Send • No Gmail App Needed
                  </span>
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  Just enter your message below. It sends straight to Daksh (<strong>{creatorEmail}</strong>) directly from this page — zero redirects, no need to open Gmail!
                </p>
              </div>

              {/* Creator's Email Address Display */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Daksh's Official Email:</span>
                  <span className="text-emerald-400 text-[10px] font-mono font-normal">Active &amp; Verified</span>
                </label>
                <div className="p-3 rounded-2xl bg-[#161b22] border border-[#30363d] hover:border-blue-500/50 transition-colors flex items-center justify-between gap-2 shadow-inner">
                  <div className="min-w-0">
                    <div className="text-xs sm:text-sm font-mono font-bold text-blue-300 select-all truncate">
                      {creatorEmail}
                    </div>
                    <div className="text-[10px] text-emerald-400 font-mono mt-0.5 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      <span>Primary &amp; Exclusive Contact</span>
                    </div>
                  </div>
                  <button
                    onClick={handleCopyEmail}
                    className="p-2 rounded-xl bg-[#21262d] hover:bg-[#30363d] text-gray-300 hover:text-white transition-all shrink-0 flex items-center gap-1.5 text-xs font-semibold"
                    title="Copy email to clipboard"
                  >
                    {copiedEmail ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 text-[11px]">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-gray-300" />
                        <span className="text-[11px]">Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Direct In-App Message Input Form (User enters message right here) */}
              <form onSubmit={handleSendDirectMessage} className="space-y-3 pt-1 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-gray-300 text-[11px] mb-1 font-medium">
                      Your Name: *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Enter your name"
                      value={senderName}
                      onChange={(e) => setSenderName(e.target.value)}
                      className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-300 text-[11px] mb-1 font-medium">
                      Your Email (for Daksh to reply): *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="Enter your email"
                      value={senderEmail}
                      onChange={(e) => setSenderEmail(e.target.value)}
                      className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-300 text-[11px] mb-1 font-medium">
                    Topic / Category:
                  </label>
                  <select
                    value={messageCategory}
                    onChange={(e) => setMessageCategory(e.target.value as any)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="appreciation">🌟 Praise &amp; Encouragement for Daksh (9th Class)</option>
                    <option value="feature">💡 Feature Suggestion for BreakoutPulse</option>
                    <option value="strategy">📈 Question on 10% ATH Strategy / 20 EMA Support</option>
                    <option value="mentorship">🤝 Tech Advice / Mentorship for Daksh</option>
                    <option value="bug">🐛 Bug Report / Technical Feedback</option>
                    <option value="general">💬 General Message</option>
                  </select>
                </div>

                {/* Quick 1-Click Message Starters */}
                <div className="space-y-1">
                  <div className="text-[10px] text-gray-400 font-medium flex items-center justify-between">
                    <span>1-Click Message Ideas:</span>
                    <span className="text-gray-500 text-[9px]">Click to auto-fill</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleApplyTemplate('praise')}
                      className="text-[10px] px-2 py-1 rounded-lg bg-[#161b22] hover:bg-[#21262d] text-blue-300 border border-blue-500/30 transition-colors"
                    >
                      👏 Praise Daksh (9th Class)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyTemplate('feature')}
                      className="text-[10px] px-2 py-1 rounded-lg bg-[#161b22] hover:bg-[#21262d] text-emerald-300 border border-emerald-500/30 transition-colors"
                    >
                      💡 Suggest Feature
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyTemplate('strategy')}
                      className="text-[10px] px-2 py-1 rounded-lg bg-[#161b22] hover:bg-[#21262d] text-purple-300 border border-purple-500/30 transition-colors"
                    >
                      📈 10% ATH Question
                    </button>
                  </div>
                </div>

                {/* Message Body */}
                <div>
                  <label className="block text-gray-300 text-[11px] mb-1 font-medium flex items-center justify-between">
                    <span>Enter your message here: *</span>
                    <span className="text-gray-500 text-[10px]">Direct inbox delivery</span>
                  </label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Type your message for Daksh here. It will be sent straight to his email without you having to open Gmail..."
                    value={senderMessage}
                    onChange={(e) => setSenderMessage(e.target.value)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 resize-none leading-relaxed text-xs"
                  />
                </div>

                {/* Primary Direct Send Button (Zero Gmail opening) */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={isSending || !senderMessage.trim()}
                    className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition-all shadow-lg ${
                      isSending
                        ? 'bg-blue-800 text-blue-200 cursor-not-allowed'
                        : !senderMessage.trim()
                        ? 'bg-[#21262d] text-gray-500 cursor-not-allowed border border-[#30363d]'
                        : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white cursor-pointer hover:shadow-blue-500/20'
                    }`}
                  >
                    {isSending ? (
                      <>
                        <span className="w-3.5 h-3.5 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                        <span>Sending Directly to Daksh...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5 text-cyan-300" />
                        <span>Send Message Directly to Daksh</span>
                      </>
                    )}
                  </button>

                  {/* Master-Only Messages Feature beside the sending one (Strictly hidden in local accounts) */}
                  {isMasterAccount && (
                    <button
                      type="button"
                      onClick={handleOpenMasterInboxClick}
                      className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all shadow-sm shrink-0 cursor-pointer"
                      title="Exclusive Master Feature: View all messages sent by individuals (Only for dakshphosamani@gmail.com)"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                      <span>Master Inbox ({masterMessages.length})</span>
                      <Lock className="w-3 h-3 text-amber-400/80" />
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap items-center justify-between text-[10px] text-gray-500 pt-0.5 gap-1">
                  <span className="flex items-center gap-1 text-emerald-400/90 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    Delivers to Master ID: dakshphosamani@gmail.com
                  </span>
                  {isMasterAccount && (
                    <span className="text-amber-400/80 font-mono flex items-center gap-1">
                      <Lock className="w-3 h-3 text-amber-400" />
                      Master Terminal Active
                    </span>
                  )}
                </div>

                {/* Real-time Delivery Feedback */}
                {sentStatus === 'success' && (
                  <div className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2.5 animate-in fade-in">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div>
                      <div className="font-bold text-white">✓ Message Sent Successfully!</div>
                      <div className="text-[11px] text-emerald-300 mt-0.5">
                        Your message was delivered straight to Daksh at <strong>{creatorEmail}</strong> without opening Gmail. Thank you!
                      </div>
                    </div>
                  </div>
                )}

                {sentStatus === 'error' && (
                  <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs animate-in fade-in">
                    {statusFeedback || 'Failed to send. Please check your text and try again.'}
                  </div>
                )}
              </form>

              {copiedEmail && (
                <div className="text-xs text-emerald-400 text-center font-medium bg-emerald-500/10 border border-emerald-500/30 py-1.5 rounded-xl animate-in fade-in">
                  ✓ Email copied to clipboard! You can paste it into any mail client.
                </div>
              )}
            </div>

          </div>
        </div>

        {/* ========================================================================= */}
        {/* SECTION 3: COPYRIGHT & TERMINAL METRICS BOTTOM BAR                        */}
        {/* ========================================================================= */}
        <div className="pt-6 border-t border-[#21262d] flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gray-500">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
            <span className="font-bold text-gray-200">BreakoutPulse Terminal</span>
            <span>•</span>
            <span className="text-gray-400">10% ATH Momentum Engine</span>
            <span>•</span>
            <span className="text-blue-400 font-semibold">Created by Daksh (9th Class Student Developer)</span>
            <span>•</span>
            <span className="text-gray-500">Made with ❤️ in India</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <a 
              href={`mailto:${creatorEmail}`}
              className="text-gray-400 hover:text-blue-400 font-mono transition-colors underline decoration-dotted"
              title="Send email to Daksh"
            >
              {creatorEmail}
            </a>
            <span>•</span>
            <button
              onClick={() => {
                const el = document.getElementById('creator-footer');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="text-gray-400 hover:text-white transition-colors"
            >
              Back to Top of Creator Info ↑
            </button>
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* INTERACTIVE MODAL: SEND MESSAGE TO DAKSH VIA YOUR EMAIL                   */}
      {/* ========================================================================= */}
      {isContactModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-[#0d1117] border border-[#30363d] rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-[#30363d] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>Send a Message to Daksh</span>
                  </h3>
                  <p className="text-xs text-gray-400">
                    Creator of BreakoutPulse • 9th Class Student Developer
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsContactModalOpen(false)}
                className="text-gray-400 hover:text-white p-1.5 rounded-lg hover:bg-[#161b22] transition-colors"
                title="Close modal"
              >
                ✕
              </button>
            </div>

            {/* Quick Template Buttons */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
                Quick Starters (Click to Fill):
              </label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('praise')}
                  className="text-xs px-2.5 py-1 rounded-lg bg-[#161b22] hover:bg-[#21262d] text-blue-300 border border-blue-500/30 transition-colors"
                >
                  🌟 Words of Encouragement
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('feature')}
                  className="text-xs px-2.5 py-1 rounded-lg bg-[#161b22] hover:bg-[#21262d] text-emerald-300 border border-emerald-500/30 transition-colors"
                >
                  💡 Feature Suggestion
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('strategy')}
                  className="text-xs px-2.5 py-1 rounded-lg bg-[#161b22] hover:bg-[#21262d] text-purple-300 border border-purple-500/30 transition-colors"
                >
                  📈 Trading Strategy Question
                </button>
              </div>
            </div>

            {/* Form */}
            <div className="space-y-3.5 text-xs">
              
              {/* Sender Name */}
              <div>
                <label className="block text-gray-300 text-xs mb-1 font-medium">
                  Your Name:
                </label>
                <input
                  type="text"
                  placeholder="e.g. Rahul, Priya, Alex"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Sender Email */}
              <div>
                <label className="block text-gray-300 text-xs mb-1 font-medium">
                  Your Email Address (Daksh will reply here):
                </label>
                <input
                  type="email"
                  placeholder="your.email@example.com"
                  value={senderEmail}
                  onChange={(e) => setSenderEmail(e.target.value)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Subject / Category */}
              <div>
                <label className="block text-gray-300 text-xs mb-1 font-medium">
                  Message Topic:
                </label>
                <select
                  value={messageCategory}
                  onChange={(e) => setMessageCategory(e.target.value as any)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="appreciation">🌟 Feedback &amp; Encouragement for Daksh (9th Class)</option>
                  <option value="feature">💡 Feature Suggestion for BreakoutPulse</option>
                  <option value="strategy">📈 Question on 10% ATH Strategy / 20 EMA Support</option>
                  <option value="mentorship">🤝 Tech Advice / Mentorship for Daksh</option>
                  <option value="bug">🐛 Bug Report / Technical Feedback</option>
                  <option value="general">💬 General Message</option>
                </select>
              </div>

              {/* Message Body */}
              <div>
                <label className="block text-gray-300 text-xs mb-1 font-medium">
                  Your Message for Daksh: *
                </label>
                <textarea
                  rows={5}
                  required
                  placeholder="Write your thoughts, feedback, encouragement, or questions about the BreakoutPulse terminal..."
                  value={senderMessage}
                  onChange={(e) => setSenderMessage(e.target.value)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 resize-none leading-relaxed"
                />
              </div>

              {/* Info Note: Direct delivery explanation */}
              <div className="p-3 rounded-2xl bg-blue-950/20 border border-blue-500/30 text-blue-300 text-xs space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-white">
                  <Mail className="w-3.5 h-3.5 text-blue-400" />
                  <span>Direct In-App Delivery:</span>
                </div>
                <p className="text-gray-300 leading-relaxed text-[11px]">
                  When you click <strong>"Send Message Directly to Daksh"</strong>, your note is immediately dispatched straight to Daksh's inbox at <strong>{creatorEmail}</strong>. No need to open Gmail, compose an email, or leave this screen!
                </p>
              </div>

              {/* Direct Send Action Button */}
              <div className="space-y-2 pt-1">
                <button
                  type="button"
                  disabled={isSending || !senderMessage.trim()}
                  onClick={() => handleSendDirectMessage()}
                  className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs font-bold transition-all shadow-md ${
                    isSending
                      ? 'bg-blue-800 text-blue-200 cursor-not-allowed'
                      : !senderMessage.trim()
                      ? 'bg-[#21262d] text-gray-500 cursor-not-allowed border border-[#30363d]'
                      : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white cursor-pointer shadow-blue-500/20'
                  }`}
                >
                  {isSending ? (
                    <>
                      <span className="w-3.5 h-3.5 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                      <span>Sending Directly to Daksh...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 text-cyan-300" />
                      <span>Send Message Directly to Daksh</span>
                    </>
                  )}
                </button>

                <div className="flex items-center justify-between gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleCopyAll}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#161b22] hover:bg-[#21262d] text-gray-300 hover:text-white border border-[#30363d] text-xs font-medium transition-colors"
                  >
                    {copiedAll ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-gray-400" />}
                    <span>{copiedAll ? 'Copied to Clipboard!' : 'Copy Note & Email'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsContactModalOpen(false)}
                    className="px-4 py-2 rounded-xl text-gray-400 hover:text-white bg-[#161b22] border border-[#30363d] text-xs font-semibold"
                  >
                    Cancel / Close
                  </button>
                </div>
              </div>

              {sentStatus === 'success' && (
                <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs text-center font-semibold animate-in fade-in">
                  ✓ Message sent directly to Daksh (dakshphosamani@gmail.com)! Your message is now in his inbox.
                </div>
              )}

              {sentStatus === 'error' && (
                <div className="p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs text-center font-semibold animate-in fade-in">
                  {statusFeedback || 'Could not send message. Please check your text.'}
                </div>
              )}

              {copiedAll && (
                <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs text-center font-semibold animate-in fade-in">
                  ✓ Copied Daksh's email address and message to clipboard!
                </div>
              )}

            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: MASTER INBOX — ALL MESSAGES FROM INDIVIDUALS (ONLY FOR DAKSH)      */}
      {/* ========================================================================= */}
      {isMasterAccount && isMasterInboxOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-[#0d1117] border border-amber-500/40 rounded-3xl max-w-2xl w-full p-6 space-y-4 shadow-2xl relative max-h-[88vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-[#30363d] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white">
                      Master Messages Inbox
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                      <UserCheck className="w-3 h-3" /> dakshphosamani@gmail.com
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5">
                    Private direct messages received from users and visitors
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={fetchMasterMessages}
                  disabled={isLoadingMasterMessages}
                  className="p-2 rounded-xl bg-[#161b22] hover:bg-[#21262d] text-gray-300 hover:text-white border border-[#30363d] transition-colors"
                  title="Refresh incoming messages"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingMasterMessages ? 'animate-spin' : ''}`} />
                </button>
                <button
                  onClick={() => setIsMasterInboxOpen(false)}
                  className="text-gray-400 hover:text-white p-2 rounded-xl hover:bg-[#161b22]"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Notification Banner */}
            <div className="p-3 rounded-2xl bg-gradient-to-r from-blue-950/40 to-amber-950/30 border border-amber-500/30 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-gray-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Inbox active: All individual notes forward directly to <strong>dakshphosamani@gmail.com</strong></span>
              </div>
              <span className="text-[11px] font-mono text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-lg border border-amber-500/40">
                Total: {masterMessages.length}
              </span>
            </div>

            {/* Messages Scroll Area */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
              {masterMessages.length === 0 ? (
                <div className="py-12 text-center text-gray-500 space-y-2">
                  <Mail className="w-8 h-8 mx-auto text-gray-600" />
                  <p className="text-sm font-medium text-gray-400">No messages in Master Inbox yet.</p>
                  <p className="text-xs text-gray-500">
                    When visitors submit the form, their message will appear here and route to dakshphosamani@gmail.com.
                  </p>
                </div>
              ) : (
                masterMessages.map((msg, idx) => (
                  <div key={msg.id || idx} className="p-4 rounded-2xl bg-[#161b22] border border-[#30363d] space-y-2.5 hover:border-amber-500/40 transition-colors">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">
                            {msg.senderName || msg.name || 'User'}
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-300 border border-blue-500/30">
                            {msg.category || 'General Message'}
                          </span>
                        </div>
                        <div className="text-[11px] text-gray-400 font-mono mt-0.5">
                          Sender Email: <a href={`mailto:${msg.senderEmail || msg.email}`} className="text-blue-400 hover:underline font-mono">{msg.senderEmail || msg.email || 'None provided'}</a>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-gray-500 font-mono block">
                          {msg.createdAt ? new Date(msg.createdAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : 'Recent'}
                        </span>
                        <span className="text-[10px] text-emerald-400 font-mono inline-flex items-center gap-1 mt-1">
                          <Check className="w-3 h-3" /> Delivered to Daksh
                        </span>
                      </div>
                    </div>

                    <div className="text-gray-200 bg-[#0d1117] p-3 rounded-xl border border-[#21262d] whitespace-pre-wrap leading-relaxed text-xs">
                      {msg.message}
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-2">
                        {Boolean(msg.senderEmail || msg.email) && (
                          <a
                            href={`mailto:${msg.senderEmail || msg.email}?subject=Re: ${encodeURIComponent(msg.category || 'BreakoutPulse Message')}`}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 text-[11px] font-semibold transition-colors"
                          >
                            <Send className="w-3 h-3" />
                            <span>Reply to Sender</span>
                          </a>
                        )}
                        {Boolean(msg.senderEmail || msg.email) && (
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(msg.senderEmail || msg.email || '');
                            }}
                            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-300 text-[11px] transition-colors"
                          >
                            <Copy className="w-3 h-3" />
                            <span>Copy Email</span>
                          </button>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDeleteMasterMessage(msg.id)}
                        className="text-gray-500 hover:text-rose-400 p-1.5 rounded-lg hover:bg-rose-500/10 transition-colors"
                        title="Delete from inbox"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="pt-3 border-t border-[#30363d] flex items-center justify-between text-xs">
              <span className="text-gray-400">
                Master ID: <strong className="text-white font-mono">dakshphosamani@gmail.com</strong>
              </span>
              <button
                onClick={() => setIsMasterInboxOpen(false)}
                className="px-4 py-1.5 rounded-xl bg-[#161b22] hover:bg-[#21262d] text-gray-200 border border-[#30363d] font-semibold transition-colors"
              >
                Close Inbox
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
}
