import { useState, useMemo } from 'react';
import { 
  UserProfile, 
  UserActivityItem, 
  GlobalUserTradeRecord, 
  Stock 
} from '../types';
import { 
  getRegisteredUsers, 
  getUserActivities, 
  getAllUserTrades, 
  recordUserActivity,
  MASTER_EMAIL,
  toggleBlockEmail,
  isEmailBlocked,
  deleteUserAccount
} from '../utils/userRegistry';
import { 
  ShieldCheck, 
  Users, 
  Activity, 
  History, 
  Search, 
  Filter, 
  Flame, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle2, 
  ArrowUpRight, 
  Sparkles, 
  Clock, 
  Layers, 
  RefreshCw,
  Mail,
  UserCheck,
  Award,
  Zap,
  Radio,
  ExternalLink,
  Key,
  Eye,
  EyeOff,
  Ban,
  Unlock,
  Copy,
  Check,
  Trash2
} from 'lucide-react';
import { soundEffects } from '../utils/audioAlert';

interface MasterAdminDashboardProps {
  currentUser: UserProfile;
  stocks: Stock[];
  onSelectStock: (stock: Stock) => void;
  onNavigateToTab: (tab: any) => void;
}

export default function MasterAdminDashboard({
  currentUser,
  stocks,
  onSelectStock,
  onNavigateToTab,
}: MasterAdminDashboardProps) {
  const [activeSubTab, setActiveSubTab] = useState<'users' | 'trades' | 'activities' | 'atl-scanner'>('users');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUserFilter, setSelectedUserFilter] = useState<string>('ALL');
  const [refreshKey, setRefreshKey] = useState(0);
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [showPasswordMap, setShowPasswordMap] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Load registered users, trades, activities
  const allUsers = useMemo(() => getRegisteredUsers(), [refreshKey]);
  const allActivities = useMemo(() => getUserActivities(), [refreshKey]);
  const allTrades = useMemo(() => getAllUserTrades(), [refreshKey]);

  const handleToggleBlock = (email: string) => {
    toggleBlockEmail(email);
    soundEffects.playAlertChime();
    setRefreshKey((prev) => prev + 1);
    setActionNotice(`Updated block status for ${email}`);
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleCopyPassword = (pass: string, id: string) => {
    navigator.clipboard.writeText(pass);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Stocks near All-Time Low (ATL <= 10%)
  const atlStocks = useMemo(() => {
    return stocks
      .filter((s) => s.distToAtl !== undefined && s.distToAtl <= 15)
      .sort((a, b) => (a.distToAtl ?? 999) - (b.distToAtl ?? 999));
  }, [stocks]);

  const handleRefresh = () => {
    setRefreshKey((prev) => prev + 1);
    soundEffects.playAlertChime();
    setActionNotice('Refreshed real-time user database and activity records.');
    setTimeout(() => setActionNotice(null), 3000);
  };

  // Filtered Users
  const filteredUsers = useMemo(() => {
    return allUsers.filter((u) => {
      if (!searchQuery) return true;
      const q = searchQuery.toLowerCase();
      return (
        u.name.toLowerCase().includes(q) ||
        u.gmail.toLowerCase().includes(q) ||
        u.id.toLowerCase().includes(q) ||
        u.experience.toLowerCase().includes(q)
      );
    });
  }, [allUsers, searchQuery]);

  // Filtered Trades
  const filteredTrades = useMemo(() => {
    return allTrades.filter((t) => {
      if (selectedUserFilter !== 'ALL' && t.userEmail.toLowerCase() !== selectedUserFilter.toLowerCase()) {
        return false;
      }
      if (!searchQuery) return true;
      const q = searchQuery.toLowerCase();
      return (
        t.symbol.toLowerCase().includes(q) ||
        t.userName.toLowerCase().includes(q) ||
        t.userEmail.toLowerCase().includes(q) ||
        t.outcome.toLowerCase().includes(q)
      );
    });
  }, [allTrades, selectedUserFilter, searchQuery]);

  // Filtered Activities
  const filteredActivities = useMemo(() => {
    return allActivities.filter((a) => {
      if (selectedUserFilter !== 'ALL' && a.userEmail.toLowerCase() !== selectedUserFilter.toLowerCase()) {
        return false;
      }
      if (!searchQuery) return true;
      const q = searchQuery.toLowerCase();
      return (
        a.userName.toLowerCase().includes(q) ||
        a.userEmail.toLowerCase().includes(q) ||
        a.action.toLowerCase().includes(q) ||
        a.details.toLowerCase().includes(q)
      );
    });
  }, [allActivities, selectedUserFilter, searchQuery]);

  // Summary Metrics for Master User
  const totalUserCapital = allUsers.reduce((sum, u) => sum + (u.initialCapital || 0), 0);
  const totalTradesCount = allTrades.length;
  const totalProfitableTrades = allTrades.filter((t) => t.outcome === 'PROFIT').length;
  const platformWinRate = totalTradesCount > 0 
    ? ((totalProfitableTrades / totalTradesCount) * 100).toFixed(1) 
    : '0.0';

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner: Master Privileged Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-950/40 via-[#161b22] to-blue-950/40 border border-amber-500/40 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-wrap items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-white shadow-lg shadow-amber-500/20 border border-amber-300/30">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                  Master Terminal &amp; User Intelligence
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black uppercase tracking-wider bg-amber-400/20 text-amber-300 border border-amber-400/40 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> VIP Master Daksh Hub
                </span>
              </div>
              <p className="text-xs sm:text-sm text-gray-300 mt-1">
                Authorized for <strong>{currentUser.gmail}</strong>. Full live access to community traders, trade histories, logins, and ATL 10% reversal scanners.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleRefresh}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#21262d] border border-[#30363d] text-xs font-semibold text-gray-200 hover:text-white hover:border-amber-400/50 transition-all cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
              <span>Refresh Records</span>
            </button>
          </div>
        </div>

        {/* Action Notice Toast */}
        {actionNotice && (
          <div className="mt-3 p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-xs text-amber-200 flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{actionNotice}</span>
          </div>
        )}

        {/* Global Statistics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
          <div className="p-3 bg-[#0d1117]/80 rounded-xl border border-[#30363d]">
            <div className="text-[11px] text-gray-400 font-semibold uppercase flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-blue-400" />
              Registered Traders
            </div>
            <div className="text-xl font-black text-white mt-1 font-mono">
              {allUsers.length}
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">Tracked with unique IDs</div>
          </div>

          <div className="p-3 bg-[#0d1117]/80 rounded-xl border border-[#30363d]">
            <div className="text-[11px] text-gray-400 font-semibold uppercase flex items-center gap-1">
              <History className="w-3.5 h-3.5 text-emerald-400" />
              Total Logged Trades
            </div>
            <div className="text-xl font-black text-white mt-1 font-mono">
              {totalTradesCount}
            </div>
            <div className="text-[10px] text-emerald-400 mt-0.5">{platformWinRate}% Community Win Rate</div>
          </div>

          <div className="p-3 bg-[#0d1117]/80 rounded-xl border border-[#30363d]">
            <div className="text-[11px] text-gray-400 font-semibold uppercase flex items-center gap-1">
              <DollarSign className="w-3.5 h-3.5 text-purple-400" />
              Active Capital Pool
            </div>
            <div className="text-xl font-black text-white mt-1 font-mono">
              ₹{(totalUserCapital / 100000).toFixed(1)}L
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">Across all virtual accounts</div>
          </div>

          <div className="p-3 bg-[#0d1117]/80 rounded-xl border border-[#30363d]">
            <div className="text-[11px] text-gray-400 font-semibold uppercase flex items-center gap-1">
              <Activity className="w-3.5 h-3.5 text-amber-400" />
              Live Activity Stream
            </div>
            <div className="text-xl font-black text-white mt-1 font-mono">
              {allActivities.length}
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">Events recorded</div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs & Filter Controls */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#21262d] pb-3">
          <div className="flex items-center gap-2 overflow-x-auto">
            <button
              onClick={() => setActiveSubTab('users')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'users'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Registered Accounts ({allUsers.length})
            </button>

            <button
              onClick={() => setActiveSubTab('trades')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'trades'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              User Trades History ({allTrades.length})
            </button>

            <button
              onClick={() => setActiveSubTab('activities')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'activities'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              Live Activity Logs ({allActivities.length})
            </button>

            <button
              onClick={() => setActiveSubTab('atl-scanner')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'atl-scanner'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-emerald-400" />
              VIP ATL 10% Reversal Hub ({atlStocks.length})
            </button>
          </div>

          {/* Search bar */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search user, gmail, symbol..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#161b22] border border-[#30363d] rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 w-52 sm:w-64"
              />
            </div>

            {/* Filter by specific trader email */}
            {(activeSubTab === 'trades' || activeSubTab === 'activities') && (
              <select
                value={selectedUserFilter}
                onChange={(e) => setSelectedUserFilter(e.target.value)}
                className="bg-[#161b22] border border-[#30363d] rounded-xl px-2.5 py-1.5 text-xs text-gray-300 focus:outline-none focus:border-amber-500"
              >
                <option value="ALL">All Traders</option>
                {allUsers.map((u) => (
                  <option key={u.id} value={u.gmail}>
                    {u.name} ({u.gmail})
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>

        {/* SUBTAB 1: REGISTERED USERS */}
        {activeSubTab === 'users' && (
          <div className="space-y-3">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#161b22] text-gray-400 font-semibold border-b border-[#30363d]">
                    <th className="py-2.5 px-3">Trader ID</th>
                    <th className="py-2.5 px-3">Name</th>
                    <th className="py-2.5 px-3">Gmail Address</th>
                    <th className="py-2.5 px-3">Permanent Password</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3 text-right">Capital</th>
                    <th className="py-2.5 px-3 text-right">Risk %</th>
                    <th className="py-2.5 px-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21262d]">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-gray-500">
                        No registered traders match the current query.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((u) => {
                      const isDaksh = u.gmail.toLowerCase() === MASTER_EMAIL.toLowerCase();
                      const isBlocked = isEmailBlocked(u.gmail);
                      const showPass = showPasswordMap[u.id] || false;
                      const userPass = u.password || 'Tr@der2026';

                      return (
                        <tr
                          key={u.id}
                          className={`hover:bg-[#161b22]/70 transition-colors ${
                            isBlocked 
                              ? 'bg-rose-950/20' 
                              : isDaksh 
                              ? 'bg-amber-500/5' 
                              : ''
                          }`}
                        >
                          <td className="py-3 px-3 font-mono text-[11px] text-gray-400">
                            <span className="px-2 py-0.5 rounded bg-[#21262d] border border-[#30363d] text-gray-300">
                              {u.id}
                            </span>
                          </td>
                          <td className="py-3 px-3 font-semibold text-white flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-300 border border-blue-500/40 flex items-center justify-center font-bold text-[10px]">
                              {u.name.charAt(0).toUpperCase()}
                            </div>
                            <span>{u.name}</span>
                            {isDaksh && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                                MASTER
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-3 text-gray-300 font-mono text-[11px]">
                            {u.gmail}
                          </td>
                          <td className="py-3 px-3">
                            <div className="flex items-center gap-1.5 bg-[#090d13] px-2 py-1 rounded border border-[#21262d] max-w-[150px]">
                              <Key className="w-3 h-3 text-amber-400 shrink-0" />
                              <span className="font-mono text-amber-300 font-bold text-[11px] truncate flex-1">
                                {showPass ? userPass : '••••••••'}
                              </span>
                              <button
                                onClick={() => setShowPasswordMap((prev) => ({ ...prev, [u.id]: !prev[u.id] }))}
                                className="p-0.5 text-gray-400 hover:text-white"
                                title={showPass ? 'Hide password' : 'Show permanent password'}
                              >
                                {showPass ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                              </button>
                              <button
                                onClick={() => handleCopyPassword(userPass, u.id)}
                                className="p-0.5 text-gray-400 hover:text-white"
                                title="Copy permanent password"
                              >
                                {copiedId === u.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                              </button>
                            </div>
                          </td>
                          <td className="py-3 px-3">
                            {isBlocked ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1 w-fit">
                                <Ban className="w-2.5 h-2.5" /> Blocked
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 w-fit">
                                <CheckCircle2 className="w-2.5 h-2.5" /> Active
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-3 text-right font-mono font-semibold text-emerald-400">
                            ₹{(u.initialCapital).toLocaleString()}
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-gray-400">
                            {u.riskPerTradePercent}%
                          </td>
                          <td className="py-3 px-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => {
                                  setSelectedUserFilter(u.gmail);
                                  setActiveSubTab('trades');
                                }}
                                className="px-2 py-1 rounded bg-[#21262d] hover:bg-amber-500/20 text-gray-300 hover:text-amber-300 border border-[#30363d] text-[10px] font-semibold transition-all cursor-pointer"
                              >
                                Trades
                              </button>

                              {!isDaksh && (
                                <button
                                  onClick={() => handleToggleBlock(u.gmail)}
                                  className={`px-2 py-1 rounded text-[10px] font-semibold border transition-all cursor-pointer flex items-center gap-1 ${
                                    isBlocked
                                      ? 'bg-emerald-600/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-600/30'
                                      : 'bg-rose-600/20 text-rose-300 border-rose-500/40 hover:bg-rose-600/30'
                                  }`}
                                  title={isBlocked ? 'Unblock user' : 'Block user from website'}
                                >
                                  {isBlocked ? <Unlock className="w-2.5 h-2.5" /> : <Ban className="w-2.5 h-2.5" />}
                                  {isBlocked ? 'Unblock' : 'Block'}
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SUBTAB 2: USER TRADES */}
        {activeSubTab === 'trades' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span>Showing {filteredTrades.length} paper trades logged across traders</span>
              {selectedUserFilter !== 'ALL' && (
                <button
                  onClick={() => setSelectedUserFilter('ALL')}
                  className="text-amber-400 hover:underline cursor-pointer"
                >
                  Clear Trader Filter ({selectedUserFilter})
                </button>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#161b22] text-gray-400 font-semibold border-b border-[#30363d]">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Trader Name &amp; Email</th>
                    <th className="py-2.5 px-3">Stock Symbol</th>
                    <th className="py-2.5 px-3">Side</th>
                    <th className="py-2.5 px-3 text-right">Entry Price</th>
                    <th className="py-2.5 px-3 text-right">Exit Price</th>
                    <th className="py-2.5 px-3 text-right">Qty</th>
                    <th className="py-2.5 px-3 text-right">Net P&amp;L</th>
                    <th className="py-2.5 px-3">Outcome</th>
                    <th className="py-2.5 px-3">Exit Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21262d]">
                  {filteredTrades.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-8 text-center text-gray-500">
                        No trade records found for this filter.
                      </td>
                    </tr>
                  ) : (
                    filteredTrades.map((t) => {
                      const isProfit = t.outcome === 'PROFIT';
                      return (
                        <tr key={t.id} className="hover:bg-[#161b22]/70 transition-colors">
                          <td className="py-3 px-3 text-gray-400 text-[11px] font-mono whitespace-nowrap">
                            {t.exitDate || t.entryDate}
                          </td>
                          <td className="py-3 px-3">
                            <div className="font-semibold text-white">{t.userName}</div>
                            <div className="text-[10px] text-gray-500 font-mono">{t.userEmail}</div>
                          </td>
                          <td className="py-3 px-3 font-bold text-white font-mono flex items-center gap-1.5">
                            <span className="text-amber-400">{t.symbol}</span>
                            <span className="text-[10px] text-gray-400 font-normal">({t.name})</span>
                          </td>
                          <td className="py-3 px-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              t.side === 'BUY'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                            }`}>
                              {t.side}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-gray-300">
                            ₹{t.entryPrice.toLocaleString()}
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-white">
                            ₹{t.exitPrice.toLocaleString()}
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-gray-400">
                            {t.quantity}
                          </td>
                          <td className={`py-3 px-3 text-right font-mono font-bold ${
                            isProfit ? 'text-emerald-400' : 'text-rose-400'
                          }`}>
                            {t.netPnl >= 0 ? '+' : ''}₹{t.netPnl.toLocaleString()}
                            <div className="text-[10px] font-normal">
                              ({t.netPnlPercent >= 0 ? '+' : ''}{t.netPnlPercent.toFixed(2)}%)
                            </div>
                          </td>
                          <td className="py-3 px-3">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              isProfit 
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                            }`}>
                              {t.outcome}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-gray-400 text-[11px]">
                            {t.exitReason}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SUBTAB 3: LIVE ACTIVITIES */}
        {activeSubTab === 'activities' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span>Displaying recent activity timeline</span>
              {selectedUserFilter !== 'ALL' && (
                <button
                  onClick={() => setSelectedUserFilter('ALL')}
                  className="text-amber-400 hover:underline cursor-pointer"
                >
                  Clear Filter ({selectedUserFilter})
                </button>
              )}
            </div>

            <div className="space-y-2">
              {filteredActivities.length === 0 ? (
                <div className="py-8 text-center text-gray-500 text-xs">
                  No activity logs recorded for this criteria.
                </div>
              ) : (
                filteredActivities.map((act) => (
                  <div
                    key={act.id}
                    className="p-3 rounded-xl bg-[#161b22] border border-[#30363d] flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg mt-0.5 ${
                        act.action.includes('BUY')
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : act.action.includes('SELL')
                          ? 'bg-blue-500/20 text-blue-400'
                          : act.action.includes('LOGIN')
                          ? 'bg-amber-500/20 text-amber-400'
                          : 'bg-purple-500/20 text-purple-400'
                      }`}>
                        <Activity className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{act.userName}</span>
                          <span className="text-[10px] text-gray-500 font-mono">({act.userEmail})</span>
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-[#21262d] text-gray-300 border border-[#30363d]">
                            {act.action}
                          </span>
                        </div>
                        <p className="text-gray-300 mt-1 leading-relaxed">
                          {act.details}
                        </p>
                      </div>
                    </div>

                    <div className="text-right text-[11px] text-gray-500 font-mono shrink-0">
                      {new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* SUBTAB 4: VIP ATL 10% SCANNER */}
        {activeSubTab === 'atl-scanner' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/30 to-[#161b22] border border-emerald-500/30 flex items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Flame className="w-4 h-4 text-emerald-400" />
                  VIP All-Time Low (ATL) ≤10% Turnaround Watchlist
                </h3>
                <p className="text-xs text-gray-300 mt-0.5">
                  Identifies deep cyclical turnaround stocks holding firm support within 10% of their historical All-Time Low with Stochastic oversold reversals.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shrink-0">
                {atlStocks.length} Turnaround Setups Found
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {atlStocks.map((stock) => (
                <div
                  key={stock.id}
                  className="p-4 rounded-xl bg-[#161b22] border border-[#30363d] hover:border-emerald-500/50 transition-all flex flex-col justify-between space-y-3"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-black text-white font-mono">{stock.symbol}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                          {stock.distToAtl?.toFixed(1)}% to ATL
                        </span>
                      </div>
                      <span className="text-xs font-bold text-white font-mono">₹{stock.currentPrice}</span>
                    </div>
                    <div className="text-xs text-gray-400 mt-0.5 truncate">{stock.name}</div>
                    
                    <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] font-mono">
                      <div className="p-2 rounded-lg bg-[#0d1117] border border-[#30363d]">
                        <div className="text-gray-500 text-[10px]">All-Time Low</div>
                        <div className="text-emerald-400 font-bold">₹{stock.atl || 'N/A'}</div>
                      </div>
                      <div className="p-2 rounded-lg bg-[#0d1117] border border-[#30363d]">
                        <div className="text-gray-500 text-[10px]">Support EMA</div>
                        <div className="text-blue-400 font-bold">₹{stock.supportEma}</div>
                      </div>
                    </div>

                    <p className="text-[11px] text-gray-300 mt-2 line-clamp-2">
                      {stock.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-[#30363d] flex items-center justify-between">
                    <span className="text-[10px] text-gray-400">
                      Signal: <strong className="text-emerald-400">{stock.stochSignal}</strong>
                    </span>
                    <button
                      onClick={() => {
                        onSelectStock(stock);
                        onNavigateToTab('screener');
                      }}
                      className="flex items-center gap-1 text-xs font-semibold text-emerald-400 hover:text-emerald-300 cursor-pointer"
                    >
                      <span>Chart Setup</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
