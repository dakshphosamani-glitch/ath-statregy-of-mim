import { useState } from 'react';
import { Stock, Watchlist, AlertRule } from '../types';
import { 
  Bell, 
  Plus, 
  Trash2, 
  Star, 
  Sliders, 
  Radio, 
  Volume2, 
  VolumeX, 
  CheckCircle2, 
  AlertCircle, 
  Flame, 
  Layers,
  ArrowUpRight,
  TrendingUp,
  Sparkles
} from 'lucide-react';
import { soundEffects } from '../utils/audioAlert';

interface WatchlistsAndAlertsProps {
  stocks: Stock[];
  watchlists: Watchlist[];
  activeWatchlistId: string;
  onSelectWatchlist: (id: string) => void;
  onCreateWatchlist: (name: string) => void;
  onDeleteWatchlist: (id: string) => void;
  onToggleStockInWatchlist: (stockId: string, watchlistId: string) => void;
  alerts: AlertRule[];
  onCreateAlert: (rule: Omit<AlertRule, 'id' | 'createdAt' | 'triggered'>) => void;
  onDeleteAlert: (id: string) => void;
  onTriggerSimulatedAlert: () => void;
  isSimulatingMarket: boolean;
  onToggleSimulatingMarket: () => void;
  onSelectStock: (stock: Stock) => void;
}

export default function WatchlistsAndAlerts({
  stocks,
  watchlists,
  activeWatchlistId,
  onSelectWatchlist,
  onCreateWatchlist,
  onDeleteWatchlist,
  onToggleStockInWatchlist,
  alerts,
  onCreateAlert,
  onDeleteAlert,
  onTriggerSimulatedAlert,
  isSimulatingMarket,
  onToggleSimulatingMarket,
  onSelectStock,
}: WatchlistsAndAlertsProps) {
  const [newWatchlistName, setNewWatchlistName] = useState('');
  const [isCreatingWatchlist, setIsCreatingWatchlist] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(soundEffects.isEnabled());

  // New alert form state
  const [alertSymbol, setAlertSymbol] = useState(stocks[0]?.symbol || 'AUROPHARMA');
  const [alertType, setAlertType] = useState<AlertRule['type']>('breakout');
  const [customPrice, setCustomPrice] = useState<string>('');

  const activeWatchlist = watchlists.find(w => w.id === activeWatchlistId) || watchlists[0];
  const watchedStocks = stocks.filter(s => activeWatchlist?.symbolIds.includes(s.id));

  const handleCreateWatchlist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWatchlistName.trim()) return;
    onCreateWatchlist(newWatchlistName.trim());
    setNewWatchlistName('');
    setIsCreatingWatchlist(false);
  };

  const handleAddAlert = (e: React.FormEvent) => {
    e.preventDefault();
    const stock = stocks.find(s => s.symbol === alertSymbol);
    if (!stock) return;

    let condition = '';
    let triggerPrice = stock.baseResistance;

    if (alertType === 'breakout') {
      triggerPrice = stock.baseResistance;
      condition = `Price crosses above base resistance ₹${stock.baseResistance}`;
    } else if (alertType === 'near_pivot') {
      triggerPrice = Number((stock.baseResistance * 0.985).toFixed(2));
      condition = `Price enters pre-breakout zone (within 1.5% of ₹${stock.baseResistance})`;
    } else if (alertType === 'ema_support') {
      triggerPrice = stock.supportEma;
      condition = `Price tests 20 EMA dynamic support near ₹${stock.supportEma}`;
    } else if (alertType === 'volume_surge') {
      condition = `Relative volume exceeds 2.0x average on breakout candle`;
    } else if (alertType === 'ath_proximity') {
      condition = `Price approaches within 1.0% of All-Time High (₹${stock.ath})`;
    } else if (alertType === 'stoch_crossover') {
      condition = `Stochastic (14, 3) %K crosses above %D near 20 EMA support`;
    }

    onCreateAlert({
      symbol: stock.symbol,
      type: alertType,
      triggerPrice,
      condition,
      message: `[Alert Setup] ${stock.symbol}: ${condition}`,
    });

    soundEffects.playAlertChime();
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundEffects.setEnabled(next);
    if (next) soundEffects.playAlertChime();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* 1. Watchlists Panel */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl overflow-hidden flex flex-col">
        <div className="p-4 border-b border-[#30363d] bg-[#161b22] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
            <h3 className="text-sm font-bold text-white">Custom Watchlists</h3>
          </div>
          <button
            onClick={() => setIsCreatingWatchlist(!isCreatingWatchlist)}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-lg bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            New List
          </button>
        </div>

        {/* Watchlist Creation Input */}
        {isCreatingWatchlist && (
          <form onSubmit={handleCreateWatchlist} className="p-3 bg-[#161b22]/50 border-b border-[#30363d] flex gap-2">
            <input
              type="text"
              placeholder="e.g. High Tight Flags, NIFTY Breakouts..."
              value={newWatchlistName}
              onChange={(e) => setNewWatchlistName(e.target.value)}
              className="flex-1 bg-[#0d1117] border border-[#30363d] rounded-lg px-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
              autoFocus
            />
            <button
              type="submit"
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 text-white hover:bg-blue-500"
            >
              Save
            </button>
            <button
              type="button"
              onClick={() => setIsCreatingWatchlist(false)}
              className="px-3 py-1.5 text-xs text-gray-400 hover:text-white"
            >
              Cancel
            </button>
          </form>
        )}

        {/* Watchlist Tabs */}
        <div className="flex items-center gap-1.5 p-3 border-b border-[#30363d] bg-[#0d1117] overflow-x-auto text-xs">
          {watchlists.map((wl) => {
            const isSelected = wl.id === activeWatchlistId;
            return (
              <div
                key={wl.id}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
                  isSelected
                    ? 'bg-blue-600/20 text-blue-300 border-blue-500/40 font-semibold'
                    : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                }`}
                onClick={() => onSelectWatchlist(wl.id)}
              >
                <span>{wl.name}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-[#21262d] text-gray-300">
                  {wl.symbolIds.length}
                </span>
                {!wl.isDefault && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteWatchlist(wl.id);
                    }}
                    className="hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Watched Stocks List */}
        <div className="p-3 flex-1 overflow-y-auto space-y-2">
          {watchedStocks.length === 0 ? (
            <div className="py-12 text-center text-xs text-gray-500 space-y-2">
              <Star className="w-6 h-6 text-gray-600 mx-auto" />
              <p>No stocks in this watchlist yet.</p>
              <p className="text-[11px] text-gray-600">Click the star icon next to any stock in the Screener to add it here.</p>
            </div>
          ) : (
            watchedStocks.map((stock) => (
              <div
                key={stock.id}
                onClick={() => onSelectStock(stock)}
                className="flex items-center justify-between p-3 rounded-lg bg-[#161b22] border border-[#30363d] hover:border-blue-500/40 cursor-pointer transition-all group"
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleStockInWatchlist(stock.id, activeWatchlistId);
                    }}
                    className="text-amber-400 hover:text-gray-500 transition-colors"
                    title="Remove from watchlist"
                  >
                    <Star className="w-4 h-4 fill-amber-400" />
                  </button>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white group-hover:text-blue-400 transition-colors">
                        {stock.symbol}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded font-mono bg-[#21262d] text-gray-300">
                        {stock.exchange}
                      </span>
                    </div>
                    <div className="text-[11px] text-gray-400">{stock.name}</div>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <div className="text-white font-semibold">
                    ₹{stock.currentPrice.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </div>
                  <div className={`text-[11px] font-medium ${
                    stock.change >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {stock.change >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%
                  </div>
                </div>

                <div className="text-right">
                  <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded font-mono font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    {stock.distToAth.toFixed(1)}% to ATH
                  </span>
                  <div className="text-[10px] text-gray-400 mt-1">
                    Pivot: ₹{stock.baseResistance}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* 2. Real-Time Alerts System Panel */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl overflow-hidden flex flex-col">
        <div className="p-4 border-b border-[#30363d] bg-[#161b22] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-blue-400" />
            <div>
              <h3 className="text-sm font-bold text-white">Real-Time Alert Dispatcher</h3>
              <p className="text-[11px] text-gray-400">Instant notification when setups cross pivot resistance or 20 EMA</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Audio Toggle */}
            <button
              onClick={toggleSound}
              className={`p-1.5 rounded-lg border transition-colors ${
                soundEnabled
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-[#21262d] text-gray-500 border-[#30363d]'
              }`}
              title={soundEnabled ? 'Alert Chime Sound: ON' : 'Alert Chime Sound: MUTED'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Live Market Simulation Toggle */}
            <button
              onClick={onToggleSimulatingMarket}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-lg border transition-all ${
                isSimulatingMarket
                  ? 'bg-emerald-500 text-black border-emerald-400 animate-pulse'
                  : 'bg-[#21262d] text-gray-300 border-[#30363d] hover:text-white'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              {isSimulatingMarket ? 'Live Market Feed ON' : 'Start Live Feed'}
            </button>
          </div>
        </div>

        {/* Create Alert Form */}
        <form onSubmit={handleAddAlert} className="p-4 bg-[#161b22]/40 border-b border-[#30363d] space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {/* Select Stock */}
            <div>
              <label className="text-[11px] font-semibold text-gray-300 mb-1 block">Target Stock</label>
              <select
                value={alertSymbol}
                onChange={(e) => setAlertSymbol(e.target.value)}
                className="w-full bg-[#0d1117] border border-[#30363d] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                {stocks.map((s) => (
                  <option key={s.id} value={s.symbol}>
                    {s.symbol} (₹{s.currentPrice})
                  </option>
                ))}
              </select>
            </div>

            {/* Select Alert Condition */}
            <div className="sm:col-span-2">
              <label className="text-[11px] font-semibold text-gray-300 mb-1 block">Trigger Condition</label>
              <select
                value={alertType}
                onChange={(e) => setAlertType(e.target.value as any)}
                className="w-full bg-[#0d1117] border border-[#30363d] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="breakout">Breakout: Crosses Base Resistance Pivot</option>
                <option value="near_pivot">Pre-Breakout: Within 1.5% of Resistance</option>
                <option value="ema_support">Support Bounce: Price Tests Rising 20 EMA</option>
                <option value="volume_surge">Volume Surge: Breakout Bar &gt; 2.0x Volume</option>
                <option value="ath_proximity">ATH Climax: Within 1% of All-Time High</option>
                <option value="stoch_crossover">Stochastic Confluence: %K Crosses Above %D</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              type="button"
              onClick={onTriggerSimulatedAlert}
              className="flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Simulate Instant Alert Trigger
            </button>

            <button
              type="submit"
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 text-white hover:bg-blue-500 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              Set Alert Rule
            </button>
          </div>
        </form>

        {/* Active Alerts List */}
        <div className="p-3 flex-1 overflow-y-auto space-y-2">
          {alerts.length === 0 ? (
            <div className="py-12 text-center text-xs text-gray-500 space-y-2">
              <Bell className="w-6 h-6 text-gray-600 mx-auto" />
              <p>No active alert rules configured.</p>
              <p className="text-[11px] text-gray-600">Create rules above to monitor breakout levels automatically.</p>
            </div>
          ) : (
            alerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-3 rounded-lg border transition-all flex items-start justify-between gap-3 ${
                  alert.triggered
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                    : 'bg-[#161b22] border-[#30363d] text-gray-300'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className={`p-1.5 rounded-md mt-0.5 ${
                    alert.triggered ? 'bg-emerald-500/20 text-emerald-400' : 'bg-blue-500/20 text-blue-400'
                  }`}>
                    {alert.triggered ? <CheckCircle2 className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-xs">{alert.symbol}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded font-semibold uppercase bg-[#21262d] text-gray-400 border border-[#30363d]">
                        {alert.type.replace('_', ' ')}
                      </span>
                      {alert.triggered && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                          TRIGGERED {alert.triggeredAt ? `at ${alert.triggeredAt.slice(11, 19)}` : ''}
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-300 mt-1">{alert.condition}</div>
                    <div className="text-[10px] text-gray-500 mt-0.5">Created: {alert.createdAt.slice(0, 10)}</div>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteAlert(alert.id)}
                  className="p-1 rounded text-gray-500 hover:text-rose-400 transition-colors"
                  title="Delete alert"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
