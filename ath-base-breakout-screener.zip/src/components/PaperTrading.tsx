import React, { useState, useEffect, useMemo } from 'react';
import { Stock, PaperPosition, PaperTradeRecord, UserProfile } from '../types';
import { 
  Plus, 
  Clock, 
  ArrowUpRight, 
  ArrowDownRight, 
  RefreshCw, 
  ShieldCheck, 
  Flame, 
  Target, 
  Radio, 
  SlidersHorizontal,
  Wallet,
  CheckCircle2,
  Search,
  Sparkles,
  Info,
  TrendingUp,
  AlertCircle,
  BarChart2,
  ChevronRight,
  Calculator,
  Star
} from 'lucide-react';
import { soundEffects } from '../utils/audioAlert';
import { recordGlobalTrade, recordUserActivity } from '../utils/userRegistry';
import { rankStocksByStrategy, getBestStrategyStock } from '../utils/strategyRanking';

interface PaperTradingProps {
  stocks: Stock[];
  userProfile: UserProfile | null;
  selectedStockSymbol?: string;
  onSelectStockForChart: (symbol: string) => void;
  isSimulatingMarket: boolean;
  onToggleSimulatingMarket: () => void;
}

const LOCAL_STORAGE_KEY_PORTFOLIO = 'breakout_paper_portfolio_v2';
const LOCAL_STORAGE_KEY_TRADES = 'breakout_paper_trades_v2';

export default function PaperTrading({
  stocks,
  userProfile,
  selectedStockSymbol,
  onSelectStockForChart,
  isSimulatingMarket,
  onToggleSimulatingMarket,
}: PaperTradingProps) {
  const initialCash = userProfile?.initialCapital || 1000000;

  // Portfolio cash balance
  const [cashBalance, setCashBalance] = useState<number>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_PORTFOLIO);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return typeof parsed.cash === 'number' ? parsed.cash : initialCash;
      } catch (e) {
        return initialCash;
      }
    }
    return initialCash;
  });

  // Open Positions: Strictly start empty! Do not pre-fill positions automatically.
  const [positions, setPositions] = useState<PaperPosition[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_PORTFOLIO);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.positions)) {
          // Filter out any legacy dummy sample position if present
          return parsed.positions.filter((p: PaperPosition) => !p.id.includes('demo') && p.symbol !== 'CORDEL');
        }
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  // Trade History (Closed Trades): Start clean!
  const [tradeHistory, setTradeHistory] = useState<PaperTradeRecord[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY_TRADES);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter((t: PaperTradeRecord) => t.id !== 'hist-1' && t.id !== 'hist-2');
        }
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  // Stock selection state
  const bestStockEval = useMemo(() => rankStocksByStrategy(stocks)[0], [stocks]);
  const defaultStock = stocks.find((s) => s.symbol === selectedStockSymbol) || bestStockEval?.stock || stocks[0];
  const [orderSymbol, setOrderSymbol] = useState<string>(defaultStock?.symbol || 'RELIANCE');
  const [stockSearchQuery, setStockSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | 'NEAREST' | 'NIFTY50' | 'MIDCAP' | 'DEFENSE'>('ALL');

  // Order Ticket inputs
  const [orderSide, setOrderSide] = useState<'BUY' | 'SHORT'>('BUY');
  const [orderQuantity, setOrderQuantity] = useState<number>(100);
  const [customStopLoss, setCustomStopLoss] = useState<string>('');
  const [customTarget, setCustomTarget] = useState<string>('');
  const [orderNotification, setOrderNotification] = useState<string | null>(null);
  const [adviceAppliedNotification, setAdviceAppliedNotification] = useState<boolean>(false);

  const currentSelectedStock = stocks.find((s) => s.symbol === orderSymbol) || stocks[0];

  // Update selected symbol if parent passes a new one
  useEffect(() => {
    if (selectedStockSymbol && stocks.some((s) => s.symbol === selectedStockSymbol)) {
      setOrderSymbol(selectedStockSymbol);
    }
  }, [selectedStockSymbol, stocks]);

  // Dynamic Trade Setup Advice & Calculations for selected stock
  const advice = useMemo(() => {
    if (!currentSelectedStock) return null;

    const price = currentSelectedStock.currentPrice;
    const ema = currentSelectedStock.supportEma;
    const resistance = currentSelectedStock.baseResistance;
    const ath = currentSelectedStock.ath;
    const distAth = currentSelectedStock.distToAth;

    // Strategy 1 Check: The ATH 10% Strategy (Momentum & Breakout)
    // "The ATH 10% strategy is a momentum and dip-buying approach where you invest or add to positions when a quality asset pulls back roughly 10% from its all-time high (ATH)"
    const isStrategy1Satisfied = distAth <= 10.0;

    // Approach A: Aggressive breakout entry
    // "After a strong candle closes above ₹110, enter around the breakout area rather than buying much later after a large extension.
    // Stop-loss: below the recent higher low / breakout structure (e.g. ₹105-106), rather than arbitrarily putting a tiny stop immediately below ₹110."
    const structuralSl1 = Number((Math.min(ema * 0.985, resistance * 0.96)).toFixed(2));
    const risk1 = Math.max(0.1, Number((price - structuralSl1).toFixed(2)));
    const target1_1 = Number((price + risk1 * 2).toFixed(2));
    const target1_2 = Number((price + risk1 * 3).toFixed(2));
    const shares1 = Math.max(1, Math.floor((cashBalance * 0.02) / risk1));

    // Strategy 2 Check: Stock Momentum & ATL Turnaround (Stochastic Hook)
    const atl = currentSelectedStock.atl || Number((price * 0.42).toFixed(2));
    const distAtl = currentSelectedStock.distToAtl !== undefined 
      ? currentSelectedStock.distToAtl 
      : Number((((price - atl) / atl) * 100).toFixed(2));
    const isStrategy2Satisfied = (distAtl <= 10.0 || (currentSelectedStock.stochK !== undefined && currentSelectedStock.stochK <= 45 && currentSelectedStock.stochSignal === 'Bullish Crossover')) && atl > 0;

    const structuralSl2 = Number((atl * 0.98).toFixed(2));
    const risk2 = Math.max(0.1, Number((price - structuralSl2).toFixed(2)));
    const target2_1 = Number((price * 1.15).toFixed(2));
    const target2_2 = Number((price * 1.30).toFixed(2));
    const shares2 = Math.max(1, Math.floor((cashBalance * 0.02) / risk2));

    const satisfiesBoth = isStrategy1Satisfied && isStrategy2Satisfied;
    const primaryStrategy = isStrategy1Satisfied ? 'STRATEGY_1' : (isStrategy2Satisfied ? 'STRATEGY_2' : 'NONE');

    return {
      isStrategy1Satisfied,
      isStrategy2Satisfied,
      satisfiesBoth,
      primaryStrategy,
      strategy1: {
        name: 'Strategy 1: ATH 10% Momentum & Aggressive Breakout',
        tag: 'ATH 10% Rule',
        verdict: currentSelectedStock.currentPrice >= resistance 
          ? `Aggressive Breakout Entry Active (Closed at ₹${price} above ₹${resistance} Resistance)`
          : `ATH 10% Dip-Buying Setup (${distAth.toFixed(1)}% to ATH, Testing 20 EMA at ₹${ema})`,
        rationale: `The ATH 10% strategy is a momentum and dip-buying approach. Enter around the breakout area (₹${price}) rather than buying after a huge extension. Stop-loss is positioned structurally at ₹${structuralSl1} (below recent consolidation structure / higher low) rather than an arbitrary tight stop immediately below resistance.`,
        entry: price,
        sl: structuralSl1,
        target1: target1_1,
        target2: target1_2,
        riskPercent: Number(((risk1 / price) * 100).toFixed(2)),
        rewardPercent1: Number((((target1_1 - price) / price) * 100).toFixed(2)),
        rrRatio: '1 : 2.0',
        shares: shares1,
        capital: shares1 * price,
      },
      strategy2: {
        name: 'Strategy 2: Stock Momentum & ATL Turnaround (Stochastic Hook)',
        tag: 'ATL 10% Rule',
        verdict: `Oversold Momentum Turnaround (Historical ATL: ₹${atl}, Dist: ${distAtl.toFixed(1)}%)`,
        rationale: `Asset has pulled back to within 10% of historical All-Time Low (ATL: ₹${atl}) or Stochastic (%K: ${currentSelectedStock.stochK || 35}) generated a bullish turnaround hook. Structural stop-loss is placed at ₹${structuralSl2} directly below the multi-year ATL floor.`,
        entry: price,
        sl: structuralSl2,
        target1: target2_1,
        target2: target2_2,
        riskPercent: Number(((risk2 / price) * 100).toFixed(2)),
        rewardPercent1: Number((((target2_1 - price) / price) * 100).toFixed(2)),
        rrRatio: '1 : 2.5',
        shares: shares2,
        capital: shares2 * price,
      },
      // Generic fallback fields for backward compatibility
      suggestedEntry: price,
      suggestedSl: isStrategy1Satisfied ? structuralSl1 : structuralSl2,
      suggestedTarget1: isStrategy1Satisfied ? target1_1 : target2_1,
      suggestedTarget2: isStrategy1Satisfied ? target1_2 : target2_2,
      riskPerShare: isStrategy1Satisfied ? risk1 : risk2,
      riskPercent: isStrategy1Satisfied ? Number(((risk1 / price) * 100).toFixed(2)) : Number(((risk2 / price) * 100).toFixed(2)),
      rewardPercent1: isStrategy1Satisfied ? Number((((target1_1 - price) / price) * 100).toFixed(2)) : Number((((target2_1 - price) / price) * 100).toFixed(2)),
      rrRatio: '1 : 2.0',
      advisedShares: isStrategy1Satisfied ? shares1 : shares2,
      advisedCapitalRequired: (isStrategy1Satisfied ? shares1 : shares2) * price,
      verdict: isStrategy1Satisfied ? 'ATH 10% Strategy Triggered' : (isStrategy2Satisfied ? 'ATL Turnaround Triggered' : 'No Strategy Triggered'),
      rationale: isStrategy1Satisfied
        ? `Consolidating within ${distAth.toFixed(1)}% of ATH with 20 EMA cushion at ₹${ema}.`
        : `Turnaround candidate near ATL (₹${atl}).`,
    };
  }, [currentSelectedStock, cashBalance]);

  // Filtered NSE stocks for selection
  const filteredStocksList = useMemo(() => {
    return stocks.filter((stock) => {
      // Category filter
      if (categoryFilter === 'NEAREST' && stock.distToAth > 3.5) return false;
      if (categoryFilter === 'NIFTY50' && !['RELIANCE', 'TCS', 'HDFCBANK', 'ICICIBANK', 'INFY', 'BHARTIARTL', 'ITC', 'LT', 'SBIN', 'SUNPHARMA', 'MARUTI', 'NTPC'].includes(stock.symbol)) {
        return false;
      }
      if (categoryFilter === 'DEFENSE' && !['HAL', 'BEL', 'MAZDOCK', 'COCHINSHIP', 'BDL', 'RVNL', 'IRFC', 'TITAGARH'].includes(stock.symbol)) {
        return false;
      }
      if (categoryFilter === 'MIDCAP' && (stock.currentPrice > 15000 || stock.type === 'index')) {
        return false;
      }

      // Search query filter
      if (stockSearchQuery) {
        const query = stockSearchQuery.toLowerCase();
        return (
          stock.symbol.toLowerCase().includes(query) ||
          stock.name.toLowerCase().includes(query) ||
          (stock.sector && stock.sector.toLowerCase().includes(query))
        );
      }
      return true;
    });
  }, [stocks, categoryFilter, stockSearchQuery]);

  // Set default SL and Target into form when user changes stock
  useEffect(() => {
    if (advice) {
      setCustomStopLoss(String(advice.suggestedSl));
      setCustomTarget(String(advice.suggestedTarget1));
    }
  }, [currentSelectedStock?.symbol]);

  // Apply Advice values to the order ticket with one click
  const handleApplyAdvice = () => {
    if (!advice) return;
    setCustomStopLoss(String(advice.suggestedSl));
    setCustomTarget(String(advice.suggestedTarget1));
    setOrderQuantity(advice.advisedShares);
    setAdviceAppliedNotification(true);
    setTimeout(() => setAdviceAppliedNotification(false), 2500);
  };

  const handleApplyStrategy = (stratType: 'STRATEGY_1' | 'STRATEGY_2') => {
    if (!advice) return;
    const strat = stratType === 'STRATEGY_1' ? advice.strategy1 : advice.strategy2;
    setCustomStopLoss(String(strat.sl));
    setCustomTarget(String(strat.target1));
    setOrderQuantity(strat.shares);
    setAdviceAppliedNotification(true);
    setTimeout(() => setAdviceAppliedNotification(false), 2500);
  };

  // Keep open positions updated with latest live prices
  useEffect(() => {
    setPositions((prevPositions) => {
      let changed = false;
      const updated = prevPositions.map((pos) => {
        const liveStock = stocks.find((s) => s.symbol === pos.symbol);
        if (!liveStock) return pos;

        const livePrice = liveStock.currentPrice;
        if (livePrice !== pos.currentPrice) {
          changed = true;
          const diff = pos.side === 'BUY' ? livePrice - pos.entryPrice : pos.entryPrice - livePrice;
          const pnl = Number((diff * pos.quantity).toFixed(2));
          const pnlPct = Number(((diff / pos.entryPrice) * 100).toFixed(2));

          return {
            ...pos,
            currentPrice: livePrice,
            unrealizedPnl: pnl,
            unrealizedPnlPercent: pnlPct,
          };
        }
        return pos;
      });

      return changed ? updated : prevPositions;
    });
  }, [stocks]);

  // Save portfolio state to localStorage
  useEffect(() => {
    localStorage.setItem(
      LOCAL_STORAGE_KEY_PORTFOLIO,
      JSON.stringify({ cash: cashBalance, positions })
    );
  }, [cashBalance, positions]);

  // Save trade history to localStorage
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY_TRADES, JSON.stringify(tradeHistory));
  }, [tradeHistory]);

  // Calculations
  const totalInvestedInPositions = positions.reduce((acc, p) => acc + p.investedAmount, 0);
  const totalUnrealizedPnl = positions.reduce((acc, p) => acc + p.unrealizedPnl, 0);
  const totalEquity = cashBalance + totalInvestedInPositions + totalUnrealizedPnl;
  const totalRealizedPnl = tradeHistory.reduce((acc, t) => acc + t.netPnl, 0);
  const winningTradesCount = tradeHistory.filter((t) => t.outcome === 'PROFIT').length;
  const winRate = tradeHistory.length > 0 ? ((winningTradesCount / tradeHistory.length) * 100).toFixed(1) : '0.0';

  // Handle Order Execution
  const handleExecuteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentSelectedStock) return;

    const entryPrice = currentSelectedStock.currentPrice;
    const requiredCapital = entryPrice * orderQuantity;

    if (requiredCapital > cashBalance) {
      setOrderNotification(`Insufficient cash balance! Required: ₹${requiredCapital.toLocaleString()}, Available: ₹${cashBalance.toLocaleString()}`);
      setTimeout(() => setOrderNotification(null), 4000);
      return;
    }

    const sl = customStopLoss ? Number(customStopLoss) : (advice?.suggestedSl || currentSelectedStock.supportEma);
    const tp = customTarget ? Number(customTarget) : (advice?.suggestedTarget1 || Number((entryPrice * 1.08).toFixed(2)));

    const newPosition: PaperPosition = {
      id: `pos-${Date.now()}`,
      symbol: currentSelectedStock.symbol,
      name: currentSelectedStock.name,
      side: orderSide,
      entryPrice,
      currentPrice: entryPrice,
      quantity: orderQuantity,
      stopLoss: sl,
      targetPrice: tp,
      entryDate: new Date().toISOString().replace('T', ' ').slice(0, 16),
      unrealizedPnl: 0,
      unrealizedPnlPercent: 0,
      investedAmount: requiredCapital,
      setupNote: `10% ATH Strategy setup (${currentSelectedStock.distToAth}% from ATH) near ₹${currentSelectedStock.baseResistance} pivot`,
    };

    setCashBalance((prev) => prev - requiredCapital);
    setPositions((prev) => [newPosition, ...prev]);
    soundEffects.playAlertChime();

    // Record user activity in persistent registry
    recordUserActivity(
      userProfile,
      orderSide === 'BUY' ? 'PAPER_TRADE_BUY' : 'PAPER_TRADE_SELL',
      `Placed ${orderSide} order for ${orderQuantity} shares of ${currentSelectedStock.symbol} at ₹${entryPrice} (Invested ₹${requiredCapital.toLocaleString()})`
    );

    setOrderNotification(`Paper Order Executed: ${orderSide} ${orderQuantity} shares of ${currentSelectedStock.symbol} at ₹${entryPrice}`);
    setTimeout(() => setOrderNotification(null), 4000);
  };

  // Close / Exit an open position
  const handleClosePosition = (positionId: string, reason: PaperTradeRecord['exitReason'] = 'Manual Exit') => {
    const pos = positions.find((p) => p.id === positionId);
    if (!pos) return;

    const exitPrice = pos.currentPrice;
    const returnedCash = pos.investedAmount + pos.unrealizedPnl;

    const record: PaperTradeRecord = {
      id: `trade-${Date.now()}`,
      symbol: pos.symbol,
      name: pos.name,
      side: pos.side,
      entryPrice: pos.entryPrice,
      exitPrice,
      quantity: pos.quantity,
      entryDate: pos.entryDate,
      exitDate: new Date().toISOString().replace('T', ' ').slice(0, 16),
      netPnl: pos.unrealizedPnl,
      netPnlPercent: pos.unrealizedPnlPercent,
      outcome: pos.unrealizedPnl >= 0 ? 'PROFIT' : 'LOSS',
      exitReason: reason,
    };

    setCashBalance((prev) => prev + returnedCash);
    setPositions((prev) => prev.filter((p) => p.id !== positionId));
    setTradeHistory((prev) => [record, ...prev]);
    soundEffects.playAlertChime();

    // Record in global trade registry (for Master Supervisor Daksh surveillance)
    recordGlobalTrade(userProfile, record);
    recordUserActivity(
      userProfile,
      'PAPER_TRADE_SELL',
      `Closed ${pos.side} on ${pos.symbol}: Exit ₹${exitPrice}, PnL: ₹${pos.unrealizedPnl.toLocaleString()} (${pos.unrealizedPnlPercent.toFixed(2)}%) [${record.outcome}]`
    );
  };

  // Square off all active positions
  const handleSquareOffAll = () => {
    if (positions.length === 0) return;
    if (window.confirm(`Close all ${positions.length} open position(s) at current market prices?`)) {
      positions.forEach((pos) => {
        handleClosePosition(pos.id, 'Manual Exit');
      });
    }
  };

  // Reset Account back to Initial Capital
  const handleResetAccount = () => {
    if (window.confirm('Reset Paper Trading Account back to starting virtual capital and clear all positions and history?')) {
      setCashBalance(initialCash);
      setPositions([]);
      setTradeHistory([]);
      localStorage.removeItem(LOCAL_STORAGE_KEY_PORTFOLIO);
      localStorage.removeItem(LOCAL_STORAGE_KEY_TRADES);
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Account Summary & Live Telemetry Banner */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#21262d]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-cyan-500 flex items-center justify-center text-white shadow-md">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">NSE Real-Time Paper Trading Portfolio</h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  Risk-Free Simulator
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-blue-500/15 text-blue-400 border border-blue-500/30">
                  {stocks.length} NSE Stocks Available
                </span>
              </div>
              <p className="text-xs text-gray-400">
                System provides strategy advice &amp; sizing. You retain full control over placing every trade manually.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onToggleSimulatingMarket}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                isSimulatingMarket
                  ? 'bg-emerald-500 text-black border-emerald-400 animate-pulse'
                  : 'bg-[#161b22] text-gray-300 border-[#30363d] hover:text-white'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              {isSimulatingMarket ? 'Live Market Ticks Active' : 'Start Live Price Ticks'}
            </button>

            <button
              onClick={handleResetAccount}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-rose-400 hover:border-rose-500/30 transition-colors cursor-pointer"
              title="Reset account to starting capital"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Reset Account
            </button>
          </div>
        </div>

        {/* Telemetry Metric Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 pt-4">
          {/* Total Equity */}
          <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3">
            <div className="text-[11px] text-gray-400 font-medium">Total Portfolio Equity</div>
            <div className="text-base sm:text-lg font-bold font-mono text-white mt-1">
              ₹{totalEquity.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">Cash + Open Positions</div>
          </div>

          {/* Cash Available */}
          <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3">
            <div className="text-[11px] text-gray-400 font-medium">Available Cash</div>
            <div className="text-base sm:text-lg font-bold font-mono text-emerald-400 mt-1">
              ₹{cashBalance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">Free Buying Power</div>
          </div>

          {/* Invested Capital */}
          <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3">
            <div className="text-[11px] text-gray-400 font-medium">Invested in Trades</div>
            <div className="text-base sm:text-lg font-bold font-mono text-blue-400 mt-1">
              ₹{totalInvestedInPositions.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">{positions.length} Active Positions</div>
          </div>

          {/* Unrealized P&L */}
          <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3">
            <div className="text-[11px] text-gray-400 font-medium">Live Floating P&amp;L</div>
            <div className={`text-base sm:text-lg font-bold font-mono mt-1 ${
              totalUnrealizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}>
              {totalUnrealizedPnl >= 0 ? '+' : ''}₹{totalUnrealizedPnl.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">Real-time open gains</div>
          </div>

          {/* Realized P&L */}
          <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3">
            <div className="text-[11px] text-gray-400 font-medium">Closed Trades P&amp;L</div>
            <div className={`text-base sm:text-lg font-bold font-mono mt-1 ${
              totalRealizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}>
              {totalRealizedPnl >= 0 ? '+' : ''}₹{totalRealizedPnl.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">Realized net returns</div>
          </div>

          {/* Win Rate */}
          <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3">
            <div className="text-[11px] text-gray-400 font-medium">Win Rate</div>
            <div className="text-base sm:text-lg font-bold font-mono text-purple-400 mt-1">
              {winRate}%
            </div>
            <div className="text-[10px] text-gray-500 mt-0.5">
              {winningTradesCount}W / {tradeHistory.length - winningTradesCount}L ({tradeHistory.length} closed)
            </div>
          </div>
        </div>
      </div>

      {/* Execution feedback toast */}
      {orderNotification && (
        <div className="bg-emerald-500/10 border border-emerald-500/40 rounded-xl p-3 flex items-center justify-between text-emerald-300 text-xs shadow-md">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">{orderNotification}</span>
          </div>
          <span className="text-[10px] text-emerald-400/80 font-mono">Recorded in Active Positions</span>
        </div>
      )}

      {/* 2. Strategy Advice Panel + Order Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN (7 Cols): Stock Selector & Strategy Advice Engine */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Best Chosen Stock of the Day Daily Quick Select */}
          {bestStockEval?.stock && (
            <div className="bg-gradient-to-r from-emerald-950/40 via-[#161b22] to-blue-950/30 border border-emerald-500/40 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-lg">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-md">
                  <Star className="w-5 h-5 fill-emerald-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] px-2 py-0.5 rounded font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      ⭐ Best Strategy Match
                    </span>
                    <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/30">
                      {bestStockEval.badgeLabel}
                    </span>
                    <span className="text-[10px] font-mono text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/30 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> [D] 15m Real Data
                    </span>
                  </div>
                  <div className="text-sm font-bold text-white mt-1">
                    {bestStockEval.stock.symbol} — {bestStockEval.stock.name}
                  </div>
                  <div className="text-xs text-gray-300 flex items-center gap-2 mt-0.5 font-mono">
                    <span className="text-white font-bold">₹{bestStockEval.stock.currentPrice.toLocaleString()}</span>
                    <span className={`font-semibold ${bestStockEval.stock.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {bestStockEval.stock.changePercent >= 0 ? '+' : ''}{bestStockEval.stock.changePercent.toFixed(2)}%
                    </span>
                    <span className="text-gray-400">| Pivot: ₹{bestStockEval.stock.baseResistance} | 20 EMA: ₹{bestStockEval.stock.supportEma}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setOrderSymbol(bestStockEval.stock.symbol)}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-md shadow-emerald-900/40 cursor-pointer flex items-center gap-1.5"
                >
                  <span>Select &amp; Trade</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => onSelectStockForChart(bestStockEval.stock.symbol)}
                  className="p-2 rounded-xl bg-[#161b22] hover:bg-[#21262d] border border-[#30363d] text-gray-300 hover:text-white transition-colors cursor-pointer"
                  title="Inspect Real Delayed Candlestick Chart"
                >
                  <BarChart2 className="w-4 h-4 text-cyan-400" />
                </button>
              </div>
            </div>
          )}

          {/* Stock Search & Filter Bar */}
          <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-blue-400" />
                <h3 className="text-sm font-bold text-white">Select Any NSE Stock</h3>
              </div>
              <span className="text-xs text-gray-400 font-mono">
                Showing {filteredStocksList.length} of {stocks.length} stocks
              </span>
            </div>

            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                placeholder="Search by NSE symbol or name (e.g. RELIANCE, TRENT, HAL, CDSL, DIXON)..."
                value={stockSearchQuery}
                onChange={(e) => setStockSearchQuery(e.target.value)}
                className="w-full bg-[#161b22] border border-[#30363d] rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
              />
              <Search className="w-3.5 h-3.5 text-gray-500 absolute left-3 top-2.5" />
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[
                { id: 'ALL', label: `All NSE Stocks (${stocks.length})` },
                { id: 'NEAREST', label: 'Nearest to ATH (≤3.5%)' },
                { id: 'NIFTY50', label: 'Nifty 50 Giants' },
                { id: 'DEFENSE', label: 'Defense & Rail Momentum' },
                { id: 'MIDCAP', label: 'Fast Midcaps' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setCategoryFilter(tab.id as any)}
                  className={`px-2.5 py-1 text-[11px] font-medium rounded-lg border transition-all cursor-pointer ${
                    categoryFilter === tab.id
                      ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                      : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white hover:border-gray-500'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Quick Stock Selector Dropdown */}
            <div>
              <label className="text-[11px] font-semibold text-gray-400 block mb-1">
                Active Setup Target:
              </label>
              <select
                value={orderSymbol}
                onChange={(e) => setOrderSymbol(e.target.value)}
                className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
              >
                {filteredStocksList.map((stock) => (
                  <option key={stock.id} value={stock.symbol}>
                    {stock.symbol} — ₹{stock.currentPrice} | ATH -{stock.distToAth}% | {stock.sector || 'NSE'} {stock.isDelayed ? '[D 15m]' : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* DUAL STRATEGY ADVICE ENGINE */}
          {currentSelectedStock && advice && (
            <div className="space-y-4">
              
              {/* Dual Strategy Confluence Banner when BOTH are satisfied */}
              {advice.satisfiesBoth && (
                <div className="bg-gradient-to-r from-purple-950/50 via-[#161b22] to-blue-950/50 border border-purple-500/50 rounded-2xl p-4 shadow-xl">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/40">
                      <Sparkles className="w-4 h-4 text-purple-300" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-2">
                        <span>⚡ Dual Strategy Confluence Satisfied!</span>
                        <span className="text-[10px] px-2 py-0.5 rounded font-mono bg-purple-500/20 text-purple-300 border border-purple-500/40">
                          Both Strategies Active
                        </span>
                      </div>
                      <p className="text-xs text-gray-300 mt-0.5">
                        <strong className="text-purple-300">{currentSelectedStock.symbol}</strong> satisfies both Strategy 1 (ATH 10% Breakout) and Strategy 2 (Momentum &amp; ATL Turnaround). Choose which entry parameters to apply below.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* CARD 1: Strategy 1 (ATH 10% Momentum & Aggressive Breakout) */}
              {advice.isStrategy1Satisfied && (
                <div className="bg-[#0d1117] border border-blue-500/40 rounded-2xl overflow-hidden shadow-xl">
                  <div className="p-4 bg-gradient-to-r from-blue-950/40 via-[#161b22] to-cyan-950/30 border-b border-[#30363d] flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-500/40">
                        {advice.strategy1.tag}
                      </span>
                      <h3 className="text-xs font-bold text-white">
                        {advice.strategy1.name}
                      </h3>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                      ATH Proximity: -{currentSelectedStock.distToAth}%
                    </span>
                  </div>

                  <div className="p-5 space-y-4">
                    {/* Strategy Rationale */}
                    <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3.5 space-y-1.5">
                      <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                        <TrendingUp className="w-3.5 h-3.5" />
                        <span>{advice.strategy1.verdict}</span>
                      </div>
                      <p className="text-xs text-gray-300 leading-relaxed">
                        {advice.strategy1.rationale}
                      </p>
                    </div>

                    {/* Technical Levels Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
                      <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-2.5">
                        <div className="text-[10px] text-gray-400 font-sans">Current Price</div>
                        <div className="text-sm font-bold text-white mt-0.5">₹{currentSelectedStock.currentPrice}</div>
                        <div className="text-[10px] text-emerald-400 mt-0.5">{currentSelectedStock.changePercent >= 0 ? '+' : ''}{currentSelectedStock.changePercent}%</div>
                      </div>
                      <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-2.5">
                        <div className="text-[10px] text-gray-400 font-sans">20 EMA Floor</div>
                        <div className="text-sm font-bold text-emerald-400 mt-0.5">₹{currentSelectedStock.supportEma}</div>
                        <div className="text-[10px] text-gray-500 mt-0.5">Dynamic Baseline</div>
                      </div>
                      <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-2.5">
                        <div className="text-[10px] text-gray-400 font-sans">Base Resistance</div>
                        <div className="text-sm font-bold text-cyan-400 mt-0.5">₹{currentSelectedStock.baseResistance}</div>
                        <div className="text-[10px] text-gray-500 mt-0.5">Breakout Level</div>
                      </div>
                      <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-2.5">
                        <div className="text-[10px] text-gray-400 font-sans">ATH (All-Time High)</div>
                        <div className="text-sm font-bold text-amber-400 mt-0.5">₹{currentSelectedStock.ath}</div>
                        <div className="text-[10px] text-amber-400/80 mt-0.5">{currentSelectedStock.distToAth}% below</div>
                      </div>
                    </div>

                    {/* Parameters Table */}
                    <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3.5 space-y-3">
                      <div className="flex items-center justify-between text-xs pb-2 border-b border-[#30363d]">
                        <span className="font-semibold text-gray-300 flex items-center gap-1.5">
                          <Target className="w-3.5 h-3.5 text-blue-400" />
                          Strategy 1 Executable Parameters
                        </span>
                        <span className="text-[11px] font-mono text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/30">
                          Risk/Reward: {advice.strategy1.rrRatio}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-3 text-xs font-mono">
                        <div>
                          <span className="text-[10px] text-gray-400 block font-sans">Breakout Entry</span>
                          <span className="text-white font-bold">₹{advice.strategy1.entry}</span>
                          <span className="text-[10px] text-gray-500 block">At breakout close</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-rose-400 block font-sans">Structural Stop Loss</span>
                          <span className="text-rose-400 font-bold">₹{advice.strategy1.sl}</span>
                          <span className="text-[10px] text-rose-400/70 block">-{advice.strategy1.riskPercent}% (below base)</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-emerald-400 block font-sans">Target 1 (1:2 RR)</span>
                          <span className="text-emerald-400 font-bold">₹{advice.strategy1.target1}</span>
                          <span className="text-[10px] text-emerald-400/70 block">+{advice.strategy1.rewardPercent1}%</span>
                        </div>
                      </div>

                      {/* Position Sizing Advice */}
                      <div className="bg-[#0d1117] border border-blue-500/20 rounded-lg p-2.5 flex items-start gap-2.5 text-xs">
                        <Calculator className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-gray-200 font-medium">Calculated Position Sizing (2% Rule): </span>
                          <span className="text-blue-300 font-mono font-semibold">{advice.strategy1.shares} shares</span>
                          <span className="text-gray-400"> (₹{advice.strategy1.capital.toLocaleString('en-IN', { maximumFractionDigits: 0 })} capital allocated).</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Button */}
                    <button
                      type="button"
                      onClick={() => handleApplyStrategy('STRATEGY_1')}
                      className="w-full py-2.5 px-4 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/50 hover:border-blue-400 text-blue-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-[0.99]"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>Apply Strategy 1 (ATH 10% Breakout) Parameters to Ticket</span>
                    </button>
                  </div>
                </div>
              )}

              {/* CARD 2: Strategy 2 (Stock Momentum & ATL 10% Turnaround / Stoch Hook) */}
              {advice.isStrategy2Satisfied && (
                <div className="bg-[#0d1117] border border-purple-500/40 rounded-2xl overflow-hidden shadow-xl">
                  <div className="p-4 bg-gradient-to-r from-purple-950/40 via-[#161b22] to-indigo-950/30 border-b border-[#30363d] flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/40">
                        {advice.strategy2.tag}
                      </span>
                      <h3 className="text-xs font-bold text-white">
                        {advice.strategy2.name}
                      </h3>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-purple-500/15 text-purple-300 border border-purple-500/30">
                      ATL Turnaround Floor
                    </span>
                  </div>

                  <div className="p-5 space-y-4">
                    {/* Strategy Rationale */}
                    <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3.5 space-y-1.5">
                      <div className="flex items-center gap-2 text-xs font-semibold text-purple-400">
                        <TrendingUp className="w-3.5 h-3.5" />
                        <span>{advice.strategy2.verdict}</span>
                      </div>
                      <p className="text-xs text-gray-300 leading-relaxed">
                        {advice.strategy2.rationale}
                      </p>
                    </div>

                    {/* Parameters Table */}
                    <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3.5 space-y-3">
                      <div className="flex items-center justify-between text-xs pb-2 border-b border-[#30363d]">
                        <span className="font-semibold text-gray-300 flex items-center gap-1.5">
                          <Target className="w-3.5 h-3.5 text-purple-400" />
                          Strategy 2 Executable Parameters
                        </span>
                        <span className="text-[11px] font-mono text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/30">
                          Risk/Reward: {advice.strategy2.rrRatio}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-3 text-xs font-mono">
                        <div>
                          <span className="text-[10px] text-gray-400 block font-sans">Turnaround Entry</span>
                          <span className="text-white font-bold">₹{advice.strategy2.entry}</span>
                          <span className="text-[10px] text-gray-500 block">At oversold hook</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-rose-400 block font-sans">Structural Stop Loss</span>
                          <span className="text-rose-400 font-bold">₹{advice.strategy2.sl}</span>
                          <span className="text-[10px] text-rose-400/70 block">Below ATL floor</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-emerald-400 block font-sans">Target 1</span>
                          <span className="text-emerald-400 font-bold">₹{advice.strategy2.target1}</span>
                          <span className="text-[10px] text-emerald-400/70 block">+{advice.strategy2.rewardPercent1}%</span>
                        </div>
                      </div>

                      {/* Position Sizing Advice */}
                      <div className="bg-[#0d1117] border border-purple-500/20 rounded-lg p-2.5 flex items-start gap-2.5 text-xs">
                        <Calculator className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-gray-200 font-medium">Calculated Position Sizing (2% Rule): </span>
                          <span className="text-purple-300 font-mono font-semibold">{advice.strategy2.shares} shares</span>
                          <span className="text-gray-400"> (₹{advice.strategy2.capital.toLocaleString('en-IN', { maximumFractionDigits: 0 })} capital allocated).</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Button */}
                    <button
                      type="button"
                      onClick={() => handleApplyStrategy('STRATEGY_2')}
                      className="w-full py-2.5 px-4 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/50 hover:border-purple-400 text-purple-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-[0.99]"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>Apply Strategy 2 (ATL Turnaround) Parameters to Ticket</span>
                    </button>
                  </div>
                </div>
              )}

              {/* CARD 3: Neither Strategy Satisfied */}
              {!advice.isStrategy1Satisfied && !advice.isStrategy2Satisfied && (
                <div className="bg-[#161b22] border border-amber-500/30 rounded-2xl p-5 text-xs space-y-2">
                  <div className="flex items-center gap-2 text-amber-400 font-bold">
                    <AlertCircle className="w-4 h-4" />
                    <span>Neither Strategy Condition Currently Satisfied for {currentSelectedStock.symbol}</span>
                  </div>
                  <p className="text-gray-300 leading-relaxed">
                    Strategy 1 requires proximity within 10% of All-Time High (current distance: <strong>{currentSelectedStock.distToAth}%</strong>). Strategy 2 requires proximity to historical ATL or an oversold Stochastic cross.
                  </p>
                  <p className="text-gray-400">
                    Consider monitoring <strong>{bestStockEval?.stock?.symbol || 'screened leaders'}</strong> or another top asset that strictly satisfies the 10% proximity mandate.
                  </p>
                </div>
              )}

              {/* Chart inspection button */}
              <div className="flex items-center justify-between gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => onSelectStockForChart(currentSelectedStock.symbol)}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#161b22] hover:bg-[#21262d] border border-[#30363d] text-gray-300 hover:text-white text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <BarChart2 className="w-4 h-4 text-cyan-400" />
                  <span>Inspect {currentSelectedStock.symbol} Real Candlestick Chart</span>
                </button>
              </div>

              {adviceAppliedNotification && (
                <div className="text-xs text-emerald-400 font-medium flex items-center gap-1.5 justify-center animate-pulse bg-emerald-500/10 py-2 rounded-xl border border-emerald-500/30">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Strategy parameters copied to order ticket! Review and submit on the right.</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* RIGHT COLUMN (5 Cols): Order Execution Form Ticket */}
        <div className="lg:col-span-5">
          <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl overflow-hidden shadow-lg sticky top-4">
            <div className="p-4 bg-[#161b22] border-b border-[#30363d] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-white">Manual Paper Order Ticket</h3>
              </div>
              <span className="text-[10px] font-mono text-gray-400 px-2 py-0.5 rounded bg-[#21262d] border border-[#30363d]">
                Zero Risk Execution
              </span>
            </div>

            <form onSubmit={handleExecuteOrder} className="p-5 space-y-4">
              {/* Target Symbol Summary */}
              <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-gray-400 block">Selected NSE Symbol</span>
                  <span className="text-base font-bold text-white font-mono">{currentSelectedStock?.symbol}</span>
                  <span className="text-[10px] text-gray-400 block truncate max-w-[170px]">{currentSelectedStock?.name}</span>
                </div>
                <div className="text-right font-mono">
                  <span className="text-[10px] text-gray-400 block">Execution Price</span>
                  <span className="text-base font-bold text-white">₹{currentSelectedStock?.currentPrice}</span>
                  <span className={`text-[10px] font-semibold block ${currentSelectedStock?.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {currentSelectedStock?.changePercent >= 0 ? '+' : ''}{currentSelectedStock?.changePercent}%
                  </span>
                </div>
              </div>

              {/* Order Side Toggle (BUY vs SHORT) */}
              <div>
                <label className="text-xs font-semibold text-gray-300 block mb-1">Position Side</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setOrderSide('BUY')}
                    className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      orderSide === 'BUY'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500 shadow-sm'
                        : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                    }`}
                  >
                    BUY (Breakout Long)
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderSide('SHORT')}
                    className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      orderSide === 'SHORT'
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500 shadow-sm'
                        : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                    }`}
                  >
                    SHORT (Breakdown)
                  </button>
                </div>
              </div>

              {/* Quantity */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-gray-300">Share Quantity</label>
                  <span className="text-[11px] font-mono text-gray-400">
                    Trade Value: ₹{((currentSelectedStock?.currentPrice || 0) * orderQuantity).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </span>
                </div>
                <input
                  type="number"
                  min={1}
                  step={10}
                  value={orderQuantity}
                  onChange={(e) => setOrderQuantity(Math.max(1, Number(e.target.value)))}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                />

                {/* Quick Size Percentage Buttons */}
                <div className="grid grid-cols-4 gap-1.5 mt-1.5">
                  {[10, 25, 50, 100].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => {
                        if (!currentSelectedStock) return;
                        const maxCashForTrade = cashBalance * (pct / 100);
                        const qty = Math.max(1, Math.floor(maxCashForTrade / currentSelectedStock.currentPrice));
                        setOrderQuantity(qty);
                      }}
                      className="py-1 text-[10px] font-mono font-medium rounded-lg bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white hover:border-gray-500 transition-colors cursor-pointer"
                    >
                      {pct}% Cash
                    </button>
                  ))}
                </div>
              </div>

              {/* Stop Loss & Target Inputs */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-rose-400 block mb-1">Stop Loss (₹)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={customStopLoss}
                    onChange={(e) => setCustomStopLoss(e.target.value)}
                    className="w-full bg-[#161b22] border border-rose-500/40 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-400 font-mono"
                  />
                  <span className="text-[10px] text-gray-500 mt-0.5 block">20 EMA: ₹{currentSelectedStock?.supportEma}</span>
                </div>

                <div>
                  <label className="text-xs font-semibold text-emerald-400 block mb-1">Target Price (₹)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={customTarget}
                    onChange={(e) => setCustomTarget(e.target.value)}
                    className="w-full bg-[#161b22] border border-emerald-500/40 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400 font-mono"
                  />
                  <span className="text-[10px] text-gray-500 mt-0.5 block">ATH: ₹{currentSelectedStock?.ath}</span>
                </div>
              </div>

              {/* Margin / Capital Check */}
              <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-3 text-xs space-y-1">
                <div className="flex justify-between text-gray-400">
                  <span>Available Buying Power:</span>
                  <span className="font-mono text-emerald-400 font-bold">₹{cashBalance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Required Margin:</span>
                  <span className="font-mono text-white font-bold">
                    ₹{((currentSelectedStock?.currentPrice || 0) * orderQuantity).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </span>
                </div>
              </div>

              {/* Execute Button */}
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-500 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/20 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Execute Paper {orderSide} Order</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* 3. Active Open Positions Table */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl overflow-hidden flex flex-col shadow-lg">
        <div className="p-4 bg-[#161b22] border-b border-[#30363d] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Active Open Positions</h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono">
              {positions.length} Live
            </span>
          </div>

          <div className="flex items-center gap-2">
            {positions.length > 0 && (
              <button
                onClick={handleSquareOffAll}
                className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-[#21262d] text-rose-300 border border-rose-500/30 hover:bg-rose-500/20 transition-colors cursor-pointer"
              >
                Square Off All
              </button>
            )}
            <span className="text-[11px] text-gray-400">Updated with live simulated ticks</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          {positions.length === 0 ? (
            <div className="p-12 text-center text-gray-500 text-xs">
              <Target className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="font-medium text-gray-400">No active positions open.</p>
              <p className="text-[11px] text-gray-500 mt-1">
                Select any of the {stocks.length} NSE stocks above, check the strategy advice, and click "Execute Paper Order" to begin.
              </p>
            </div>
          ) : (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#30363d] bg-[#161b22]/50 text-gray-400 font-semibold select-none">
                  <th className="py-2.5 px-3">Symbol &amp; Side</th>
                  <th className="py-2.5 px-3">Entry &amp; Current Price</th>
                  <th className="py-2.5 px-3">Shares / Invested</th>
                  <th className="py-2.5 px-3">SL / Target</th>
                  <th className="py-2.5 px-3">Unrealized P&amp;L</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#21262d]">
                {positions.map((pos) => {
                  const isProfit = pos.unrealizedPnl >= 0;
                  return (
                    <tr key={pos.id} className="hover:bg-[#161b22]/60 transition-colors">
                      {/* Symbol */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1.5">
                          <span 
                            onClick={() => onSelectStockForChart(pos.symbol)}
                            className="font-bold text-white hover:text-blue-400 cursor-pointer transition-colors"
                          >
                            {pos.symbol}
                          </span>
                          <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                            pos.side === 'BUY'
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                          }`}>
                            {pos.side}
                          </span>
                        </div>
                        <div className="text-[10px] text-gray-400 truncate max-w-[130px]">{pos.name}</div>
                      </td>

                      {/* Prices */}
                      <td className="py-3 px-3 font-mono">
                        <div className="text-white font-semibold">₹{pos.currentPrice}</div>
                        <div className="text-[10px] text-gray-400">Entry: ₹{pos.entryPrice}</div>
                      </td>

                      {/* Shares / Invested */}
                      <td className="py-3 px-3 font-mono">
                        <div className="text-gray-200">{pos.quantity} shares</div>
                        <div className="text-[10px] text-gray-400">
                          ₹{pos.investedAmount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                        </div>
                      </td>

                      {/* SL / Target */}
                      <td className="py-3 px-3 font-mono text-[11px]">
                        <div className="text-rose-400">SL: ₹{pos.stopLoss}</div>
                        <div className="text-emerald-400">TP: ₹{pos.targetPrice}</div>
                      </td>

                      {/* Live PnL */}
                      <td className="py-3 px-3 font-mono">
                        <div className={`font-bold flex items-center gap-1 ${
                          isProfit ? 'text-emerald-400' : 'text-rose-400'
                        }`}>
                          {isProfit ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                          {isProfit ? '+' : ''}₹{pos.unrealizedPnl.toLocaleString('en-IN', { maximumFractionDigits: 1 })}
                        </div>
                        <div className={`text-[11px] font-semibold ${
                          isProfit ? 'text-emerald-400' : 'text-rose-400'
                        }`}>
                          {isProfit ? '+' : ''}{pos.unrealizedPnlPercent.toFixed(2)}%
                        </div>
                      </td>

                      {/* Close Action */}
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => handleClosePosition(pos.id, 'Manual Exit')}
                          className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-[#21262d] text-gray-300 border border-[#30363d] hover:bg-rose-500/20 hover:text-rose-300 hover:border-rose-500/40 transition-colors cursor-pointer"
                        >
                          Square Off
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* 4. Closed Paper Trades History Log */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl overflow-hidden shadow-lg">
        <div className="p-4 bg-[#161b22] border-b border-[#30363d] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-bold text-white">Closed Trades Execution Log</h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30 font-mono">
              {tradeHistory.length} Completed
            </span>
          </div>
          <span className="text-xs text-gray-400">Auditable simulated trading record</span>
        </div>

        <div className="overflow-x-auto">
          {tradeHistory.length === 0 ? (
            <div className="p-8 text-center text-gray-500 text-xs">
              No closed paper trades recorded yet. Once you square off a position, it will be saved here.
            </div>
          ) : (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#30363d] bg-[#161b22]/50 text-gray-400 font-semibold select-none">
                  <th className="py-2.5 px-3">Symbol</th>
                  <th className="py-2.5 px-3">Side &amp; Shares</th>
                  <th className="py-2.5 px-3">Entry &amp; Exit Price</th>
                  <th className="py-2.5 px-3">Exit Reason</th>
                  <th className="py-2.5 px-3">Net Profit / Loss</th>
                  <th className="py-2.5 px-3">Return %</th>
                  <th className="py-2.5 px-3">Dates</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#21262d]">
                {tradeHistory.map((trade) => {
                  const isProfit = trade.outcome === 'PROFIT';
                  return (
                    <tr key={trade.id} className="hover:bg-[#161b22]/50 transition-colors">
                      <td className="py-3 px-3 font-bold text-white font-mono">
                        {trade.symbol}
                      </td>
                      <td className="py-3 px-3 font-mono">
                        <span className={`inline-block px-1.5 py-0.2 text-[10px] rounded font-bold mr-1.5 ${
                          trade.side === 'BUY'
                            ? 'bg-emerald-500/15 text-emerald-300'
                            : 'bg-rose-500/15 text-rose-300'
                        }`}>
                          {trade.side}
                        </span>
                        <span className="text-gray-300">{trade.quantity} qty</span>
                      </td>
                      <td className="py-3 px-3 font-mono">
                        <span className="text-gray-400">₹{trade.entryPrice}</span>
                        <span className="text-gray-500 mx-1">&rarr;</span>
                        <span className="text-white font-semibold">₹{trade.exitPrice}</span>
                      </td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-[#21262d] text-gray-300 border border-[#30363d]">
                          {trade.exitReason}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono font-bold">
                        <span className={isProfit ? 'text-emerald-400' : 'text-rose-400'}>
                          {isProfit ? '+' : ''}₹{trade.netPnl.toLocaleString('en-IN', { maximumFractionDigits: 1 })}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono font-semibold">
                        <span className={`inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded text-[11px] ${
                          isProfit ? 'bg-emerald-500/15 text-emerald-300' : 'bg-rose-500/15 text-rose-300'
                        }`}>
                          {isProfit ? '+' : ''}{trade.netPnlPercent.toFixed(2)}%
                        </span>
                      </td>
                      <td className="py-3 px-3 text-[10px] text-gray-400 font-mono">
                        <div>Entry: {trade.entryDate}</div>
                        <div>Exit: {trade.exitDate}</div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
