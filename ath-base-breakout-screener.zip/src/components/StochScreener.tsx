import { useState, useMemo } from 'react';
import { Stock, Timeframe, StochSignalType } from '../types';
import { MARKET_SCAN_UNIVERSE, ScanCandidate } from '../data/mockMarketData';
import { evaluateStockPatternAndStoch } from '../utils/technicalAnalysis';
import { rankStocksByStrategy } from '../utils/strategyRanking';
import { 
  Activity, 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  ArrowUpRight, 
  Flame, 
  SlidersHorizontal, 
  Radio, 
  Sparkles, 
  Target, 
  BarChart2, 
  Sliders, 
  Star, 
  BookmarkPlus,
  RefreshCw,
  TrendingUp,
  Info,
  Layers,
  ChevronDown
} from 'lucide-react';

interface StochScreenerProps {
  stocks: Stock[];
  selectedStockId: string;
  onSelectStock: (stock: Stock) => void;
  timeframe: Timeframe;
  onTimeframeChange: (tf: Timeframe) => void;
  onOpenBacktestWithStock: (stock: Stock) => void;
  onAddToWatchlist: (stockId: string) => void;
  onAddStockToUniverse?: (newStock: Stock) => void;
  watchlistStockIds: string[];
  isMaster?: boolean;
}

export default function StochScreener({
  stocks,
  selectedStockId,
  onSelectStock,
  timeframe,
  onTimeframeChange,
  onOpenBacktestWithStock,
  onAddToWatchlist,
  onAddStockToUniverse,
  watchlistStockIds,
  isMaster = false,
}: StochScreenerProps) {
  // Filter States
  const bestStrategyStockId = useMemo(() => rankStocksByStrategy(stocks)[0]?.stock?.id, [stocks]);
  const [searchTerm, setSearchTerm] = useState('');
  const [signalFilter, setSignalFilter] = useState<string>('ALL');
  const [proximityMode, setProximityMode] = useState<'ATH_10' | 'ATL_10' | 'ATH_5' | 'ALL'>('ATH_10');
  const [maxAthFilter, setMaxAthFilter] = useState<number>(10);
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  // Scanner Tool State (Allows scanning ANY stock in the market)
  const [isScannerOpen, setIsScannerOpen] = useState(true);
  const [scanQuery, setScanQuery] = useState('');
  const [scannedResult, setScannedResult] = useState<{
    candidate: ScanCandidate;
    evaluation: ReturnType<typeof evaluateStockPatternAndStoch>;
  } | null>(null);

  // Quick stats
  const primeCount = stocks.filter(s => s.stochQuality === 'Prime (Crossover at 20 EMA)').length;
  const hookCount = stocks.filter(s => s.stochSignal === 'Oversold Hook').length;
  const momentumCount = stocks.filter(s => s.stochSignal === 'Momentum Zone' || s.stochK > 70).length;
  const atlReboundCount = stocks.filter(s => s.distToAtl !== undefined && s.distToAtl <= 15).length;

  // Filtered stocks for the Stock Screener
  const filteredStocks = useMemo(() => {
    return stocks.filter((stock) => {
      // Search
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const match = stock.symbol.toLowerCase().includes(q) || stock.name.toLowerCase().includes(q);
        if (!match) return false;
      }

      // Proximity Mode Filter (ATH 10% vs ATL 10% Turnaround vs ATH 5%)
      if (proximityMode === 'ATH_10') {
        if (stock.distToAth > 10) return false;
      } else if (proximityMode === 'ATH_5') {
        if (stock.distToAth > 5) return false;
      } else if (proximityMode === 'ATL_10') {
        // Stock must be within 15% of its All-Time Low (ATL Reversal Candidate)
        if (stock.distToAtl === undefined || stock.distToAtl > 15) return false;
      }

      // Signal filter
      if (signalFilter !== 'ALL') {
        if (signalFilter === 'PRIME_EMA') {
          if (stock.stochQuality !== 'Prime (Crossover at 20 EMA)') return false;
        } else if (signalFilter === 'OVERSOLD_HOOK') {
          if (stock.stochSignal !== 'Oversold Hook' && stock.stochK >= 45) return false;
        } else if (signalFilter === 'MOMENTUM_ZONE') {
          if (stock.stochSignal !== 'Momentum Zone' && (stock.stochK < 50 || stock.stochK > 82)) return false;
        } else if (signalFilter === 'BREAKOUT_ZONE') {
          if (stock.stochK < 80) return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (proximityMode === 'ATL_10') {
        return (a.distToAtl ?? 999) - (b.distToAtl ?? 999);
      }
      // Sort prime crossovers and tightest ATH proximity first
      if (a.stochQuality === 'Prime (Crossover at 20 EMA)' && b.stochQuality !== 'Prime (Crossover at 20 EMA)') return -1;
      if (b.stochQuality === 'Prime (Crossover at 20 EMA)' && a.stochQuality !== 'Prime (Crossover at 20 EMA)') return 1;
      return a.distToAth - b.distToAth;
    });
  }, [stocks, searchTerm, signalFilter, proximityMode]);

  // Handle Scanning Any Stock from the Universe
  const handleScanStock = (candidate: ScanCandidate) => {
    const evaluation = evaluateStockPatternAndStoch(
      candidate.currentPrice,
      candidate.ath,
      candidate.baseResistance,
      candidate.supportEma,
      candidate.stochK,
      candidate.stochD
    );
    setScannedResult({ candidate, evaluation });
  };

  // Convert scanned candidate to active Stock in screener if user clicks "Add to Active Screener"
  const handleAddCandidateToScreener = (candidate: ScanCandidate) => {
    // Check if already in stocks
    const exists = stocks.find(s => s.symbol.toLowerCase() === candidate.symbol.toLowerCase());
    if (exists) {
      onSelectStock(exists);
      return;
    }

    const distToAth = Math.max(0, Number((((candidate.ath - candidate.currentPrice) / candidate.ath) * 100).toFixed(2)));
    const syntheticStock: Stock = {
      id: candidate.symbol.toLowerCase(),
      symbol: candidate.symbol,
      name: candidate.name,
      exchange: candidate.exchange,
      type: 'stock',
      currentPrice: candidate.currentPrice,
      change: Number((candidate.currentPrice * 0.018).toFixed(2)),
      changePercent: 1.82,
      ath: candidate.ath,
      distToAth,
      atl: Math.round(candidate.currentPrice * 0.45),
      distToAtl: 122.2,
      baseResistance: candidate.baseResistance,
      supportEma: candidate.supportEma,
      pattern: 'Scanned High Base + Stoch Hook',
      patternConfidence: 94,
      patternStatus: distToAth <= 2 ? 'Breakout Confirmed' : 'Base Forming / Near Pivot',
      volumeRatio: 2.1,
      avgVolume20: 3200000,
      baseLengthBars: 9,
      marketRegime: 'Bullish Day',
      sector: candidate.sector,
      description: `Discovered by Live Pattern Radar: trading at ${distToAth}% from ATH with active Stochastic (%K: ${candidate.stochK}) above 20 EMA support (₹${candidate.supportEma}).`,
      stochK: candidate.stochK,
      stochD: candidate.stochD,
      stochSignal: candidate.stochK > candidate.stochD ? 'Bullish Crossover' : 'Momentum Zone',
      stochCondition: `%K (${candidate.stochK}) holding above %D (${candidate.stochD}) at 20 EMA`,
      stochQuality: 'Prime (Crossover at 20 EMA)',
      isStochAtEmaSupport: true,
      dailyCandles: [
        { date: '2026-08-28', open: candidate.currentPrice * 0.96, high: candidate.currentPrice * 0.98, low: candidate.currentPrice * 0.95, close: candidate.currentPrice * 0.97, volume: 2100000, ema20: candidate.supportEma * 0.99, stochK: 52, stochD: 48, marketRegime: 'Neutral Day' },
        { date: '2026-09-01', open: candidate.currentPrice * 0.97, high: candidate.currentPrice * 0.99, low: candidate.currentPrice * 0.96, close: candidate.currentPrice * 0.98, volume: 2400000, ema20: candidate.supportEma, stochK: 60, stochD: 54, marketRegime: 'Bullish Day' },
        { date: '2026-09-02', open: candidate.currentPrice * 0.98, high: candidate.currentPrice * 1.01, low: candidate.currentPrice * 0.975, close: candidate.currentPrice * 0.99, volume: 2900000, ema20: candidate.supportEma, stochK: candidate.stochK - 4, stochD: candidate.stochD - 2, marketRegime: 'Bullish Day' },
        { date: '2026-09-03', open: candidate.currentPrice * 0.99, high: candidate.currentPrice * 1.02, low: candidate.currentPrice * 0.985, close: candidate.currentPrice, volume: 4600000, ema20: candidate.supportEma, stochK: candidate.stochK, stochD: candidate.stochD, marketRegime: 'Bullish Day' },
      ],
      weeklyCandles: [
        { date: '2026-08-17', open: candidate.currentPrice * 0.92, high: candidate.currentPrice * 0.96, low: candidate.currentPrice * 0.90, close: candidate.currentPrice * 0.95, volume: 9500000, ema20: candidate.supportEma * 0.96, stochK: 58, stochD: 52 },
        { date: '2026-08-24', open: candidate.currentPrice * 0.95, high: candidate.currentPrice * 0.98, low: candidate.currentPrice * 0.93, close: candidate.currentPrice * 0.97, volume: 11000000, ema20: candidate.supportEma * 0.98, stochK: 65, stochD: 59 },
        { date: '2026-08-31', open: candidate.currentPrice * 0.97, high: candidate.currentPrice * 1.02, low: candidate.currentPrice * 0.96, close: candidate.currentPrice, volume: 15500000, ema20: candidate.supportEma, stochK: candidate.stochK, stochD: candidate.stochD },
      ],
    };

    if (onAddStockToUniverse) {
      onAddStockToUniverse(syntheticStock);
    }
    onSelectStock(syntheticStock);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Dedicated Stock Screener Identity */}
      <div className="bg-gradient-to-r from-blue-950/40 via-purple-950/40 to-emerald-950/40 border border-[#30363d] rounded-2xl p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/40">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-extrabold text-white tracking-tight">
                    10% Momentum &amp; Stochastic Screener
                  </h2>
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
                    Stock Oscillator (14, 3, 3) + 20 EMA + ≤10% ATH Strategy
                  </span>
                </div>
                <p className="text-xs text-gray-300 mt-0.5">
                  Filters stocks trading <strong>≤10% below All-Time High</strong> or holding deep <strong>All-Time Low reversals (≤10% to ATL)</strong> with <strong>20 EMA dynamic support</strong> confirmation.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Metrics Pills */}
          <div className="flex items-center gap-2.5 flex-wrap text-xs">
            <div className="bg-[#161b22] px-3 py-1.5 rounded-xl border border-[#30363d] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="text-gray-400">Prime 20 EMA Hooks:</span>
              <strong className="text-white font-mono">{primeCount}</strong>
            </div>
            <div className="bg-[#161b22] px-3 py-1.5 rounded-xl border border-[#30363d] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span className="text-gray-400">Oversold Hooks:</span>
              <strong className="text-white font-mono">{hookCount}</strong>
            </div>
            <div className="bg-[#161b22] px-3 py-1.5 rounded-xl border border-[#30363d] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-400" />
              <span className="text-gray-400">Momentum Zone:</span>
              <strong className="text-white font-mono">{momentumCount}</strong>
            </div>
            <div className="bg-[#161b22] px-3 py-1.5 rounded-xl border border-emerald-500/30 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-emerald-300 font-semibold">ATL Turnarounds:</span>
              <strong className="text-white font-mono">{atlReboundCount}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* TOOL: Automated "Scan Any Stock" 10% Strategy Radar */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl overflow-hidden shadow-sm">
        <button
          onClick={() => setIsScannerOpen(!isScannerOpen)}
          className="w-full flex items-center justify-between p-4 bg-[#161b22] hover:bg-[#1a202c] transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400 border border-blue-500/30">
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-2">
                Live 10% Strategy Radar: Scan ANY Stock for 10% Strategy &amp; Stochastic Setup
                <span className="text-[10px] px-1.5 py-0.2 rounded font-mono bg-blue-500/10 text-blue-300 border border-blue-500/30">
                  Instant Checker
                </span>
              </div>
              <p className="text-[11px] text-gray-400">
                Click any ticker or test any market stock to immediately evaluate if it qualifies for the 10% ATH Strategy (≤10% to ATH with 20 EMA support &amp; momentum).
              </p>
            </div>
          </div>
          <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isScannerOpen ? 'rotate-180' : ''}`} />
        </button>

        {isScannerOpen && (
          <div className="p-4 border-t border-[#30363d] bg-[#090d13] space-y-4">
            {/* Quick Candidate Selector Chips */}
            <div>
              <div className="text-[11px] font-semibold text-gray-400 mb-2 flex items-center gap-1.5">
                <span>Select from Market Scan Universe:</span>
                <span className="text-gray-500 font-normal">(Shows stocks that qualify vs overextended stocks)</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {MARKET_SCAN_UNIVERSE.map((cand) => {
                  const isQualifying = cand.category === 'Matches Both (ATH + Stoch)';
                  const isSelected = scannedResult?.candidate.symbol === cand.symbol;
                  return (
                    <button
                      key={cand.symbol}
                      onClick={() => handleScanStock(cand)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium flex items-center gap-1.5 transition-all ${
                        isSelected
                          ? 'bg-blue-600 text-white shadow'
                          : isQualifying
                          ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20'
                          : 'bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white'
                      }`}
                    >
                      <span>{cand.symbol}</span>
                      <span className={`text-[10px] px-1 rounded ${
                        isQualifying ? 'bg-emerald-500/20 text-emerald-300' : 'bg-gray-800 text-gray-400'
                      }`}>
                        {(((cand.ath - cand.currentPrice) / cand.ath) * 100).toFixed(1)}% to ATH
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Scanned Diagnostic Output Card */}
            {scannedResult && (
              <div className={`p-4 rounded-xl border transition-all ${
                scannedResult.evaluation.matchesPattern
                  ? 'bg-emerald-950/20 border-emerald-500/40'
                  : 'bg-[#161b22] border-amber-500/30'
              }`}>
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2.5">
                      <span className="text-base font-bold text-white font-mono">
                        {scannedResult.candidate.symbol}
                      </span>
                      <span className="text-xs text-gray-400">
                        {scannedResult.candidate.name} ({scannedResult.candidate.sector})
                      </span>
                      <span className={`text-xs px-2 py-0.5 rounded font-semibold ${
                        scannedResult.evaluation.matchesPattern
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}>
                        {scannedResult.evaluation.matchesPattern
                          ? '✓ 10% STRATEGY QUALIFIED'
                          : '⚠ DOES NOT MEET CRITERIA'}
                      </span>
                    </div>

                    <div className="mt-2 text-xs text-gray-300 flex flex-wrap gap-4 font-mono">
                      <span>Price: <strong className="text-white">₹{scannedResult.candidate.currentPrice}</strong></span>
                      <span>ATH: <strong className="text-white">₹{scannedResult.candidate.ath}</strong></span>
                      <span>Dist to ATH: <strong className={scannedResult.evaluation.distToAth <= 10 ? 'text-emerald-400' : 'text-rose-400'}>{scannedResult.evaluation.distToAth}%</strong></span>
                      <span>20 EMA: <strong className="text-white">₹{scannedResult.candidate.supportEma}</strong></span>
                      <span>Stoch %K / %D: <strong className="text-cyan-400">{scannedResult.candidate.stochK}</strong> / <strong className="text-amber-400">{scannedResult.candidate.stochD}</strong></span>
                    </div>

                    <p className="mt-2 text-xs text-gray-300 leading-relaxed font-sans">
                      {scannedResult.evaluation.summary} — <span className="text-gray-400">{scannedResult.evaluation.recommendation}</span>
                    </p>
                  </div>

                  {/* Action to load or add to screener */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleAddCandidateToScreener(scannedResult.candidate)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-500 text-white shadow transition-all"
                    >
                      <BookmarkPlus className="w-3.5 h-3.5" />
                      Add to Screener &amp; Chart
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Screener Controls Bar */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Left: Search & Filter Tabs */}
          <div className="flex flex-wrap items-center gap-2 flex-1 max-w-2xl">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search symbol, company, or sector..."
                className="w-full pl-9 pr-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded-lg text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Timeframe toggle */}
            <div className="flex items-center bg-[#161b22] p-0.5 rounded-lg border border-[#30363d]">
              <button
                onClick={() => onTimeframeChange('1D')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                  timeframe === '1D' ? 'bg-blue-600 text-white shadow' : 'text-gray-400 hover:text-white'
                }`}
              >
                1D (Daily)
              </button>
              <button
                onClick={() => onTimeframeChange('1W')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                  timeframe === '1W' ? 'bg-blue-600 text-white shadow' : 'text-gray-400 hover:text-white'
                }`}
              >
                1W (Weekly)
              </button>
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-[#161b22] p-0.5 rounded-lg border border-[#30363d] text-xs">
              <button
                onClick={() => setViewMode('table')}
                className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                  viewMode === 'table' ? 'bg-[#21262d] text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                Table
              </button>
              <button
                onClick={() => setViewMode('cards')}
                className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                  viewMode === 'cards' ? 'bg-[#21262d] text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                Cards
              </button>
            </div>
          </div>

          {/* Right: Signal Filter Pills */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setSignalFilter('ALL')}
              className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                signalFilter === 'ALL'
                  ? 'bg-blue-600 text-white'
                  : 'bg-[#161b22] text-gray-400 hover:text-white border border-[#30363d]'
              }`}
            >
              All Setups ({stocks.length})
            </button>
            <button
              onClick={() => setSignalFilter('PRIME_EMA')}
              className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                signalFilter === 'PRIME_EMA'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#161b22] text-gray-400 hover:text-white border border-[#30363d]'
              }`}
            >
              Prime 20 EMA Crossover
            </button>
            <button
              onClick={() => setSignalFilter('OVERSOLD_HOOK')}
              className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                signalFilter === 'OVERSOLD_HOOK'
                  ? 'bg-amber-600 text-white'
                  : 'bg-[#161b22] text-gray-400 hover:text-white border border-[#30363d]'
              }`}
            >
              Oversold Hook (&lt;35)
            </button>
            <button
              onClick={() => setSignalFilter('MOMENTUM_ZONE')}
              className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                signalFilter === 'MOMENTUM_ZONE'
                  ? 'bg-purple-600 text-white'
                  : 'bg-[#161b22] text-gray-400 hover:text-white border border-[#30363d]'
              }`}
            >
              Momentum (50-80)
            </button>
          </div>
        </div>

        {/* Proximity Pill filters */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-gray-400 pt-1 border-t border-[#21262d]">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-semibold text-gray-300">Strategy Focus:</span>
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                onClick={() => setProximityMode('ATH_10')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  proximityMode === 'ATH_10'
                    ? 'bg-blue-600 text-white shadow'
                    : 'bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white'
                }`}
              >
                ≤10% to ATH (Base Breakout)
              </button>
              <button
                onClick={() => setProximityMode('ATH_5')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  proximityMode === 'ATH_5'
                    ? 'bg-blue-600 text-white shadow'
                    : 'bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white'
                }`}
              >
                ≤5% to ATH (High Tight)
              </button>
              <button
                onClick={() => setProximityMode('ATL_10')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  proximityMode === 'ATL_10'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                ≤10% to ATL (Turnaround)
              </button>
              <button
                onClick={() => setProximityMode('ALL')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  proximityMode === 'ALL'
                    ? 'bg-gray-700 text-white shadow'
                    : 'bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white'
                }`}
              >
                All Universe
              </button>
            </div>
          </div>

          <div className="text-[11px] text-gray-400">
            Showing <strong className="text-white font-mono">{filteredStocks.length}</strong> matching setups
          </div>
        </div>
      </div>

      {/* TABLE VIEW */}
      {viewMode === 'table' ? (
        <div className="bg-[#0d1117] border border-[#30363d] rounded-xl overflow-x-auto shadow-sm">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#30363d] bg-[#161b22] text-gray-400 font-semibold select-none">
                <th className="py-3 px-4">Stock Symbol</th>
                <th className="py-3 px-4">Current Price</th>
                <th className="py-3 px-4">Dist to ATH / ATL</th>
                <th className="py-3 px-4">20 EMA Support</th>
                <th className="py-3 px-4">Stock Oscillator (14, 3)</th>
                <th className="py-3 px-4">Stock Momentum Signal</th>
                <th className="py-3 px-4">10% Setup Stage</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {filteredStocks.map((stock) => {
                const isSelected = stock.id === selectedStockId;
                const isWatchlisted = watchlistStockIds.includes(stock.id);
                const isTopStrategyPick = stock.id === bestStrategyStockId;

                return (
                  <tr
                    key={stock.id}
                    onClick={() => onSelectStock(stock)}
                    className={`cursor-pointer transition-colors group ${
                      isSelected
                        ? 'bg-blue-950/30 hover:bg-blue-950/40'
                        : 'hover:bg-[#161b22]'
                    }`}
                  >
                    {/* Symbol */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onAddToWatchlist(stock.id);
                          }}
                          className={`p-1 rounded transition-colors ${
                            isWatchlisted ? 'text-amber-400' : 'text-gray-600 hover:text-gray-300'
                          }`}
                          title={isWatchlisted ? 'In Watchlist' : 'Add to Watchlist'}
                        >
                          <Star className="w-3.5 h-3.5 fill-current" />
                        </button>
                        <div>
                          <div className="font-bold text-white flex items-center gap-1.5 font-mono">
                            {stock.symbol}
                            {isTopStrategyPick && (
                              <span className="text-[10px] px-1 bg-amber-500/20 text-amber-300 rounded font-sans font-semibold border border-amber-500/30">
                                ⭐ Top Pick
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-gray-400 truncate max-w-[150px]">
                            {stock.name}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Price & Change */}
                    <td className="py-3 px-4 font-mono">
                      <div className="font-bold text-white">₹{stock.currentPrice.toLocaleString()}</div>
                      <div className={`text-[11px] font-medium flex items-center gap-0.5 ${
                        stock.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%
                      </div>
                    </td>

                    {/* Distance to ATH / ATL */}
                    <td className="py-3 px-4 font-mono">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`font-bold ${
                          stock.distToAth <= 2 ? 'text-emerald-400' : 'text-amber-400'
                        }`}>
                          {stock.distToAth.toFixed(1)}% to ATH
                        </span>
                        {stock.distToAtl !== undefined && stock.distToAtl <= 15 && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                            {stock.distToAtl.toFixed(1)}% to ATL
                          </span>
                        )}
                      </div>
                      <div className="w-20 bg-[#21262d] h-1.5 rounded-full overflow-hidden mt-1">
                        <div
                          className="bg-emerald-500 h-full rounded-full"
                          style={{ width: `${Math.max(10, 100 - stock.distToAth * 10)}%` }}
                        />
                      </div>
                      <div className="text-[10px] text-gray-500 mt-0.5 flex items-center justify-between">
                        <span>ATH: ₹{stock.ath.toLocaleString()}</span>
                        {stock.atl && <span className="text-gray-400">ATL: ₹{stock.atl}</span>}
                      </div>
                    </td>

                    {/* 20 EMA Support */}
                    <td className="py-3 px-4 font-mono">
                      <div className="text-white font-semibold">₹{stock.supportEma.toLocaleString()}</div>
                      <div className="text-[10px] text-emerald-400 flex items-center gap-1 mt-0.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        Holding above 20 EMA
                      </div>
                    </td>

                    {/* Stochastic %K and %D with Mini Visualizer */}
                    <td className="py-3 px-4 font-mono">
                      <div className="flex items-center gap-3">
                        <div>
                          <div className="text-xs font-bold text-cyan-400">
                            %K: {stock.stochK.toFixed(1)}
                          </div>
                          <div className="text-[11px] text-amber-400">
                            %D: {stock.stochD.toFixed(1)}
                          </div>
                        </div>

                        {/* Visual Stochastic Bar */}
                        <div className="w-16 bg-[#21262d] h-3 rounded relative overflow-hidden border border-[#30363d]">
                          {/* Overbought line at 80% */}
                          <div className="absolute top-0 bottom-0 left-[80%] w-0.5 bg-rose-500/40 z-10" />
                          {/* Oversold line at 20% */}
                          <div className="absolute top-0 bottom-0 left-[20%] w-0.5 bg-emerald-500/40 z-10" />
                          {/* %K fill */}
                          <div
                            className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-sm"
                            style={{ width: `${Math.min(100, Math.max(5, stock.stochK))}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    {/* Stoch Signal & Quality */}
                    <td className="py-3 px-4">
                      <div>
                        <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded font-semibold border ${
                          stock.stochQuality === 'Prime (Crossover at 20 EMA)'
                            ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                            : stock.stochSignal === 'Oversold Hook'
                            ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                            : 'bg-blue-500/10 text-blue-300 border-blue-500/30'
                        }`}>
                          <Flame className="w-3 h-3 text-amber-400" />
                          {stock.stochSignal}
                        </span>
                        <div className="text-[10px] text-gray-400 mt-1 max-w-[210px] truncate leading-tight">
                          {stock.stochCondition}
                        </div>
                      </div>
                    </td>

                    {/* 10% Setup Stage */}
                    <td className="py-3 px-4">
                      <span className="text-[11px] px-2 py-0.5 rounded font-medium bg-[#161b22] text-gray-300 border border-[#30363d]">
                        {stock.patternStatus}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => onSelectStock(stock)}
                          className="px-2.5 py-1 text-xs rounded bg-blue-600/20 text-blue-300 border border-blue-500/40 hover:bg-blue-600/30 transition-colors font-medium flex items-center gap-1"
                        >
                          <BarChart2 className="w-3 h-3" />
                          Chart
                        </button>
                        {isMaster && (
                          <button
                            onClick={() => onOpenBacktestWithStock(stock)}
                            className="px-2.5 py-1 text-xs rounded bg-[#21262d] text-gray-300 border border-[#30363d] hover:text-white transition-colors font-medium flex items-center gap-1"
                            title="Backtest this setup (Master ID Exclusive)"
                          >
                            <Sliders className="w-3 h-3" />
                            Test
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        /* CARDS VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredStocks.map((stock) => {
            const isSelected = stock.id === selectedStockId;
            const isTopStrategyPick = stock.id === bestStrategyStockId;

            return (
              <div
                key={stock.id}
                onClick={() => onSelectStock(stock)}
                className={`bg-[#0d1117] border rounded-xl p-4 transition-all cursor-pointer space-y-3 ${
                  isSelected
                    ? 'border-blue-500 shadow-md shadow-blue-950/40 bg-[#121720]'
                    : 'border-[#30363d] hover:border-gray-500 bg-[#0d1117]'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-base font-bold text-white font-mono">{stock.symbol}</span>
                      {isTopStrategyPick && (
                        <span className="text-[10px] px-1 bg-amber-500/20 text-amber-300 rounded font-semibold border border-amber-500/30">
                          ⭐ Top Pick
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-400">{stock.name}</div>
                  </div>

                  <div className="text-right font-mono">
                    <div className="text-base font-bold text-white">₹{stock.currentPrice.toLocaleString()}</div>
                    <div className={`text-xs ${stock.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%
                    </div>
                  </div>
                </div>

                {/* Stochastic Gauge & Metrics */}
                <div className="bg-[#161b22] p-3 rounded-lg border border-[#30363d] space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-gray-400">Stochastic (14, 3):</span>
                    <span className="space-x-2">
                      <strong className="text-cyan-400">%K {stock.stochK.toFixed(1)}</strong>
                      <strong className="text-amber-400">%D {stock.stochD.toFixed(1)}</strong>
                    </span>
                  </div>

                  {/* Progress Meter */}
                  <div className="w-full bg-[#0d1117] h-2.5 rounded-full overflow-hidden border border-[#30363d] relative">
                    <div
                      className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full rounded-full"
                      style={{ width: `${Math.min(100, Math.max(5, stock.stochK))}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-gray-400 pt-1">
                    <span>20 EMA Support: <strong className="text-white font-mono">₹{stock.supportEma}</strong></span>
                    <span>Dist to ATH: <strong className="text-emerald-400 font-mono">{stock.distToAth.toFixed(1)}%</strong></span>
                  </div>
                </div>

                <div className="text-xs text-gray-300 flex items-center justify-between">
                  <span className="text-[11px] px-2 py-0.5 rounded font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                    {stock.stochSignal}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectStock(stock);
                      }}
                      className="text-xs text-blue-400 hover:text-blue-300 font-semibold"
                    >
                      View Chart →
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
