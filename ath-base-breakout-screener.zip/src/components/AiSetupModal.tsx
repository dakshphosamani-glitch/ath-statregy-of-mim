import { useState, useEffect } from 'react';
import { Stock, Timeframe, AiSetupAnalysis } from '../types';
import { Sparkles, X, ShieldCheck, Target, TrendingUp, AlertTriangle, Layers, Loader2 } from 'lucide-react';

interface AiSetupModalProps {
  stock: Stock;
  timeframe: Timeframe;
  isOpen: boolean;
  onClose: () => void;
}

export default function AiSetupModal({ stock, timeframe, isOpen, onClose }: AiSetupModalProps) {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<AiSetupAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    const fetchAnalysis = async () => {
      setLoading(true);
      setError(null);
      try {
        const candles = timeframe === '1D' ? stock.dailyCandles : stock.weeklyCandles;
        const res = await fetch('/api/analyze-setup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            symbol: stock.symbol,
            name: stock.name,
            timeframe,
            currentPrice: stock.currentPrice,
            ath: stock.ath,
            distToAth: stock.distToAth,
            baseResistance: stock.baseResistance,
            supportEma: stock.supportEma,
            strategyType: '10% ATH Strategy',
            volumeRatio: stock.volumeRatio,
            marketRegime: stock.marketRegime,
            recentCandles: candles.slice(-5).map(c => ({
              date: c.date,
              open: c.open,
              high: c.high,
              low: c.low,
              close: c.close,
              volume: c.volume,
            })),
          }),
        });

        if (!res.ok) {
          throw new Error(`Server returned ${res.status}`);
        }

        const data = await res.json();
        if (isMounted) {
          setAnalysis(data);
        }
      } catch (err: any) {
        if (isMounted) {
          setError(err.message || 'Failed to fetch AI analysis');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchAnalysis();

    return () => {
      isMounted = false;
    };
  }, [isOpen, stock.symbol, timeframe]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 border-b border-[#30363d] bg-[#161b22] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>AI Setup Analysis: {stock.symbol}</span>
                <span className="text-xs px-2 py-0.5 rounded font-mono font-normal bg-[#21262d] text-gray-300">
                  {timeframe} Timeframe
                </span>
              </h3>
              <p className="text-[11px] text-gray-400">10% Strategy compliance audit &amp; market regime risk evaluation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-[#21262d] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
          {loading ? (
            <div className="py-16 text-center space-y-3">
              <Loader2 className="w-8 h-8 text-purple-400 animate-spin mx-auto" />
              <div className="text-white font-semibold">Auditing Base Geometry &amp; Volume...</div>
              <p className="text-gray-500 text-[11px]">Evaluating 20 EMA slope, pivot resistance, and market regime conditions</p>
            </div>
          ) : error ? (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 space-y-2">
              <div className="font-semibold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Error evaluating setup
              </div>
              <p className="text-[11px] text-gray-400">{error}</p>
            </div>
          ) : analysis ? (
            <>
              {/* Score and Grade Banner */}
              <div className="grid grid-cols-3 gap-3 p-3 rounded-xl bg-[#161b22] border border-[#30363d]">
                <div>
                  <div className="text-gray-400 text-[11px]">Setup Grade</div>
                  <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
                    {analysis.setupGrade || 'A+'}
                  </div>
                  <div className="text-[10px] text-gray-500">Minervini Quality</div>
                </div>

                <div>
                  <div className="text-gray-400 text-[11px]">10% Strategy Confidence</div>
                  <div className="text-xl font-bold font-mono text-cyan-400 mt-0.5">
                    {analysis.confidence}%
                  </div>
                  <div className="text-[10px] text-gray-500">Breakout Probability</div>
                </div>

                <div>
                  <div className="text-gray-400 text-[11px]">Market Regime</div>
                  <div className="text-xs font-bold text-white mt-1 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    {stock.marketRegime}
                  </div>
                  <div className="text-[10px] text-gray-500">Tailwind Factor</div>
                </div>
              </div>

              {/* Key Technical Execution Levels */}
              {analysis.keyLevels && (
                <div className="p-3 rounded-xl bg-[#161b22] border border-[#30363d] space-y-2">
                  <div className="font-semibold text-gray-300 flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5 text-blue-400" /> Key Execution Levels
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
                    <div className="bg-[#0d1117] p-2 rounded border border-[#30363d]">
                      <div className="text-gray-500 text-[10px]">Pivot Entry</div>
                      <div className="text-amber-400 font-bold">₹{analysis.keyLevels.resistance}</div>
                    </div>
                    <div className="bg-[#0d1117] p-2 rounded border border-[#30363d]">
                      <div className="text-gray-500 text-[10px]">Stop Loss</div>
                      <div className="text-rose-400 font-bold">₹{analysis.keyLevels.stopLoss}</div>
                    </div>
                    <div className="bg-[#0d1117] p-2 rounded border border-[#30363d]">
                      <div className="text-gray-500 text-[10px]">Target 1 (+8%)</div>
                      <div className="text-emerald-400 font-bold">₹{analysis.keyLevels.target1}</div>
                    </div>
                    <div className="bg-[#0d1117] p-2 rounded border border-[#30363d]">
                      <div className="text-gray-500 text-[10px]">Target 2 (+16%)</div>
                      <div className="text-cyan-400 font-bold">₹{analysis.keyLevels.target2}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Text Breakdown */}
              <div className="p-4 rounded-xl bg-[#161b22] border border-[#30363d] space-y-2 leading-relaxed text-gray-300 whitespace-pre-line">
                {analysis.analysis}
              </div>
            </>
          ) : null}
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-[#30363d] bg-[#161b22] flex items-center justify-between text-xs text-gray-500">
          <span>For personal research and backtesting discretion.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-[#21262d] text-white hover:bg-[#30363d] transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
