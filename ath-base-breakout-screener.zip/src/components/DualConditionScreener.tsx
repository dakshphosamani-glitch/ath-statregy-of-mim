import React, { useState, useMemo } from 'react';
import { Stock, Timeframe } from '../types';
import { evaluateStockConditions, ConditionEvaluation } from '../utils/conditionEvaluator';
import { 
  Sparkles, 
  Layers, 
  Search, 
  Target, 
  TrendingUp, 
  Gauge, 
  CheckCircle2, 
  SlidersHorizontal, 
  BarChart2, 
  Wallet, 
  ArrowUpRight, 
  Flame, 
  Sliders, 
  Star, 
  Info,
  ChevronRight,
  Filter,
  RefreshCw
} from 'lucide-react';

interface DualConditionScreenerProps {
  stocks: Stock[];
  selectedStockId: string;
  onSelectStock: (stock: Stock) => void;
  onOpenChart: (stock: Stock) => void;
  onOpenPaperTrade: (stock: Stock) => void;
  onOpenBacktest: (stock: Stock) => void;
  onAddToWatchlist: (stockId: string) => void;
  watchlistStockIds: string[];
}

export type CategoryFilterType = 'ANY' | 'PATTERN' | 'STOCHASTIC' | 'BOTH';

export default function DualConditionScreener({
  stocks,
  selectedStockId,
  onSelectStock,
  onOpenChart,
  onOpenPaperTrade,
  onOpenBacktest,
  onAddToWatchlist,
  watchlistStockIds,
}: DualConditionScreenerProps) {
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilterType>('ANY');
  const [searchQuery, setSearchQuery] = useState('');
  const [subSectorFilter, setSubSectorFilter] = useState<'ALL' | 'NEAREST' | 'NIFTY50' | 'DEFENSE'>('ALL');
  const [viewMode, setViewMode] = useState<'TABLE' | 'SPLIT_COLUMNS'>('TABLE');
  const [sortBy, setSortBy] = useState<'distToAth' | 'changePercent' | 'confidence'>('distToAth');

  // Evaluate all stocks against both conditions
  const evaluatedStocks = useMemo(() => {
    return stocks.map(evaluateStockConditions);
  }, [stocks]);

  // Aggregate counts
  const anyConditionCount = useMemo(() => evaluatedStocks.filter(e => e.isAnyMet).length, [evaluatedStocks]);
  const patternOnlyCount = useMemo(() => evaluatedStocks.filter(e => e.isPatternMet).length, [evaluatedStocks]);
  const stochOnlyCount = useMemo(() => evaluatedStocks.filter(e => e.isStochMet).length, [evaluatedStocks]);
  const bothCount = useMemo(() => evaluatedStocks.filter(e => e.isBothMet).length, [evaluatedStocks]);

  // Filter list based on selected category, search, and sub-sector
  const filteredList = useMemo(() => {
    return evaluatedStocks.filter((item) => {
      const { stock, isAnyMet, isPatternMet, isStochMet, isBothMet } = item;

      // 1. Primary Category Filter
      if (categoryFilter === 'ANY' && !isAnyMet) return false;
      if (categoryFilter === 'PATTERN' && !isPatternMet) return false;
      if (categoryFilter === 'STOCHASTIC' && !isStochMet) return false;
      if (categoryFilter === 'BOTH' && !isBothMet) return false;

      // 2. Sub-sector filter
      if (subSectorFilter === 'NEAREST' && stock.distToAth > 3.5) return false;
      if (subSectorFilter === 'NIFTY50' && !['RELIANCE', 'TCS', 'HDFCBANK', 'ICICIBANK', 'INFY', 'BHARTIARTL', 'ITC', 'LT', 'SBIN', 'SUNPHARMA'].includes(stock.symbol)) {
        return false;
      }
      if (subSectorFilter === 'DEFENSE' && !['HAL', 'BEL', 'MAZDOCK', 'COCHINSHIP', 'BDL', 'RVNL', 'IRFC'].includes(stock.symbol)) {
        return false;
      }

      // 3. Search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          stock.symbol.toLowerCase().includes(query) ||
          stock.name.toLowerCase().includes(query) ||
          (stock.sector && stock.sector.toLowerCase().includes(query))
        );
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'distToAth') {
        return a.stock.distToAth - b.stock.distToAth;
      } else if (sortBy === 'changePercent') {
        return b.stock.changePercent - a.stock.changePercent;
      } else {
        return b.stock.patternConfidence - a.stock.patternConfidence;
      }
    });
  }, [evaluatedStocks, categoryFilter, subSectorFilter, searchQuery, sortBy]);

  // Separate pools for Split Columns view
  const patternList = useMemo(() => evaluatedStocks.filter(e => e.isPatternMet), [evaluatedStocks]);
  const stochList = useMemo(() => evaluatedStocks.filter(e => e.isStochMet), [evaluatedStocks]);
  const dualConfluenceList = useMemo(() => evaluatedStocks.filter(e => e.isBothMet), [evaluatedStocks]);

  return (
    <div className="space-y-6">
      {/* 1. Header Banner & Condition Definition Guide */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl p-5 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#21262d]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Dual Condition Scanner: 10% ATH &amp; Stochastic</h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                  Any Condition OR Both
                </span>
              </div>
              <p className="text-xs text-gray-400">
                Screen all stocks fulfilling <strong className="text-gray-200">either condition</strong>, or isolate by <strong className="text-blue-400">10% ATH Strategy</strong>, <strong className="text-purple-400">Category 2: Stochastic Momentum</strong>, or <strong className="text-amber-400">Dual Confluence</strong>.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-[#161b22] border border-[#30363d] rounded-xl p-1 text-xs">
              <button
                onClick={() => setViewMode('TABLE')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                  viewMode === 'TABLE' ? 'bg-blue-600 text-white shadow' : 'text-gray-400 hover:text-white'
                }`}
              >
                Table View
              </button>
              <button
                onClick={() => setViewMode('SPLIT_COLUMNS')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                  viewMode === 'SPLIT_COLUMNS' ? 'bg-blue-600 text-white shadow' : 'text-gray-400 hover:text-white'
                }`}
              >
                Split Categories View
              </button>
            </div>
          </div>
        </div>

        {/* 2. Interactive Category Metric Cards (Clickable to Filter) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4">
          
          {/* Card 1: Any Condition Met */}
          <div 
            onClick={() => setCategoryFilter('ANY')}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
              categoryFilter === 'ANY'
                ? 'bg-blue-600/15 border-blue-500 ring-1 ring-blue-500 shadow-md'
                : 'bg-[#161b22] border-[#30363d] hover:border-gray-500'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-300">All Qualifying (Any Condition)</span>
              <Layers className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-bold font-mono text-white mt-2">
              {anyConditionCount} <span className="text-xs font-sans text-gray-400 font-normal">/ {stocks.length}</span>
            </div>
            <div className="text-[11px] text-gray-400 mt-1">
              Meets 10% ATH OR Stochastic condition
            </div>
          </div>

          {/* Card 2: 10% ATH Setups */}
          <div 
            onClick={() => setCategoryFilter('PATTERN')}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
              categoryFilter === 'PATTERN'
                ? 'bg-cyan-600/15 border-cyan-500 ring-1 ring-cyan-500 shadow-md'
                : 'bg-[#161b22] border-[#30363d] hover:border-gray-500'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-cyan-300">10% ATH Strategy Setups</span>
              <TrendingUp className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold font-mono text-cyan-400 mt-2">
              {patternOnlyCount}
            </div>
            <div className="text-[11px] text-gray-400 mt-1">
              ≤10% to ATH with 20 EMA Support
            </div>
          </div>

          {/* Card 3: Category 2 - The Other One (Stochastic) */}
          <div 
            onClick={() => setCategoryFilter('STOCHASTIC')}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
              categoryFilter === 'STOCHASTIC'
                ? 'bg-purple-600/15 border-purple-500 ring-1 ring-purple-500 shadow-md'
                : 'bg-[#161b22] border-[#30363d] hover:border-gray-500'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-purple-300">Category 2: The Other (Stoch)</span>
              <Gauge className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-2xl font-bold font-mono text-purple-400 mt-2">
              {stochOnlyCount}
            </div>
            <div className="text-[11px] text-gray-400 mt-1">
              Bullish Crossover, Oversold Hook, Momentum
            </div>
          </div>

          {/* Card 4: Dual Confluence (Both Conditions Met!) */}
          <div 
            onClick={() => setCategoryFilter('BOTH')}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
              categoryFilter === 'BOTH'
                ? 'bg-amber-500/20 border-amber-400 ring-1 ring-amber-400 shadow-md'
                : 'bg-[#161b22] border-[#30363d] hover:border-gray-500'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-amber-300">Dual Confluence (Both Met!)</span>
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            </div>
            <div className="text-2xl font-bold font-mono text-amber-400 mt-2">
              {bothCount}
            </div>
            <div className="text-[11px] text-gray-400 mt-1">
              Highest Probability: Pattern + Stochastic Confluence
            </div>
          </div>
        </div>
      </div>

      {/* 3. Search & Sub-Filter Bar */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <input
            type="text"
            placeholder="Search stock symbol, company, or sector..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#161b22] border border-[#30363d] rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
          />
          <Search className="w-4 h-4 text-gray-500 absolute left-3 top-2.5" />
        </div>

        {/* Quick Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'ALL', label: 'All Sectors' },
            { id: 'NEAREST', label: 'Nearest to ATH (≤3.5%)' },
            { id: 'NIFTY50', label: 'Nifty 50 Giants' },
            { id: 'DEFENSE', label: 'Defense & Rail Momentum' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setSubSectorFilter(item.id as any)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
                subSectorFilter === item.id
                  ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                  : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Sort selector */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-gray-400">Sort by:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-[#161b22] border border-[#30363d] text-white text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-blue-500 font-medium"
          >
            <option value="distToAth">Distance to ATH (Ascending)</option>
            <option value="changePercent">Day's Gain % (Highest)</option>
            <option value="confidence">Pattern Confidence (Highest)</option>
          </select>
        </div>
      </div>

      {/* 4. CONTENT VIEW MODE: TABLE vs SPLIT CATEGORIES */}
      {viewMode === 'TABLE' ? (
        <div className="bg-[#0d1117] border border-[#30363d] rounded-2xl overflow-hidden shadow-xl">
          <div className="p-4 bg-[#161b22] border-b border-[#30363d] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-blue-400" />
              <h3 className="text-sm font-bold text-white">
                {categoryFilter === 'ANY' && `All Stocks Fulfilling Any Condition (${filteredList.length})`}
                {categoryFilter === 'PATTERN' && `Category 1: Pattern Setups (${filteredList.length})`}
                {categoryFilter === 'STOCHASTIC' && `Category 2: The Other One - Stochastic Setups (${filteredList.length})`}
                {categoryFilter === 'BOTH' && `Dual Confluence: Both Conditions Met (${filteredList.length})`}
              </h3>
            </div>
            <span className="text-xs text-gray-400 font-mono">
              Click any stock to inspect chart or trade
            </span>
          </div>

          <div className="overflow-x-auto">
            {filteredList.length === 0 ? (
              <div className="p-12 text-center text-gray-400 text-xs">
                No stocks match this specific combination of search and filters. Try selecting "All Qualifying (Any Condition)" above.
              </div>
            ) : (
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#30363d] bg-[#161b22]/70 text-gray-400 font-semibold select-none">
                    <th className="py-3 px-4">Symbol &amp; Company</th>
                    <th className="py-3 px-4">Price &amp; Change</th>
                    <th className="py-3 px-4">Condition Status</th>
                    <th className="py-3 px-4">Strategy 1: 10% ATH Reason</th>
                    <th className="py-3 px-4">Category 2: Stochastic Momentum</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21262d]">
                  {filteredList.map(({ stock, isPatternMet, isStochMet, isBothMet, patternReason, stochReason }) => {
                    const isSelected = stock.id === selectedStockId;
                    const inWatchlist = watchlistStockIds.includes(stock.id);

                    return (
                      <tr
                        key={stock.id}
                        onClick={() => onSelectStock(stock)}
                        className={`transition-colors cursor-pointer ${
                          isSelected ? 'bg-blue-600/10' : 'hover:bg-[#161b22]/60'
                        } ${isBothMet ? 'bg-amber-500/[0.03]' : ''}`}
                      >
                        {/* Symbol & Name */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white font-mono text-sm group-hover:text-blue-400">
                              {stock.symbol}
                            </span>
                            {isBothMet && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                BOTH MET
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-gray-400 truncate max-w-[170px]">{stock.name}</div>
                        </td>

                        {/* Price & Change */}
                        <td className="py-3.5 px-4 font-mono">
                          <div className="text-white font-bold">₹{stock.currentPrice}</div>
                          <div className={`text-[11px] font-semibold flex items-center gap-0.5 ${
                            stock.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}>
                            {stock.changePercent >= 0 ? '+' : ''}{stock.changePercent}%
                          </div>
                        </td>

                        {/* Condition Status Badges */}
                        <td className="py-3.5 px-4">
                          <div className="flex flex-col gap-1">
                            {isPatternMet && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 w-fit">
                                <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                                Pattern Condition Met
                              </span>
                            )}
                            {isStochMet && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-purple-500/15 text-purple-300 border border-purple-500/30 w-fit">
                                <Gauge className="w-3 h-3 text-purple-400" />
                                The Other One (Stoch) Met
                              </span>
                            )}
                          </div>
                        </td>

                        {/* Pattern Breakdown */}
                        <td className="py-3.5 px-4 text-xs">
                          <div className="text-gray-200 font-medium">
                            {stock.pattern}
                          </div>
                          <div className="text-[11px] text-gray-400 mt-0.5 font-mono">
                            {stock.distToAth}% to ATH | 20 EMA: ₹{stock.supportEma}
                          </div>
                        </td>

                        {/* Stochastic Breakdown */}
                        <td className="py-3.5 px-4 text-xs">
                          <div className="text-purple-300 font-medium flex items-center gap-1">
                            <span>{stock.stochSignal}</span>
                          </div>
                          <div className="text-[11px] text-gray-400 mt-0.5 font-mono">
                            %K: <strong className="text-white">{stock.stochK}</strong> | %D: <strong className="text-white">{stock.stochD}</strong>
                          </div>
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => onOpenChart(stock)}
                              className="p-1.5 rounded-lg bg-[#21262d] text-gray-300 hover:text-white hover:bg-blue-600/30 transition-colors"
                              title="Inspect Candlestick Chart"
                            >
                              <BarChart2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => onOpenPaperTrade(stock)}
                              className="p-1.5 rounded-lg bg-[#21262d] text-emerald-400 hover:bg-emerald-600/30 transition-colors"
                              title="Open Paper Trade Ticket"
                            >
                              <Wallet className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => onOpenBacktest(stock)}
                              className="p-1.5 rounded-lg bg-[#21262d] text-purple-400 hover:bg-purple-600/30 transition-colors"
                              title="Backtest Strategy on Stock"
                            >
                              <Sliders className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => onAddToWatchlist(stock.id)}
                              className={`p-1.5 rounded-lg transition-colors ${
                                inWatchlist 
                                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' 
                                  : 'bg-[#21262d] text-gray-400 hover:text-white'
                              }`}
                              title={inWatchlist ? 'In Watchlist' : 'Add to Watchlist'}
                            >
                              <Star className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>
      ) : (
        /* SPLIT CATEGORIES VIEW: Side-by-Side Category 1 vs Category 2 + Dual Confluence Top Bar */
        <div className="space-y-6">
          {/* Top Banner: Dual Confluence Setups (Both Conditions Met) */}
          <div className="bg-[#0d1117] border border-amber-500/40 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white">
                  Dual Confluence Setups: Both Conditions Met ({dualConfluenceList.length})
                </h3>
              </div>
              <span className="text-[10px] font-mono text-amber-300 bg-amber-500/15 px-2 py-0.5 rounded border border-amber-500/30">
                Pattern Breakout + Stochastic Crossover
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {dualConfluenceList.slice(0, 6).map(({ stock }) => (
                <div
                  key={stock.id}
                  onClick={() => onOpenChart(stock)}
                  className="bg-[#161b22] border border-amber-500/30 hover:border-amber-400 rounded-xl p-3.5 transition-all cursor-pointer group shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm font-mono group-hover:text-amber-400">
                      {stock.symbol}
                    </span>
                    <span className="text-xs font-mono font-bold text-white">₹{stock.currentPrice}</span>
                  </div>
                  <div className="text-[10px] text-gray-400 truncate mt-0.5">{stock.name}</div>

                  <div className="mt-2.5 pt-2 border-t border-[#30363d] flex items-center justify-between text-[11px] font-mono">
                    <span className="text-cyan-400">{stock.distToAth}% to ATH</span>
                    <span className="text-purple-400">Stoch %K {stock.stochK}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 2 Split Columns: Category 1 (Pattern) vs Category 2 (The Other One / Stochastic) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* COLUMN 1: 10% ATH Setups */}
            <div className="bg-[#0d1117] border border-cyan-500/30 rounded-2xl overflow-hidden shadow-lg">
              <div className="p-4 bg-gradient-to-r from-cyan-950/40 to-[#161b22] border-b border-[#30363d] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-sm font-bold text-white">
                    Strategy 1: 10% ATH Setups ({patternList.length})
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-cyan-300 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30">
                  ≤10% ATH Strategy
                </span>
              </div>

              <div className="p-3 space-y-2.5 max-h-[600px] overflow-y-auto">
                {patternList.map(({ stock, patternReason, isBothMet }) => (
                  <div
                    key={stock.id}
                    onClick={() => onSelectStock(stock)}
                    className={`bg-[#161b22] border rounded-xl p-3 transition-all cursor-pointer hover:border-cyan-500/50 ${
                      stock.id === selectedStockId ? 'border-cyan-500 bg-cyan-950/20' : 'border-[#30363d]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white font-mono">{stock.symbol}</span>
                        {isBothMet && (
                          <span className="text-[9px] px-1 bg-amber-500/20 text-amber-300 rounded font-bold">
                            + STOCH
                          </span>
                        )}
                      </div>
                      <span className="text-xs font-mono font-bold text-white">₹{stock.currentPrice}</span>
                    </div>

                    <div className="text-[11px] text-cyan-400 font-medium mt-1">
                      {stock.pattern}
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-gray-400 mt-2 font-mono">
                      <span>ATH Distance: {stock.distToAth}%</span>
                      <span>20 EMA: ₹{stock.supportEma}</span>
                    </div>

                    <div className="flex items-center justify-between gap-2 mt-2 pt-2 border-t border-[#30363d]">
                      <button
                        onClick={(e) => { e.stopPropagation(); onOpenChart(stock); }}
                        className="text-[10px] text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1"
                      >
                        Chart <ChevronRight className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); onOpenPaperTrade(stock); }}
                        className="text-[10px] text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1"
                      >
                        Paper Trade <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* COLUMN 2: Category 2 - The Other One (Stochastic Momentum) */}
            <div className="bg-[#0d1117] border border-purple-500/30 rounded-2xl overflow-hidden shadow-lg">
              <div className="p-4 bg-gradient-to-r from-purple-950/40 to-[#161b22] border-b border-[#30363d] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-purple-400" />
                  <h3 className="text-sm font-bold text-white">
                    Category 2: The Other One (Stochastic) ({stochList.length})
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/30">
                  Bullish Crossovers &amp; Hooks
                </span>
              </div>

              <div className="p-3 space-y-2.5 max-h-[600px] overflow-y-auto">
                {stochList.map(({ stock, stochReason, isBothMet }) => (
                  <div
                    key={stock.id}
                    onClick={() => onSelectStock(stock)}
                    className={`bg-[#161b22] border rounded-xl p-3 transition-all cursor-pointer hover:border-purple-500/50 ${
                      stock.id === selectedStockId ? 'border-purple-500 bg-purple-950/20' : 'border-[#30363d]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white font-mono">{stock.symbol}</span>
                        {isBothMet && (
                          <span className="text-[9px] px-1 bg-amber-500/20 text-amber-300 rounded font-bold">
                            + PATTERN
                          </span>
                        )}
                      </div>
                      <span className="text-xs font-mono font-bold text-white">₹{stock.currentPrice}</span>
                    </div>

                    <div className="text-[11px] text-purple-400 font-medium mt-1">
                      {stock.stochSignal} (%K {stock.stochK} / %D {stock.stochD})
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-gray-400 mt-2 font-mono">
                      <span>Quality: {stock.stochQuality}</span>
                      <span>20 EMA Confluence: {stock.isStochAtEmaSupport ? 'Yes' : 'No'}</span>
                    </div>

                    <div className="flex items-center justify-between gap-2 mt-2 pt-2 border-t border-[#30363d]">
                      <button
                        onClick={(e) => { e.stopPropagation(); onOpenChart(stock); }}
                        className="text-[10px] text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1"
                      >
                        Chart <ChevronRight className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); onOpenPaperTrade(stock); }}
                        className="text-[10px] text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1"
                      >
                        Paper Trade <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
