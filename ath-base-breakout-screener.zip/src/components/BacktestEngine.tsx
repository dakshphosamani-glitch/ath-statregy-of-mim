import { useState, useMemo } from 'react';
import { Stock, BacktestStrategyConfig, BacktestTrade, BacktestMetrics, Timeframe, MarketRegime } from '../types';
import { runBacktest, DEFAULT_STRATEGY_CONFIG } from '../utils/technicalAnalysis';
import { 
  Sliders, 
  TrendingUp, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  BarChart3, 
  Layers, 
  ShieldCheck, 
  RefreshCw, 
  ExternalLink,
  ChevronRight,
  TrendingDown,
  Info,
  Bot,
  Zap,
  Cpu,
  Sparkles
} from 'lucide-react';

interface BacktestEngineProps {
  stocks: Stock[];
  selectedStockSymbol?: string;
  onSelectStockForChart: (symbol: string) => void;
}

export default function BacktestEngine({
  stocks,
  selectedStockSymbol,
  onSelectStockForChart,
}: BacktestEngineProps) {
  // Strategy Configuration State for Refinement
  const [config, setConfig] = useState<BacktestStrategyConfig>({
    ...DEFAULT_STRATEGY_CONFIG,
    timeframe: '1D',
  });

  const [targetAsset, setTargetAsset] = useState<string>(selectedStockSymbol || 'ALL');
  const [tradeFilter, setTradeFilter] = useState<'ALL' | 'SUCCESS' | 'FAILED' | 'BULLISH_DAY' | 'BEARISH_DAY' | 'STOCH_CONFIRMED'>('ALL');

  // Run the backtest whenever config or target asset changes
  const { trades, metrics } = useMemo(() => {
    return runBacktest(stocks, config, targetAsset);
  }, [stocks, config, targetAsset]);

  // Filtered trades for table display
  const filteredTrades = useMemo(() => {
    return trades.filter((trade) => {
      if (tradeFilter === 'SUCCESS') return trade.status === 'SUCCESS';
      if (tradeFilter === 'FAILED') return trade.status === 'FAILED';
      if (tradeFilter === 'BULLISH_DAY') return trade.marketRegime === 'Bullish Day';
      if (tradeFilter === 'BEARISH_DAY') return trade.marketRegime === 'Bearish Day';
      if (tradeFilter === 'STOCH_CONFIRMED') return trade.stochAtEntry ? trade.stochAtEntry.k >= trade.stochAtEntry.d : false;
      return true;
    });
  }, [trades, tradeFilter]);

  const resetConfig = () => {
    setConfig({
      ...DEFAULT_STRATEGY_CONFIG,
      timeframe: '1D',
      requireStochBullish: false,
    });
  };

  return (
    <div className="space-y-6">
      {/* Strategy Refinement Header & Controls */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between pb-4 border-b border-[#30363d] gap-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
                <Sliders className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Strategy Backtester & Parameter Refinement
              </h2>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Backtest the "10% ATH Strategy" (Momentum Breakout &amp; 20 EMA Dip-Buying within 10% of ATH) across historical bars. Refine stop-loss, targets, and analyze performance on Bullish vs Bearish market days.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={resetConfig}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg text-gray-300 bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Reset Defaults
            </button>
          </div>
        </div>

        {/* Autonomous AI Auto-Execution Engine Banner */}
        <div className="bg-gradient-to-r from-blue-950/60 via-[#161b22] to-cyan-950/50 border border-blue-500/40 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 mt-2">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/40 shrink-0">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  🤖 Autonomous AI Execution Engine
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Auto-Execution Active
                </span>
              </div>
              <p className="text-xs text-gray-300 mt-1 max-w-2xl leading-relaxed">
                The AI engine chronologically evaluates candle bars across real historical data. When strategy conditions trigger (<strong>ATH 10% Dip-Buy</strong> to rising 20 EMA or <strong>Aggressive Breakout</strong> above base resistance), it automatically executes entries and exits based on your structural rules without manual delay.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-cyan-300 bg-cyan-950/40 px-3 py-1.5 rounded-lg border border-cyan-500/30">
              Execution: Zero Slippage (Real Bars)
            </span>
          </div>
        </div>

        {/* Refinement Sliders & Parameters Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 pt-4">
          {/* 1. Target Stock Selection */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300 flex items-center justify-between">
              <span>Backtest Scope</span>
              <span className="text-blue-400 font-mono text-[11px]">{targetAsset}</span>
            </label>
            <select
              value={targetAsset}
              onChange={(e) => setTargetAsset(e.target.value)}
              className="w-full bg-[#161b22] border border-[#30363d] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 cursor-pointer"
            >
              <option value="ALL">All Screened Stocks & Indices</option>
              {stocks.map((s) => (
                <option key={s.id} value={s.symbol}>
                  {s.symbol} ({s.name})
                </option>
              ))}
            </select>
            <p className="text-[10px] text-gray-500">Run against entire watchlist or isolate a single asset</p>
          </div>

          {/* 2. Timeframe Selection */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300 flex items-center justify-between">
              <span>Timeframe</span>
              <span className="text-blue-400 font-mono text-[11px]">{config.timeframe}</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setConfig({ ...config, timeframe: '1D' })}
                className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                  config.timeframe === '1D'
                    ? 'bg-blue-600/20 text-blue-300 border-blue-500/50 shadow-sm'
                    : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                }`}
              >
                1D (Daily)
              </button>
              <button
                type="button"
                onClick={() => setConfig({ ...config, timeframe: '1W' })}
                className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                  config.timeframe === '1W'
                    ? 'bg-blue-600/20 text-blue-300 border-blue-500/50 shadow-sm'
                    : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                }`}
              >
                1W (Weekly)
              </button>
            </div>
            <p className="text-[10px] text-gray-500">Daily swings vs Multi-week positional bases</p>
          </div>

          {/* 3. Stop-Loss Refinement */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold text-gray-300">
              <span>Stop-Loss Buffer</span>
              <span className="text-rose-400 font-mono font-bold">-{config.stopLossPercent.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="2.0"
              max="10.0"
              step="0.5"
              value={config.stopLossPercent}
              onChange={(e) => setConfig({ ...config, stopLossPercent: parseFloat(e.target.value) })}
              className="w-full accent-rose-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-gray-500">
              <span>Tight (2%)</span>
              <span>Standard (4.5%)</span>
              <span>Loose (10%)</span>
            </div>
          </div>

          {/* 4. Profit Target Refinement */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold text-gray-300">
              <span>Profit Target</span>
              <span className="text-emerald-400 font-mono font-bold">+{config.targetPercent.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="5.0"
              max="30.0"
              step="1.0"
              value={config.targetPercent}
              onChange={(e) => setConfig({ ...config, targetPercent: parseFloat(e.target.value) })}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-gray-500">
              <span>Quick (5%)</span>
              <span>Swing (12%)</span>
              <span>Runner (30%)</span>
            </div>
          </div>

          {/* 5. Volume Surge Threshold */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold text-gray-300">
              <span>Breakout Volume Surge</span>
              <span className="text-amber-400 font-mono font-bold">≥ {config.volumeMultiplier.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="3.0"
              step="0.1"
              value={config.volumeMultiplier}
              onChange={(e) => setConfig({ ...config, volumeMultiplier: parseFloat(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-gray-500">
              <span>Avg (1.0x)</span>
              <span>Strong (1.5x)</span>
              <span>Climax (3.0x)</span>
            </div>
          </div>

          {/* 6. Proximity to ATH Max Distance */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold text-gray-300">
              <span>Max Distance to ATH</span>
              <span className="text-cyan-400 font-mono font-bold">≤ {config.maxDistToAth.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="2.0"
              max="15.0"
              step="0.5"
              value={config.maxDistToAth}
              onChange={(e) => setConfig({ ...config, maxDistToAth: parseFloat(e.target.value) })}
              className="w-full accent-cyan-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-gray-500">
              <span>Near High (2%)</span>
              <span>Mandate (10%)</span>
              <span>Loose (15%)</span>
            </div>
          </div>

          {/* 7. Market Regime Entry Filter */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300 flex items-center justify-between">
              <span>Market Regime Filter</span>
              <span className="text-purple-400 font-mono text-[10px]">{config.marketRegimeFilter}</span>
            </label>
            <select
              value={config.marketRegimeFilter}
              onChange={(e) => setConfig({ ...config, marketRegimeFilter: e.target.value as any })}
              className="w-full bg-[#161b22] border border-[#30363d] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 cursor-pointer"
            >
              <option value="ALL">All Market Conditions</option>
              <option value="BULLISH_ONLY">Bullish Days Only (Highest Edge)</option>
              <option value="NON_BEARISH">Exclude Bearish Days (Avoid Fakeouts)</option>
            </select>
            <p className="text-[10px] text-gray-500">Test how broader market trend prevents fakeouts</p>
          </div>

          {/* 8. 20 EMA Support Requirement */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300 flex items-center justify-between">
              <span>20 EMA Dynamic Support</span>
              <span className={config.requireEmaSupport ? 'text-emerald-400 font-mono text-[10px]' : 'text-gray-500 font-mono text-[10px]'}>
                {config.requireEmaSupport ? 'Enabled' : 'Disabled'}
              </span>
            </label>
            <div className="pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-gray-300 bg-[#161b22] px-3 py-2 rounded-lg border border-[#30363d] hover:bg-[#21262d]">
                <input
                  type="checkbox"
                  checked={config.requireEmaSupport}
                  onChange={(e) => setConfig({ ...config, requireEmaSupport: e.target.checked })}
                  className="rounded text-blue-600 focus:ring-0"
                />
                <span>Require Price &gt; Rising 20 EMA</span>
              </label>
            </div>
            <p className="text-[10px] text-gray-500">Filters out breakdowns where price lost moving average</p>
          </div>

          {/* 9. Stochastic %K >= %D Bullish Filter */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300 flex items-center justify-between">
              <span>Stochastic Oscillator Filter</span>
              <span className={config.requireStochBullish ? 'text-purple-400 font-mono text-[10px]' : 'text-gray-500 font-mono text-[10px]'}>
                {config.requireStochBullish ? 'Enforced' : 'Off'}
              </span>
            </label>
            <div className="pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-gray-300 bg-[#161b22] px-3 py-2 rounded-lg border border-purple-500/30 hover:bg-[#21262d]">
                <input
                  type="checkbox"
                  checked={!!config.requireStochBullish}
                  onChange={(e) => setConfig({ ...config, requireStochBullish: e.target.checked })}
                  className="rounded text-purple-600 focus:ring-0"
                />
                <span className="text-purple-200">Require %K &ge; %D at Breakout</span>
              </label>
            </div>
            <p className="text-[10px] text-gray-500">Eliminates setups where Stochastic momentum is turning bearish</p>
          </div>

          {/* 10. Autonomous Entry Strategy Approach */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300 flex items-center justify-between">
              <span>Strategy Entry Approach</span>
              <span className="text-cyan-400 font-mono text-[10px]">{config.entryApproach || 'BOTH'}</span>
            </label>
            <select
              value={config.entryApproach || 'BOTH'}
              onChange={(e) => setConfig({ ...config, entryApproach: e.target.value as any })}
              className="w-full bg-[#161b22] border border-[#30363d] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 cursor-pointer"
            >
              <option value="BOTH">Dual Confluence (Breakout + 20 EMA Support)</option>
              <option value="RETEST_BOUNCE">Price Action: Resistance Breakout &amp; Retest Bounce (🚀 🔄)</option>
              <option value="AGGRESSIVE_BREAKOUT">Approach A: Aggressive Breakout (Close &gt; Resistance)</option>
              <option value="DIP_BUYING_PULLBACK">Approach B: ATH 10% Dip-Buying (20 EMA Cushion)</option>
            </select>
            <p className="text-[10px] text-gray-500">
              Evaluates breakout above base resistance followed by a pullback retest bounce
            </p>
          </div>

          {/* 11. Fakeout Protection Architecture */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300 flex items-center justify-between">
              <span>Fakeout Protection (❌ Cut)</span>
              <span className={config.fakeoutImmediateCut !== false ? 'text-rose-400 font-mono text-[10px]' : 'text-gray-500 font-mono text-[10px]'}>
                {config.fakeoutImmediateCut !== false ? 'Active Protection' : 'Disabled'}
              </span>
            </label>
            <div className="pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-gray-300 bg-[#161b22] px-3 py-2 rounded-lg border border-[#30363d] hover:bg-[#21262d]">
                <input
                  type="checkbox"
                  checked={config.fakeoutImmediateCut !== false}
                  onChange={(e) => setConfig({ ...config, fakeoutImmediateCut: e.target.checked })}
                  className="rounded text-rose-500 focus:ring-0"
                />
                <span className="text-rose-200">Cut Trade If Price Falls Back Below Resistance (❌)</span>
              </label>
            </div>
            <p className="text-[10px] text-gray-500">
              Instant exit if stock pops above resistance (e.g. ₹113) but fails to hold and tumbles below (₹110 ❌)
            </p>
          </div>

          {/* 12. Structural Stop-Loss Protection */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-300 flex items-center justify-between">
              <span>Stop-Loss Architecture</span>
              <span className={config.useStructuralStopLoss !== false ? 'text-emerald-400 font-mono text-[10px]' : 'text-gray-500 font-mono text-[10px]'}>
                {config.useStructuralStopLoss !== false ? 'Structural SL' : 'Fixed Percent SL'}
              </span>
            </label>
            <div className="pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-gray-300 bg-[#161b22] px-3 py-2 rounded-lg border border-[#30363d] hover:bg-[#21262d]">
                <input
                  type="checkbox"
                  checked={config.useStructuralStopLoss !== false}
                  onChange={(e) => setConfig({ ...config, useStructuralStopLoss: e.target.checked })}
                  className="rounded text-blue-600 focus:ring-0"
                />
                <span>Anchor SL Below Base Structure Floor</span>
              </label>
            </div>
            <p className="text-[10px] text-gray-500">
              Places stop below recent higher low / base floor rather than arbitrary tight stop
            </p>
          </div>
        </div>

        {/* 10% Strategy Blueprint Card */}
        <div className="mt-5 p-4 rounded-xl bg-[#161b22] border border-blue-500/30">
          <div className="flex items-center justify-between pb-3 border-b border-[#30363d]">
            <div className="flex items-center gap-2">
              <div className="p-1 rounded bg-blue-500/20 text-blue-400">
                <Sliders className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                10% ATH Strategy Tested: Momentum Breakout &amp; 20 EMA Dip-Buy
              </span>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              10% Rules Fed to AI Engine
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3">
            {/* Stage 1 */}
            <div className="p-3 bg-[#0d1117] rounded-lg border border-[#30363d] font-mono text-[11px] text-gray-300 leading-tight">
              <div className="text-[10px] font-bold text-cyan-400 mb-1 flex items-center justify-between">
                <span>1. 10% ATH BREAKOUT</span>
                <span className="text-xs">🚀</span>
              </div>
              <pre className="text-[10px] text-gray-400 overflow-x-auto">
{`₹110 ─────── ATH / Pivot (≤10%)
      /\\   /\\  🚀 Breakout Entry
     /  \\ /  \\    ↑
₹100 ────────── 20 EMA Floor`}
              </pre>
            </div>

            {/* Stage 2 */}
            <div className="p-3 bg-[#0d1117] rounded-lg border border-emerald-500/30 font-mono text-[11px] text-gray-300 leading-tight">
              <div className="text-[10px] font-bold text-emerald-400 mb-1 flex items-center justify-between">
                <span>2. 20 EMA DIP-BUY</span>
                <span className="text-xs">🔄</span>
              </div>
              <pre className="text-[10px] text-emerald-300 overflow-x-auto">
{`₹115        🚀 2R Target
₹110 ──/─── Prior Pivot
      /
     ↓ Dip-Buy at 20 EMA -> Bounce`}
              </pre>
            </div>

            {/* Stage 3 */}
            <div className="p-3 bg-[#0d1117] rounded-lg border border-rose-500/30 font-mono text-[11px] text-gray-300 leading-tight">
              <div className="text-[10px] font-bold text-rose-400 mb-1 flex items-center justify-between">
                <span>3. STRUCTURAL SL</span>
                <span className="text-xs">🛡️</span>
              </div>
              <pre className="text-[10px] text-rose-300 overflow-x-auto">
{`    ₹113 (Extension)
      /\\
₹110 ─/──\\── Resistance
           \\ 🛡️ Cut Below 20 EMA`}
              </pre>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Performance Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total Trades */}
        <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5">
          <div className="text-[11px] font-semibold text-gray-400">Total Backtest Trades</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">{metrics.totalTrades}</div>
          <div className="text-[10px] text-gray-500 mt-1">Across historical data</div>
        </div>

        {/* Win Rate */}
        <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5">
          <div className="text-[11px] font-semibold text-gray-400">Strategy Win Rate</div>
          <div className={`text-2xl font-bold font-mono mt-1 ${
            metrics.winRate >= 70 ? 'text-emerald-400' : metrics.winRate >= 50 ? 'text-amber-400' : 'text-rose-400'
          }`}>
            {metrics.winRate}%
          </div>
          <div className="text-[10px] text-gray-400 mt-1 flex items-center gap-1.5">
            <span className="text-emerald-400 font-semibold">{metrics.successfulTrades} Wins</span>
            <span>•</span>
            <span className="text-rose-400 font-semibold">{metrics.failedTrades} Fails</span>
          </div>
        </div>

        {/* Profit Factor */}
        <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5">
          <div className="text-[11px] font-semibold text-gray-400">Profit Factor</div>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
            {metrics.profitFactor > 0 ? metrics.profitFactor.toFixed(2) : '—'}
          </div>
          <div className="text-[10px] text-gray-400 mt-1">Gross Wins / Gross Losses</div>
        </div>

        {/* Net Return % */}
        <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5">
          <div className="text-[11px] font-semibold text-gray-400">Net Return</div>
          <div className={`text-2xl font-bold font-mono mt-1 ${
            metrics.netPnlPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
          }`}>
            {metrics.netPnlPercent >= 0 ? '+' : ''}{metrics.netPnlPercent}%
          </div>
          <div className="text-[10px] text-gray-500 mt-1">Cumulative Strategy P&amp;L</div>
        </div>

        {/* Avg Win vs Avg Loss */}
        <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5">
          <div className="text-[11px] font-semibold text-gray-400">Avg Win / Loss</div>
          <div className="text-lg font-bold font-mono mt-1.5">
            <span className="text-emerald-400">+{metrics.avgWinPercent}%</span>
            <span className="text-gray-500 mx-1">/</span>
            <span className="text-rose-400">-{metrics.avgLossPercent}%</span>
          </div>
          <div className="text-[10px] text-gray-500 mt-1">R:R Ratio ~1:{(metrics.avgWinPercent / (metrics.avgLossPercent || 1)).toFixed(1)}</div>
        </div>

        {/* Max Drawdown */}
        <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5">
          <div className="text-[11px] font-semibold text-gray-400">Max Drawdown</div>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
            -{metrics.maxDrawdown}%
          </div>
          <div className="text-[10px] text-gray-500 mt-1">Peak-to-trough decline</div>
        </div>
      </div>

      {/* Market Regime Analysis (Bullish Day vs Bearish Day Edge) */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-5">
        <div className="flex items-center justify-between pb-3 border-b border-[#30363d]">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">
              Market Regime Edge: Bullish Day vs. Bearish Day Performance
            </h3>
          </div>
          <span className="text-xs text-gray-400 font-mono">
            Directly answers: Why trades fail or succeed
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4">
          {/* Bullish Day Breakouts */}
          <div className="bg-[#161b22] border border-emerald-500/30 rounded-xl p-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/5 rounded-bl-full pointer-events-none" />
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Bullish Day Entries
              </span>
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                {metrics.bullishDayWinRate}% Win Rate
              </span>
            </div>
            <div className="mt-3 space-y-1 text-xs">
              <div className="flex justify-between text-gray-300">
                <span>Trades Executed:</span>
                <span className="font-mono font-bold text-white">{metrics.bullishTradesCount}</span>
              </div>
              <div className="flex justify-between text-gray-300">
                <span>Follow-Through:</span>
                <span className="text-emerald-400 font-semibold">High Momentum &amp; Buying</span>
              </div>
              <p className="text-[11px] text-gray-400 pt-2 border-t border-[#30363d] mt-2">
                When broader indices are in a Bullish Day regime, ATH breakouts experience minimal fakeouts.
              </p>
            </div>
          </div>

          {/* Bearish Day Breakouts */}
          <div className="bg-[#161b22] border border-rose-500/30 rounded-xl p-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-rose-500/5 rounded-bl-full pointer-events-none" />
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-400 uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-400" />
                Bearish Day Entries
              </span>
              <span className="text-xs font-mono font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/30">
                {metrics.bearishDayWinRate}% Win Rate
              </span>
            </div>
            <div className="mt-3 space-y-1 text-xs">
              <div className="flex justify-between text-gray-300">
                <span>Trades Executed:</span>
                <span className="font-mono font-bold text-white">{metrics.bearishTradesCount}</span>
              </div>
              <div className="flex justify-between text-gray-300">
                <span>Primary Risk:</span>
                <span className="text-rose-400 font-semibold">High Fakeout Rate</span>
              </div>
              <p className="text-[11px] text-gray-400 pt-2 border-t border-[#30363d] mt-2">
                Breakouts into Bearish Days suffer from market drag, tripping stops quickly.
              </p>
            </div>
          </div>

          {/* Neutral / Choppy Days */}
          <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-300 uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-gray-400" />
                Neutral / Choppy
              </span>
              <span className="text-xs font-mono font-bold text-gray-300 bg-[#21262d] px-2 py-0.5 rounded border border-[#30363d]">
                {metrics.neutralDayWinRate}% Win Rate
              </span>
            </div>
            <div className="mt-3 space-y-1 text-xs">
              <div className="flex justify-between text-gray-300">
                <span>Stock-Specific:</span>
                <span className="font-semibold text-white">Dependent on Stock Vol</span>
              </div>
              <div className="flex justify-between text-gray-300">
                <span>Recommendation:</span>
                <span className="text-amber-400 font-semibold">2.0x+ Volume Confirmation</span>
              </div>
              <p className="text-[11px] text-gray-400 pt-2 border-t border-[#30363d] mt-2">
                On rangebound days, only trade setups with outsized volume and tight 20 EMA cushion.
              </p>
            </div>
          </div>

          {/* Stochastic Oscillator Confluence Edge */}
          <div className="bg-[#161b22] border border-purple-500/40 rounded-xl p-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-purple-500/5 rounded-bl-full pointer-events-none" />
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-300 uppercase tracking-wide flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-purple-400" />
                Stoch Confirmed
              </span>
              <span className="text-xs font-mono font-bold text-purple-300 bg-purple-500/15 px-2 py-0.5 rounded border border-purple-500/40">
                {metrics.stochConfirmedWinRate || metrics.winRate}% Win Rate
              </span>
            </div>
            <div className="mt-3 space-y-1 text-xs">
              <div className="flex justify-between text-gray-300">
                <span>Condition:</span>
                <span className="font-mono text-purple-300 font-semibold">%K &ge; %D at Breakout</span>
              </div>
              <div className="flex justify-between text-gray-300">
                <span>Advantage:</span>
                <span className="text-emerald-400 font-semibold">Oscillator Momentum Aligned</span>
              </div>
              <p className="text-[11px] text-gray-400 pt-2 border-t border-[#30363d] mt-2">
                Trades entering when Stochastic lines are crossing upward have significantly fewer early stop-outs.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Cumulative Equity Curve Chart */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-5">
        <div className="flex items-center justify-between pb-3 border-b border-[#30363d]">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Strategy Equity Growth Simulation (Starting Capital: ₹1,00,000)
            </h3>
            <p className="text-xs text-gray-400">Simulated portfolio equity through sequential breakout trades</p>
          </div>
          <div className="text-right">
            <div className="text-sm font-bold font-mono text-emerald-400">
              ₹{(metrics.equityCurve[metrics.equityCurve.length - 1]?.equity || 100000).toLocaleString('en-IN')}
            </div>
            <div className="text-[10px] text-gray-400">Ending Balance</div>
          </div>
        </div>

        {/* Equity Curve SVG */}
        <div className="pt-4 overflow-x-auto">
          {metrics.equityCurve.length > 1 ? (
            (() => {
              const pts = metrics.equityCurve;
              const svgWidth = 800;
              const svgHeight = 160;
              const padLeft = 40;
              const padRight = 60;
              const padY = 20;

              const values = pts.map(p => p.equity);
              const minEq = Math.min(...values) * 0.98;
              const maxEq = Math.max(...values) * 1.02;

              const eqToY = (val: number) => {
                const range = maxEq - minEq;
                if (range <= 0) return svgHeight / 2;
                return svgHeight - padY - ((val - minEq) / range) * (svgHeight - 2 * padY);
              };

              const xStep = (svgWidth - padLeft - padRight) / Math.max(1, pts.length - 1);

              const pathD = pts.reduce((d, pt, i) => {
                const x = padLeft + i * xStep;
                const y = eqToY(pt.equity);
                return i === 0 ? `M ${x} ${y}` : `${d} L ${x} ${y}`;
              }, '');

              const areaD = `${pathD} L ${padLeft + (pts.length - 1) * xStep} ${svgHeight - padY} L ${padLeft} ${svgHeight - padY} Z`;

              return (
                <svg width="100%" height={svgHeight} viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="overflow-visible">
                  <defs>
                    <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>
                  {/* Base line */}
                  <line
                    x1={padLeft}
                    y1={eqToY(100000)}
                    x2={svgWidth - padRight}
                    y2={eqToY(100000)}
                    stroke="#30363d"
                    strokeWidth="1"
                    strokeDasharray="4 4"
                  />
                  <text
                    x={svgWidth - padRight + 6}
                    y={eqToY(100000) + 4}
                    fill="#6e7681"
                    fontSize="9"
                    fontFamily="monospace"
                  >
                    ₹100k Base
                  </text>

                  {/* Area fill */}
                  <path d={areaD} fill="url(#eqGrad)" />

                  {/* Line */}
                  <path d={pathD} fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" />

                  {/* Points */}
                  {pts.map((pt, i) => {
                    const x = padLeft + i * xStep;
                    const y = eqToY(pt.equity);
                    return (
                      <circle
                        key={i}
                        cx={x}
                        cy={y}
                        r={3}
                        fill="#10b981"
                        stroke="#0d1117"
                        strokeWidth="1.5"
                      />
                    );
                  })}
                </svg>
              );
            })()
          ) : (
            <div className="py-8 text-center text-xs text-gray-500">
              Adjust refinement filters above to generate trade setups for the equity curve.
            </div>
          )}
        </div>
      </div>

      {/* Comprehensive Backtest Trade Log Table */}
      <div className="bg-[#0d1117] border border-[#30363d] rounded-xl overflow-hidden">
        <div className="p-4 border-b border-[#30363d] bg-[#161b22] flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <span>Backtest Execution Log</span>
              <span className="text-xs px-2 py-0.5 rounded-full font-mono bg-blue-500/10 text-blue-400 border border-blue-500/30">
                {filteredTrades.length} Trades Recorded
              </span>
            </h3>
            <p className="text-xs text-gray-400">Detailed record of every simulated trade: entries, targets, stops, and market regimes</p>
          </div>

          {/* Trade status filter */}
          <div className="flex items-center gap-1.5 bg-[#0d1117] p-1 rounded-lg border border-[#30363d] text-xs">
            <button
              onClick={() => setTradeFilter('ALL')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                tradeFilter === 'ALL' ? 'bg-[#21262d] text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              All Trades ({trades.length})
            </button>
            <button
              onClick={() => setTradeFilter('SUCCESS')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                tradeFilter === 'SUCCESS' ? 'bg-emerald-500/20 text-emerald-300' : 'text-gray-400 hover:text-emerald-300'
              }`}
            >
              Successful ({metrics.successfulTrades})
            </button>
            <button
              onClick={() => setTradeFilter('FAILED')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                tradeFilter === 'FAILED' ? 'bg-rose-500/20 text-rose-300' : 'text-gray-400 hover:text-rose-300'
              }`}
            >
              Failed ({metrics.failedTrades})
            </button>
            <button
              onClick={() => setTradeFilter('BULLISH_DAY')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                tradeFilter === 'BULLISH_DAY' ? 'bg-blue-500/20 text-blue-300' : 'text-gray-400 hover:text-blue-300'
              }`}
            >
              Bullish Day Entries
            </button>
            <button
              onClick={() => setTradeFilter('BEARISH_DAY')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                tradeFilter === 'BEARISH_DAY' ? 'bg-purple-500/20 text-purple-300' : 'text-gray-400 hover:text-purple-300'
              }`}
            >
              Bearish Day Entries
            </button>
            <button
              onClick={() => setTradeFilter('STOCH_CONFIRMED')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                tradeFilter === 'STOCH_CONFIRMED' ? 'bg-cyan-500/20 text-cyan-300' : 'text-gray-400 hover:text-cyan-300'
              }`}
            >
              Stoch %K &ge; %D
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#30363d] bg-[#161b22]/50 text-gray-400 font-semibold select-none">
                <th className="py-2.5 px-3">Symbol &amp; Name</th>
                <th className="py-2.5 px-3">Timeframe</th>
                <th className="py-2.5 px-3">Entry Date &amp; Price</th>
                <th className="py-2.5 px-3">Exit Date &amp; Price</th>
                <th className="py-2.5 px-3">Stoch at Entry</th>
                <th className="py-2.5 px-3">Stop / Target</th>
                <th className="py-2.5 px-3">P&amp;L Result</th>
                <th className="py-2.5 px-3">Market Condition on Entry</th>
                <th className="py-2.5 px-3">Exit Classification</th>
                <th className="py-2.5 px-3 text-right">View</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {filteredTrades.length === 0 ? (
                <tr>
                  <td colSpan={10} className="text-center py-8 text-gray-500">
                    No backtest trades match this filter. Try adjusting parameters above.
                  </td>
                </tr>
              ) : (
                filteredTrades.map((trade) => {
                  const isSuccess = trade.status === 'SUCCESS';

                  return (
                    <tr
                      key={trade.id}
                      className="hover:bg-[#161b22]/60 transition-colors group cursor-pointer"
                      onClick={() => onSelectStockForChart(trade.symbol)}
                    >
                      {/* Symbol */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-white group-hover:text-blue-400 transition-colors">
                            {trade.symbol}
                          </span>
                        </div>
                        <div className="text-[10px] text-gray-400 truncate max-w-[140px]">
                          {trade.name}
                        </div>
                        <div className="flex items-center gap-1 mt-1">
                          <span className="text-[9px] px-1.5 py-0.2 rounded font-semibold font-mono bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 flex items-center gap-0.5">
                            <Bot className="w-2.5 h-2.5" /> AI Executed
                          </span>
                        </div>
                      </td>

                      {/* Timeframe */}
                      <td className="py-3 px-3 font-mono text-[11px] text-gray-300">
                        {trade.timeframe}
                      </td>

                      {/* Entry */}
                      <td className="py-3 px-3 font-mono">
                        <div className="text-white font-semibold">₹{trade.entryPrice}</div>
                        <div className="text-[10px] text-gray-400">{trade.entryDate}</div>
                        {trade.entryType && (
                          <div className="mt-1">
                            <span className="inline-block px-1.5 py-0.2 rounded text-[9px] font-sans font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                              {trade.entryType}
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Exit */}
                      <td className="py-3 px-3 font-mono">
                        <div className="text-white font-semibold">₹{trade.exitPrice}</div>
                        <div className="text-[10px] text-gray-400">{trade.exitDate}</div>
                      </td>

                      {/* Stoch at Entry */}
                      <td className="py-3 px-3 font-mono">
                        {trade.stochAtEntry ? (
                          <div>
                            <div className="flex items-center gap-1 text-[11px]">
                              <span className="text-cyan-400 font-semibold">%K:{trade.stochAtEntry.k}</span>
                              <span className="text-gray-500">/</span>
                              <span className="text-amber-400 font-semibold">%D:{trade.stochAtEntry.d}</span>
                            </div>
                            <span className={`inline-block px-1.5 py-0.2 text-[10px] rounded font-sans mt-0.5 border ${
                              trade.stochAtEntry.k >= trade.stochAtEntry.d
                                ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                                : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                            }`}>
                              {trade.stochAtEntry.signal}
                            </span>
                          </div>
                        ) : (
                          <span className="text-gray-500 text-[11px]">—</span>
                        )}
                      </td>

                      {/* Stop / Target */}
                      <td className="py-3 px-3 font-mono text-[11px]">
                        <div className="text-rose-400 flex items-center gap-1">
                          <span>SL: ₹{trade.stopLoss}</span>
                          {config.useStructuralStopLoss !== false && (
                            <span className="text-[9px] font-sans text-amber-300/80">(Structural)</span>
                          )}
                        </div>
                        <div className="text-emerald-400">TP: ₹{trade.target}</div>
                      </td>

                      {/* P&L */}
                      <td className="py-3 px-3 font-mono">
                        <div className={`font-bold flex items-center gap-1 ${
                          isSuccess ? 'text-emerald-400' : 'text-rose-400'
                        }`}>
                          {isSuccess ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                          {trade.pnlPercent >= 0 ? '+' : ''}{trade.pnlPercent}%
                        </div>
                        <span className={`inline-block px-1.5 py-0.2 text-[10px] rounded font-semibold uppercase mt-0.5 ${
                          isSuccess
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                        }`}>
                          {trade.status}
                        </span>
                      </td>

                      {/* Market Regime */}
                      <td className="py-3 px-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium ${
                          trade.marketRegime === 'Bullish Day'
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            : trade.marketRegime === 'Bearish Day'
                            ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                            : 'bg-gray-500/15 text-gray-300 border border-gray-500/30'
                        }`}>
                          <span className="w-1.5 h-1.5 rounded-full bg-current" />
                          {trade.marketRegime}
                        </span>
                        <div className="text-[10px] text-gray-500 mt-0.5">
                          {trade.holdingBars} bars held
                        </div>
                      </td>

                      {/* Exit Reason */}
                      <td className="py-3 px-3 text-gray-300">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`font-semibold ${
                            trade.exitReason.includes('Fakeout') ? 'text-rose-400' : 'text-white'
                          }`}>
                            {trade.exitReason}
                          </span>
                          {trade.patternStage === 'RETEST_BOUNCE' && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                              🔄 20 EMA Bounce
                            </span>
                          )}
                          {trade.patternStage === 'FAKEOUT_FAILED' && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                              🛡️ Stop-Loss Cut
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-gray-400 max-w-[220px] truncate">
                          {trade.patternNotes}
                        </div>
                      </td>

                      {/* View Action */}
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectStockForChart(trade.symbol);
                          }}
                          className="p-1 rounded text-gray-400 hover:text-white hover:bg-[#21262d] transition-colors"
                          title="Open Chart for this trade"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
