import React, { useState } from 'react';
import { UserProfile } from '../types';
import { 
  TrendingUp, 
  Mail, 
  User, 
  DollarSign, 
  ShieldAlert, 
  ShieldCheck,
  CheckCircle2, 
  ArrowRight, 
  Layers, 
  Sparkles,
  Award,
  Zap,
  Target,
  X,
  Lock,
  Eye,
  EyeOff
} from 'lucide-react';
import { soundEffects } from '../utils/audioAlert';
import { recordUserSession, isMasterCredentials, MASTER_EMAIL, verifyUserCredentials, isEmailBlocked } from '../utils/userRegistry';

interface OnboardingScreenProps {
  onComplete: (profile: UserProfile) => void;
  initialData?: UserProfile | null;
  onCancel?: () => void;
}

export default function OnboardingScreen({ onComplete, initialData, onCancel }: OnboardingScreenProps) {
  const [name, setName] = useState(initialData?.name || '');
  const [gmail, setGmail] = useState(initialData?.gmail || '');
  const [password, setPassword] = useState(initialData?.password || '');
  const [showPassword, setShowPassword] = useState(false);
  const [experience, setExperience] = useState<UserProfile['experience']>(
    initialData?.experience || 'Intermediate'
  );
  const [initialCapital, setInitialCapital] = useState<number>(
    initialData?.initialCapital || 1000000
  );
  const [customCapitalInput, setCustomCapitalInput] = useState<string>('');
  const [riskPerTradePercent, setRiskPerTradePercent] = useState<number>(
    initialData?.riskPerTradePercent || 2
  );
  const [preferredTimeframe, setPreferredTimeframe] = useState<'1D' | '1W'>(
    initialData?.preferredTimeframe || '1D'
  );

  const [errors, setErrors] = useState<{ name?: string; gmail?: string; password?: string; general?: string }>({});

  const isMasterAccountEntered = isMasterCredentials(gmail, password) || gmail.trim().toLowerCase() === MASTER_EMAIL.toLowerCase();
  const isMasterPasswordCorrect = isMasterCredentials(gmail, password);
  const isBlocked = isEmailBlocked(gmail.trim().toLowerCase());

  const validate = () => {
    const newErrors: { name?: string; gmail?: string; password?: string; general?: string } = {};
    if (!name.trim()) {
      newErrors.name = 'Please enter your name to personalize your terminal';
    }
    if (!gmail.trim()) {
      newErrors.gmail = 'Gmail address is required for alert sync and account records';
    } else if (!gmail.includes('@')) {
      newErrors.gmail = 'Please enter a valid email address (e.g. name@gmail.com)';
    }
    if (!password.trim()) {
      newErrors.password = 'Please set your permanent terminal account password';
    } else if (password.trim().length < 4) {
      newErrors.password = 'Password must be at least 4 characters long';
    }

    // Verify against registry (checks permanent password & blocked status)
    if (gmail.trim() && password.trim()) {
      const verification = verifyUserCredentials(gmail.trim(), password.trim());
      if (!verification.success && verification.error) {
        newErrors.gmail = verification.error;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const finalCapital = customCapitalInput && Number(customCapitalInput) > 0 
      ? Number(customCapitalInput) 
      : initialCapital;

    const rawProfile: UserProfile = {
      id: initialData?.id || `trader-${gmail.trim().split('@')[0]}-${Math.floor(100 + Math.random() * 900)}`,
      name: name.trim(),
      gmail: gmail.trim(),
      password: password.trim(),
      experience,
      initialCapital: finalCapital,
      riskPerTradePercent,
      preferredTimeframe,
      savedAt: new Date().toISOString(),
    };

    // Store in global registry & check master credentials
    const registeredProfile = recordUserSession(rawProfile, password.trim());

    soundEffects.playAlertChime();
    onComplete(registeredProfile);
  };

  return (
    <div className="min-h-screen bg-[#080c10] text-gray-100 flex flex-col justify-center items-center p-4 sm:p-6 relative overflow-hidden">
      {/* Background Subtle Gradient Accents */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-2xl bg-[#0d1117] border border-[#30363d] rounded-2xl shadow-2xl overflow-hidden relative z-10">
        {/* Terminal Header */}
        <div className="p-6 sm:p-8 bg-gradient-to-b from-[#161b22] to-[#0d1117] border-b border-[#30363d] relative">
          {onCancel && (
            <button
              onClick={onCancel}
              className="absolute top-6 right-6 p-2 rounded-xl bg-[#21262d] text-gray-400 hover:text-white border border-[#30363d] transition-colors"
              title="Close and return to terminal"
            >
              <X className="w-4 h-4" />
            </button>
          )}

          <div className="flex items-center gap-3 mb-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-blue-600 to-emerald-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  BreakoutPulse Terminal
                </h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  ATH &lt;10% Setup
                </span>
              </div>
              <p className="text-xs sm:text-sm text-gray-400 mt-0.5">
                High Tight Base Breakout, 20 EMA Support &amp; Real-Time Paper Trading
              </p>
            </div>
          </div>

          <div className="mt-4 p-3.5 bg-[#080c10]/70 rounded-xl border border-[#30363d] flex items-center gap-3 text-xs text-gray-300">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Welcome!</strong> Before accessing the real-time stock screener and paper trading simulator, please enter your details below to initialize your personal account.
            </span>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
          {/* Section 1: Personal Credentials */}
          <div className="space-y-4">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-blue-400" />
              Trader Identity &amp; Notification Channel
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                  Full Name <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Aarav Sharma"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors({ ...errors, name: undefined });
                    }}
                    className={`w-full bg-[#161b22] border rounded-xl pl-9 pr-3 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all ${
                      errors.name ? 'border-rose-500' : 'border-[#30363d]'
                    }`}
                  />
                </div>
                {errors.name && (
                  <p className="text-[11px] text-rose-400 mt-1">{errors.name}</p>
                )}
              </div>

              {/* Gmail Address */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                  Gmail Address <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    required
                    placeholder="e.g. trader99@gmail.com"
                    value={gmail}
                    onChange={(e) => {
                      setGmail(e.target.value);
                      if (errors.gmail) setErrors({ ...errors, gmail: undefined });
                    }}
                    className={`w-full bg-[#161b22] border rounded-xl pl-9 pr-3 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all ${
                      errors.gmail ? 'border-rose-500' : 'border-[#30363d]'
                    }`}
                  />
                </div>
                {errors.gmail && (
                  <p className="text-[11px] text-rose-400 mt-1">{errors.gmail}</p>
                )}
                {isBlocked && (
                  <div className="mt-2 p-2 rounded-lg bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>This Gmail ID has been blocked from the website by Administrator Daksh.</span>
                  </div>
                )}
              </div>
            </div>

            {/* Account Password Field */}
            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1.5 flex items-center justify-between">
                <span>Permanent Account Password <span className="text-rose-400">*</span></span>
                <span className="text-[10px] text-gray-400 font-medium">
                  Permanent access key
                </span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Create or enter your permanent password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errors.password) setErrors({ ...errors, password: undefined });
                  }}
                  className={`w-full bg-[#161b22] border rounded-xl pl-9 pr-10 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all ${
                    errors.password ? 'border-rose-500' : 'border-[#30363d]'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-gray-400 mt-1 flex items-center gap-1">
                <span>The password entered here will be permanently tied to this Gmail account.</span>
              </p>
              {errors.password && (
                <p className="text-[11px] text-rose-400 mt-1">{errors.password}</p>
              )}
            </div>

            {/* Master Account Status Indicator */}
            {isMasterAccountEntered && (
              <div className={`p-3.5 rounded-xl border text-xs flex items-start gap-3 transition-all ${
                isMasterPasswordCorrect
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-200'
                  : 'bg-blue-950/30 border-blue-500/30 text-blue-200'
              }`}>
                {isMasterPasswordCorrect ? (
                  <>
                    <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold text-amber-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5" />
                        VIP Master Administrator Verified!
                      </div>
                      <p className="text-[11px] text-amber-200/90 mt-0.5 leading-relaxed">
                        Master authorization granted for <strong>{MASTER_EMAIL}</strong>. You will have full privileged access to all user profiles, global trade histories, live activity feeds, and the exclusive ATL 10% reversal radar.
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <Lock className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold text-white">Master Account ID Recognized</div>
                      <p className="text-[11px] text-gray-300 mt-0.5 leading-relaxed">
                        Enter your master credentials password (<strong>Daksh2011</strong>) to unlock the exclusive Master Terminal with complete user tracking and trade intelligence.
                      </p>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Section 2: Trading Experience & Strategy Preferences */}
          <div className="space-y-4 pt-2 border-t border-[#21262d]">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-purple-400" />
              Trading Experience &amp; Timeframe
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Experience Level */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                  Experience Level
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Beginner', 'Intermediate', 'Advanced Swing Trader'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setExperience(lvl)}
                      className={`px-2.5 py-2 text-xs font-medium rounded-xl border text-center transition-all ${
                        experience === lvl
                          ? 'bg-blue-600/20 text-blue-300 border-blue-500 font-semibold'
                          : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                      }`}
                    >
                      {lvl === 'Advanced Swing Trader' ? 'Advanced' : lvl}
                    </button>
                  ))}
                </div>
              </div>

              {/* Preferred Timeframe */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                  Default Screener Timeframe
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPreferredTimeframe('1D')}
                    className={`px-3 py-2 text-xs rounded-xl border font-medium transition-all ${
                      preferredTimeframe === '1D'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-semibold'
                        : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                    }`}
                  >
                    Daily (1D) — High Tight Base
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreferredTimeframe('1W')}
                    className={`px-3 py-2 text-xs rounded-xl border font-medium transition-all ${
                      preferredTimeframe === '1W'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-semibold'
                        : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                    }`}
                  >
                    Weekly (1W) — Macro Trend
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Paper Trading Virtual Capital Setup */}
          <div className="space-y-4 pt-2 border-t border-[#21262d]">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
              Paper Trading Virtual Account Setup
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Virtual Starting Capital */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                  Starting Virtual Capital
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[500000, 1000000, 2500000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => {
                        setInitialCapital(amt);
                        setCustomCapitalInput('');
                      }}
                      className={`py-2 px-1 text-xs rounded-xl border font-mono font-semibold transition-all ${
                        initialCapital === amt && !customCapitalInput
                          ? 'bg-emerald-600/20 text-emerald-300 border-emerald-500'
                          : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                      }`}
                    >
                      ₹{(amt / 100000).toFixed(0)} Lakhs
                    </button>
                  ))}
                </div>
                <div className="mt-2">
                  <input
                    type="number"
                    placeholder="Or enter custom capital (₹)..."
                    value={customCapitalInput}
                    onChange={(e) => setCustomCapitalInput(e.target.value)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg px-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Risk per Trade */}
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5 flex items-center justify-between">
                  <span>Risk Per Trade</span>
                  <span className="text-emerald-400 font-mono font-bold text-xs">{riskPerTradePercent}% of Capital</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[1, 2, 3].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setRiskPerTradePercent(pct)}
                      className={`py-2 text-xs rounded-xl border font-medium transition-all ${
                        riskPerTradePercent === pct
                          ? 'bg-blue-600/20 text-blue-300 border-blue-500 font-semibold'
                          : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
                      }`}
                    >
                      {pct}% {pct === 1 ? '(Conservative)' : pct === 2 ? '(Optimal)' : '(Aggressive)'}
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-gray-500 mt-2">
                  Auto-calculates maximum shares per breakout setup to preserve your capital.
                </p>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-3">
            <button
              type="submit"
              className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-600 text-white font-bold text-sm shadow-lg shadow-blue-600/25 hover:shadow-blue-600/40 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 group cursor-pointer"
            >
              <span>Unlock Terminal &amp; Open Screener</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <p className="text-center text-[11px] text-gray-500 mt-2">
              All settings are safely stored locally. You can update your profile or reset paper capital anytime.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}
