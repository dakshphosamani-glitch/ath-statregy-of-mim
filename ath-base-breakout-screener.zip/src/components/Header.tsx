import { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  BarChart2, 
  Layers, 
  Bell, 
  Sliders, 
  Star, 
  Volume2, 
  VolumeX, 
  Radio, 
  Flame, 
  ExternalLink,
  ShieldCheck,
  Wallet,
  Gauge,
  User,
  LogOut,
  Bot,
  Sparkles,
  Key,
  RefreshCw,
  Trophy
} from 'lucide-react';
import { Stock, AlertRule, UserProfile } from '../types';
import { rankStocksByStrategy } from '../utils/strategyRanking';

export type ActiveTabType = 'screener' | 'dual-condition' | 'stoch' | 'paper-trade' | 'backtest' | 'watchlists' | 'admin';

interface HeaderProps {
  activeTab: ActiveTabType;
  onTabChange: (tab: ActiveTabType) => void;
  stocks: Stock[];
  alerts: AlertRule[];
  isSimulatingMarket: boolean;
  onToggleSimulatingMarket: () => void;
  isSoundEnabled: boolean;
  onToggleSound: () => void;
  onSelectStock: (stock: Stock) => void;
  userProfile: UserProfile | null;
  onEditProfile: () => void;
  onLogout?: () => void;
  onOpenAiChatbot?: () => void;
  onOpenIdAdministration?: () => void;
  onForceSync?: () => void;
}

export default function Header({
  activeTab,
  onTabChange,
  stocks,
  alerts,
  isSimulatingMarket,
  onToggleSimulatingMarket,
  isSoundEnabled,
  onToggleSound,
  onSelectStock,
  userProfile,
  onEditProfile,
  onLogout,
  onOpenAiChatbot,
  onOpenIdAdministration,
  onForceSync,
}: HeaderProps) {
  const [showAlertDropdown, setShowAlertDropdown] = useState(false);

  const isMaster = Boolean(
    userProfile?.isMasterUser ||
    userProfile?.gmail?.toLowerCase() === 'dakshphosamani@gmail.com'
  );

  const triggeredAlerts = alerts.filter(a => a.triggered);
  const ranked = useMemo(() => rankStocksByStrategy(stocks), [stocks]);
  const bestStockEval = ranked[0];
  const secondBestEval = ranked[1];

  return (
    <header className="sticky top-0 z-40 bg-[#0d1117]/95 backdrop-blur-md border-b border-[#30363d]">
      {/* Top Ticker Bar */}
      <div className="bg-[#080c10] border-b border-[#21262d] px-4 py-1.5 flex items-center justify-between text-[11px] font-mono overflow-x-auto text-gray-400 gap-6">
        <div className="flex items-center gap-5 shrink-0">
          <span className="flex items-center gap-1.5 text-gray-400 font-sans font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Market Pulse: <strong className="text-emerald-400 font-mono">BULLISH DAY REGIME</strong>
          </span>

          {/* Dynamic Top Strategy Setup (#1 calculated across the 2 strategies) */}
          {bestStockEval && (
            <div 
              onClick={() => onSelectStock(bestStockEval.stock)}
              className="flex items-center gap-1.5 cursor-pointer hover:text-white transition-colors bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded"
              title={bestStockEval.reason}
            >
              <Trophy className="w-3 h-3 text-amber-400" />
              <span className="text-amber-300 font-bold">Top Setup ({bestStockEval.stock.symbol}):</span>
              <span className="text-white font-semibold">₹{bestStockEval.stock.currentPrice.toLocaleString()}</span>
              <span className={`font-medium ${bestStockEval.stock.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {bestStockEval.stock.changePercent >= 0 ? `+${bestStockEval.stock.changePercent.toFixed(2)}%` : `${bestStockEval.stock.changePercent.toFixed(2)}%`}
              </span>
              <span className="text-[10px] px-1 bg-amber-500/20 text-amber-300 rounded font-mono">
                {bestStockEval.badgeLabel}
              </span>
            </div>
          )}

          {/* Dynamic Runner-up Strategy Setup (#2) */}
          {secondBestEval && (
            <div 
              onClick={() => onSelectStock(secondBestEval.stock)}
              className="flex items-center gap-1.5 cursor-pointer hover:text-white transition-colors"
              title={secondBestEval.reason}
            >
              <span className="text-cyan-300 font-bold">{secondBestEval.stock.symbol}:</span>
              <span className="text-white font-semibold">₹{secondBestEval.stock.currentPrice.toLocaleString()}</span>
              <span className={`font-medium ${secondBestEval.stock.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {secondBestEval.stock.changePercent >= 0 ? `+${secondBestEval.stock.changePercent.toFixed(2)}%` : `${secondBestEval.stock.changePercent.toFixed(2)}%`}
              </span>
              <span className="text-[10px] px-1 bg-emerald-500/10 text-emerald-400 rounded font-mono">
                {secondBestEval.badgeLabel}
              </span>
            </div>
          )}

          {/* Real-time status indicator & Sync */}
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              LIVE REAL-TIME (&lt;5s DELAY)
            </span>
            {onForceSync && (
              <button
                onClick={onForceSync}
                className="px-2 py-0.5 rounded bg-[#161b22] hover:bg-[#21262d] text-gray-300 hover:text-white text-[10px] border border-[#30363d] transition-all flex items-center gap-1"
                title="Force refresh live stock quotes"
              >
                <RefreshCw className="w-2.5 h-2.5" />
                <span>Sync Now</span>
              </button>
            )}
          </div>
        </div>

          {/* 10% Strategy Tag */}
          <div className="hidden md:flex items-center gap-1 text-gray-500">
            <span>•</span>
            <span>Strategy: <strong>10% ATH Strategy (≤10% to ATH + 20 EMA Support)</strong></span>
          </div>

          {/* Creator Badge & Quick Email */}
          <button
            onClick={() => {
              const el = document.getElementById('creator-footer');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hidden lg:flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/30 transition-colors cursor-pointer"
            title="Daksh Phosamani • Class 9 Student & Developer • Click to view highlights & contact"
          >
            <span>👨‍💻 Created by Daksh (Class 9)</span>
            <span className="text-gray-500">•</span>
            <span className="underline">dakshphosamani@gmail.com</span>
          </button>

        {/* Live Simulator Status */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onToggleSimulatingMarket}
            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold transition-all ${
              isSimulatingMarket
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse'
                : 'bg-[#161b22] text-gray-400 border border-[#30363d] hover:text-white'
            }`}
          >
            <Radio className="w-3 h-3" />
            {isSimulatingMarket ? 'LIVE FEED ACTIVE' : 'SIMULATE TICKS'}
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-emerald-500 flex items-center justify-center shadow-md shadow-emerald-950">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-extrabold text-white tracking-tight">
                BreakoutPulse
              </h1>
              <span className="text-[10px] px-1.5 py-0.2 rounded font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                10% ATH STRATEGY
              </span>
            </div>
            <p className="text-[11px] text-gray-400">
              10% ATH Momentum &amp; 20 EMA Pullback Strategy Terminal
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center bg-[#161b22] p-1 rounded-xl border border-[#30363d] text-xs font-semibold overflow-x-auto max-w-full">
          <button
            onClick={() => onTabChange('screener')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'screener'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white hover:bg-[#21262d]'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            10% Strategy Screener &amp; Charts
          </button>

          <button
            onClick={() => onTabChange('stoch')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'stoch'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white hover:bg-[#21262d]'
            }`}
          >
            <Gauge className="w-3.5 h-3.5 text-purple-300" />
            Stock Momentum Screener
          </button>

          <button
            onClick={() => onTabChange('paper-trade')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'paper-trade'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white hover:bg-[#21262d]'
            }`}
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-300" />
            Real-Time Paper Trade
          </button>

          {/* Algorithmic Strategy Backtester */}
          <button
            onClick={() => onTabChange('backtest')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'backtest'
                ? 'bg-blue-600 text-white shadow-sm font-semibold'
                : 'text-gray-400 hover:text-white hover:bg-[#21262d]'
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-blue-400" />
            <span>AI Backtester</span>
          </button>

          <button
            onClick={() => onTabChange('watchlists')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'watchlists'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white hover:bg-[#21262d]'
            }`}
          >
            <Star className="w-3.5 h-3.5" />
            Watchlists &amp; Alerts
          </button>

          {/* Exclusive Master Supervisor Access for Daksh (dakshphosamani@gmail.com) */}
          {isMaster && (
            <button
              onClick={() => onTabChange('admin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition-all border ${
                activeTab === 'admin'
                  ? 'bg-amber-600 text-white shadow-md border-amber-400 font-bold'
                  : 'text-amber-300 hover:text-white bg-amber-500/10 border-amber-500/30 hover:bg-amber-500/20'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
              <span>Master Supervisor</span>
              <span className="text-[9px] px-1 py-0.2 rounded bg-amber-400/20 text-amber-200 font-mono font-bold">
                DAKSH ID
              </span>
            </button>
          )}

          {/* 1-Click Administration of IDs button */}
          {isMaster && onOpenIdAdministration && (
            <button
              onClick={onOpenIdAdministration}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition-all border border-amber-500/40 bg-gradient-to-r from-amber-600/30 to-amber-700/30 hover:from-amber-600/50 hover:to-amber-700/50 text-amber-200 text-xs font-bold shadow"
              title="1-Click: Open entire ID Directory with all IDs, gmails, and permanent passwords"
            >
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span>Administration of IDs</span>
              <span className="text-[9px] px-1 py-0.2 rounded bg-amber-400 text-black font-bold font-mono">
                1-CLICK
              </span>
            </button>
          )}
        </nav>

        {/* Header Action Tools */}
        <div className="flex items-center gap-2">
          {/* User Profile Badge */}
          {userProfile && (
            <button
              onClick={onEditProfile}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-[#161b22] border border-[#30363d] hover:border-blue-500/40 text-xs transition-colors"
              title="Click to view/update your profile & trading plan"
            >
              <div className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-300 border border-blue-500/40 flex items-center justify-center font-bold text-[10px]">
                {userProfile.name ? userProfile.name.charAt(0).toUpperCase() : 'U'}
              </div>
              <div className="text-left hidden sm:block">
                <div className="font-semibold text-white leading-tight truncate max-w-[90px]">{userProfile.name}</div>
                <div className="text-[10px] text-gray-400 leading-tight">₹{(userProfile.initialCapital / 100000).toFixed(1)}L Cap</div>
              </div>
            </button>
          )}

          {/* AI Mentor Quick Button */}
          {onOpenAiChatbot && (
            <button
              id="header-btn-ai-mentor"
              onClick={onOpenAiChatbot}
              className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30 text-blue-300 hover:text-white hover:border-blue-400 text-xs font-semibold transition-all"
              title="Open AI Strategy & Feature Mentor"
            >
              <Bot className="w-3.5 h-3.5 text-blue-400" />
              <span>AI Mentor</span>
            </button>
          )}

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className={`p-2 rounded-lg border transition-colors ${
              isSoundEnabled
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                : 'bg-[#161b22] text-gray-400 border-[#30363d] hover:text-white'
            }`}
            title={isSoundEnabled ? 'Alert Chime Sound: ON' : 'Alert Chime Sound: MUTED'}
          >
            {isSoundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Real-time Alerts Notification Bell */}
          <div className="relative">
            <button
              onClick={() => setShowAlertDropdown(!showAlertDropdown)}
              className="p-2 rounded-lg bg-[#161b22] border border-[#30363d] text-gray-300 hover:text-white hover:bg-[#21262d] transition-colors relative"
            >
              <Bell className="w-4 h-4" />
              {triggeredAlerts.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center animate-bounce">
                  {triggeredAlerts.length}
                </span>
              )}
            </button>

            {/* Notification Dropdown */}
            {showAlertDropdown && (
              <div className="absolute right-0 mt-2 w-80 bg-[#161b22] border border-[#30363d] rounded-xl shadow-2xl z-50 p-3 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-[#30363d]">
                  <span className="font-bold text-white">Alert Notifications</span>
                  <span className="text-[10px] text-gray-400">{alerts.length} Rules Configured</span>
                </div>
                <div className="py-2 max-h-60 overflow-y-auto space-y-1.5">
                  {alerts.length === 0 ? (
                    <div className="text-center py-4 text-gray-500 text-xs">No alerts configured</div>
                  ) : (
                    alerts.map((a) => (
                      <div
                        key={a.id}
                        className={`p-2 rounded-lg border text-left ${
                          a.triggered
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                            : 'bg-[#0d1117] border-[#30363d] text-gray-400'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white">{a.symbol}</span>
                          <span className="text-[10px] font-mono">
                            {a.triggered ? 'TRIGGERED' : 'MONITORING'}
                          </span>
                        </div>
                        <div className="text-[11px] text-gray-300 mt-0.5">{a.condition}</div>
                      </div>
                    ))
                  )}
                </div>
                <div className="pt-2 border-t border-[#30363d]">
                  <button
                    onClick={() => {
                      setShowAlertDropdown(false);
                      onTabChange('watchlists');
                    }}
                    className="w-full py-1.5 text-center text-xs text-blue-400 hover:text-blue-300 font-semibold"
                  >
                    Manage All Watchlists &amp; Alerts →
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* User Logout Button */}
          {onLogout && (
            <button
              id="header-btn-logout"
              onClick={onLogout}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-600 hover:text-white border border-rose-500/25 text-rose-300 text-xs font-semibold transition-all"
              title="Log out of current account"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Log Out</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
