import { useState, useMemo } from 'react';
import { Stock, Timeframe, PatternStatus, MarketRegime } from '../types';
import { evaluateStockConditions } from '../utils/conditionEvaluator';
import { rankStocksByStrategy } from '../utils/strategyRanking';
import { 
  Filter, 
  Search, 
  TrendingUp, 
  Layers, 
  CheckCircle2, 
  Clock, 
  Bell, 
  Star, 
  Flame, 
  ArrowUpRight, 
  SlidersHorizontal,
  BookmarkPlus,
  Play,
  Wallet,
  Target,
  Gauge,
  Sparkles
} from 'lucide-react';

interface ScreenerTableProps {
  stocks: Stock[];
  selectedStockId: string;
  onSelectStock: (stock: Stock) => void;
  timeframe: Timeframe;
  onTimeframeChange: (tf: Timeframe) => void;
  onOpenBacktestWithStock: (stock: Stock) => void;
  onAddToWatchlist: (stockId: string) => void;
  onOpenAlertModal: (stock: Stock) => void;
  onPaperTradeStock?: (stock: Stock) => void;
  watchlistStockIds: string[];
  isMaster?: boolean;
}

export default function ScreenerTable({
  stocks,
  selectedStockId,
  onSelectStock,
  timeframe,
  onTimeframeChange,
  onOpenBacktestWithStock,
  onAddToWatchlist,
  onOpenAlertModal,
  onPaperTradeStock,
  watchlistStockIds,
  isMaster = false,
}: ScreenerTableProps) {
  // 10% Strategy Filter Option: ALL_10 (All stocks fulfilling 10% strategy) | TIGHT_5 (<=5% to ATH) | BREAKOUT_2 (<=2% to ATH) | EMA_SUPPORT | ALL (Unfiltered)
  const [conditionFilter, setConditionFilter] = useState<'ALL_10' | 'TIGHT_5' | 'BREAKOUT_2' | 'EMA_SUPPORT' | 'ALL'>('ALL_10');

  // 2-Option Scope: All Stocks vs Nearest Stocks (Default: ALL)
  const [scopeFilter, setScopeFilter] = useState<'ALL' | 'NEAREST'>('ALL');

  const [searchTerm, setSearchTerm] = useState('');
  const [maxAthFilter, setMaxAthFilter] = useState<number>(10); // Default <= 10% to ATH
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [assetTypeFilter, setAssetTypeFilter] = useState<string>('ALL');
  const [regimeFilter, setRegimeFilter] = useState<string>('ALL');
  const [stochFilter, setStochFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'distToAth' | 'volumeRatio' | 'patternConfidence' | 'changePercent'>('distToAth');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Dynamic Best Strategy Stock across universe
  const bestStrategyStockId = useMemo(() => rankStocksByStrategy(stocks)[0]?.stock?.id, [stocks]);

  // Counts for 10% Strategy filters
  const conditionCounts = useMemo(() => {
    let tenPercentCount = 0;
    let tightCount = 0;
    let breakoutCount = 0;
    let emaCount = 0;
    for (const s of stocks) {
      if (s.distToAth <= 10 && s.currentPrice >= s.supportEma * 0.97) tenPercentCount++;
      if (s.distToAth <= 5) tightCount++;
      if (s.distToAth <= 2) breakoutCount++;
      if (s.currentPrice >= s.supportEma) emaCount++;
    }
    return { tenPercentCount, tightCount, breakoutCount, emaCount };
  }, [stocks]);

  // Count of nearest stocks (<= 3.5% from ATH or right at pivot)
  const nearestStocksCount = useMemo(() => {
    return stocks.filter(
      (s) => s.distToAth <= 3.5 || Math.abs(s.currentPrice - s.baseResistance) / s.baseResistance <= 0.025
    ).length;
  }, [stocks]);

  // Filtered & Sorted Stocks
  const filteredStocks = useMemo(() => {
    return stocks
      .filter((stock) => {
        // 10% Strategy Filter
        if (conditionFilter === 'ALL_10') {
          if (stock.distToAth > 10 || stock.currentPrice < stock.supportEma * 0.97) return false;
        } else if (conditionFilter === 'TIGHT_5') {
          if (stock.distToAth > 5) return false;
        } else if (conditionFilter === 'BREAKOUT_2') {
          if (stock.distToAth > 2) return false;
        } else if (conditionFilter === 'EMA_SUPPORT') {
          if (stock.currentPrice < stock.supportEma) return false;
        }

        // 2-Option Filter: If NEAREST STOCKS selected, filter to setups closest to ATH or breakout pivot
        if (scopeFilter === 'NEAREST') {
          const isNearAth = stock.distToAth <= 3.5;
          const isNearPivot = Math.abs(stock.currentPrice - stock.baseResistance) / stock.baseResistance <= 0.025;
          if (!isNearAth && !isNearPivot) return false;
        }

        // Search filter
        if (searchTerm) {
          const term = searchTerm.toLowerCase();
          const match = stock.symbol.toLowerCase().includes(term) || stock.name.toLowerCase().includes(term);
          if (!match) return false;
        }

        // Distance to ATH filter (<= 10% as requested)
        if (maxAthFilter < 100 && stock.distToAth > maxAthFilter) {
          return false;
        }

        // Strategy status filter
        if (statusFilter !== 'ALL' && stock.patternStatus !== statusFilter) {
          return false;
        }

        // Strategy focus filter (ATH 10% vs ATL 10% Rebound)
        if (assetTypeFilter === 'ATL_10') {
          if (stock.distToAtl === undefined || stock.distToAtl > 15) return false;
        } else if (assetTypeFilter === 'ATH_10') {
          if (stock.distToAth > 10) return false;
        }

        // Market Regime filter
        if (regimeFilter !== 'ALL' && stock.marketRegime !== regimeFilter) {
          return false;
        }

        // Stochastic Filter
        if (stochFilter === 'BULLISH') {
          const isBull = stock.stochSignal === 'Bullish Crossover' || stock.stochSignal === 'Oversold Hook';
          if (!isBull) return false;
        } else if (stochFilter === 'OVERSOLD') {
          if (stock.stochK === undefined || stock.stochK > 35) return false;
        } else if (stochFilter === 'OVERBOUGHT') {
          if (stock.stochK === undefined || stock.stochK < 75) return false;
        }

        return true;
      })
      .sort((a, b) => {
        let valA = a[sortBy];
        let valB = b[sortBy];
        if (sortOrder === 'asc') {
          return valA > valB ? 1 : -1;
        } else {
          return valA < valB ? 1 : -1;
        }
      });
  }, [stocks, scopeFilter, searchTerm, maxAthFilter, statusFilter, assetTypeFilter, regimeFilter, stochFilter, sortBy, sortOrder]);

  const toggleSort = (field: typeof sortBy) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  return (
    <div className="bg-[#0d1117] border border-[#30363d] rounded-xl flex flex-col overflow-hidden">
      {/* Screener Header & Filter Controls */}
      <div className="p-4 border-b border-[#30363d] bg-[#161b22] space-y-4">
        {/* Top Title & 2-Option Scope Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Filter className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                All-Time High Base Screener
                <span className="text-xs px-2 py-0.5 rounded-full font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  {filteredStocks.length} Results
                </span>
              </h2>
              <p className="text-xs text-gray-400">
                {scopeFilter === 'ALL'
                  ? `Displaying all ${stocks.length} stocks & indices within 10% of ATH with 20 EMA support`
                  : `Showing ${filteredStocks.length} nearest candidates right at resistance pivot or ≤3.5% from ATH`}
              </p>
            </div>
          </div>

          {/* User Requested 2 Options: All Stocks vs Nearest Stocks */}
          <div className="flex items-center p-1 bg-[#0d1117] rounded-xl border border-[#30363d]">
            <button
              onClick={() => setScopeFilter('ALL')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                scopeFilter === 'ALL'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-gray-400 hover:text-white hover:bg-[#161b22]'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>All Stocks ({stocks.length})</span>
            </button>
            <button
              onClick={() => setScopeFilter('NEAREST')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                scopeFilter === 'NEAREST'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-gray-400 hover:text-white hover:bg-[#161b22]'
              }`}
            >
              <Target className="w-3.5 h-3.5" />
              <span>Nearest Stocks ({nearestStocksCount})</span>
              <span className="text-[10px] px-1 py-0.2 rounded bg-black/40 font-mono text-emerald-200">
                Imminent
              </span>
            </button>
          </div>

          {/* Timeframe selector (1D vs 1W) */}
          <div className="flex items-center bg-[#0d1117] p-1 rounded-lg border border-[#30363d]">
            <button
              onClick={() => onTimeframeChange('1D')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                timeframe === '1D'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Day (1D)
            </button>
            <button
              onClick={() => onTimeframeChange('1W')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                timeframe === '1W'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Week (1W)
            </button>
          </div>
        </div>

        {/* 10% Strategy Filter Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-1.5 bg-[#0d1117] rounded-xl border border-[#30363d]">
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-semibold">
            <span className="text-gray-400 text-[11px] font-mono px-2 py-0.5">10% Strategy:</span>
            
            <button
              onClick={() => setConditionFilter('ALL_10')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                conditionFilter === 'ALL_10'
                  ? 'bg-blue-600 text-white shadow font-bold'
                  : 'text-gray-400 hover:text-white hover:bg-[#161b22]'
              }`}
              title="All stocks meeting the 10% ATH Strategy (≤10% to ATH holding 20 EMA)"
            >
              <TrendingUp className="w-3.5 h-3.5 text-blue-300" />
              <span>≤10% ATH Strategy ({conditionCounts.tenPercentCount})</span>
            </button>

            <button
              onClick={() => setConditionFilter('TIGHT_5')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                conditionFilter === 'TIGHT_5'
                  ? 'bg-cyan-600 text-white shadow font-bold'
                  : 'text-gray-400 hover:text-white hover:bg-[#161b22]'
              }`}
              title="Tight pullbacks within 5% of All-Time High"
            >
              <Target className="w-3.5 h-3.5 text-cyan-300" />
              <span>Tight Pullbacks ≤5% ({conditionCounts.tightCount})</span>
            </button>

            <button
              onClick={() => setConditionFilter('BREAKOUT_2')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                conditionFilter === 'BREAKOUT_2'
                  ? 'bg-emerald-600 text-white shadow font-bold'
                  : 'text-gray-400 hover:text-white hover:bg-[#161b22]'
              }`}
              title="Breakout & at All-Time Highs (≤2% from ATH)"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              <span>At Highs / Breakout ≤2% ({conditionCounts.breakoutCount})</span>
            </button>

            <button
              onClick={() => setConditionFilter('EMA_SUPPORT')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                conditionFilter === 'EMA_SUPPORT'
                  ? 'bg-purple-600 text-white shadow font-bold'
                  : 'text-gray-400 hover:text-white hover:bg-[#161b22]'
              }`}
              title="Stocks holding firm above rising 20 EMA support"
            >
              <Layers className="w-3.5 h-3.5 text-purple-300" />
              <span>Above 20 EMA ({conditionCounts.emaCount})</span>
            </button>
          </div>

          <button
            onClick={() => setConditionFilter('ALL')}
            className={`px-2.5 py-1 text-xs rounded-lg transition-all cursor-pointer ${
              conditionFilter === 'ALL'
                ? 'bg-gray-700 text-white font-bold'
                : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            All Universe ({stocks.length})
          </button>
        </div>

        {/* Filter Pills Bar */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          {/* Search Box */}
          <div className="relative min-w-[200px] flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search ticker or company..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0d1117] border border-[#30363d] rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Distance to ATH Filter */}
          <div className="flex items-center gap-1 bg-[#0d1117] px-2.5 py-1.5 rounded-lg border border-[#30363d]">
            <span className="text-gray-400 text-[11px]">ATH Distance:</span>
            <select
              value={maxAthFilter}
              onChange={(e) => setMaxAthFilter(Number(e.target.value))}
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer"
            >
              <option value={10} className="bg-[#161b22]">≤ 10% to ATH (Mandate)</option>
              <option value={5} className="bg-[#161b22]">≤ 5% to ATH (Tight)</option>
              <option value={2} className="bg-[#161b22]">≤ 2% to ATH (At Highs)</option>
              <option value={100} className="bg-[#161b22]">All Stocks</option>
            </select>
          </div>

          {/* Strategy / Proximity Setup Filter */}
          <div className="flex items-center gap-1 bg-[#0d1117] px-2.5 py-1.5 rounded-lg border border-[#30363d]">
            <span className="text-gray-400 text-[11px]">Strategy:</span>
            <select
              value={assetTypeFilter}
              onChange={(e) => setAssetTypeFilter(e.target.value)}
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-[#161b22]">All Stocks</option>
              <option value="ATH_10" className="bg-[#161b22]">≤10% to ATH (10% Strategy)</option>
              <option value="ATL_10" className="bg-[#161b22]">≤10% to ATL (Value Turnaround)</option>
            </select>
          </div>

          {/* 10% Strategy Setup Stage Filter */}
          <div className="flex items-center gap-1 bg-[#0d1117] px-2.5 py-1.5 rounded-lg border border-[#30363d]">
            <span className="text-gray-400 text-[11px]">Strategy Stage:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-[#161b22]">All Stages</option>
              <option value="Breakout Confirmed" className="bg-[#161b22]">Breakout Confirmed</option>
              <option value="Base Forming / Near Pivot" className="bg-[#161b22]">Base Forming / Near Pivot</option>
              <option value="Testing 20 EMA" className="bg-[#161b22]">Testing 20 EMA</option>
            </select>
          </div>

          {/* Market Regime Filter */}
          <div className="flex items-center gap-1 bg-[#0d1117] px-2.5 py-1.5 rounded-lg border border-[#30363d]">
            <span className="text-gray-400 text-[11px]">Day Regime:</span>
            <select
              value={regimeFilter}
              onChange={(e) => setRegimeFilter(e.target.value)}
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-[#161b22]">All Regimes</option>
              <option value="Bullish Day" className="bg-[#161b22]">Bullish Day (Higher Win Rate)</option>
              <option value="Bearish Day" className="bg-[#161b22]">Bearish Day (Higher Fakeout Risk)</option>
              <option value="Neutral Day" className="bg-[#161b22]">Neutral Day</option>
            </select>
          </div>

          {/* Stock Oscillator (14, 3) Filter */}
          <div className="flex items-center gap-1 bg-[#0d1117] px-2.5 py-1.5 rounded-lg border border-purple-500/30">
            <span className="text-purple-400 text-[11px] font-semibold">Stock Oscillator:</span>
            <select
              value={stochFilter}
              onChange={(e) => setStochFilter(e.target.value)}
              className="bg-transparent text-purple-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-[#161b22]">All Stock States</option>
              <option value="BULLISH" className="bg-[#161b22]">Bullish Cross / Hook</option>
              <option value="OVERSOLD" className="bg-[#161b22]">Oversold (%K &lt; 35)</option>
              <option value="OVERBOUGHT" className="bg-[#161b22]">Power Zone (%K &gt; 75)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-[#30363d] bg-[#161b22]/50 text-gray-400 font-semibold select-none">
              <th className="py-2.5 px-3">Stock Symbol</th>
              <th className="py-2.5 px-3">LTP / Change</th>
              <th 
                className="py-2.5 px-3 cursor-pointer hover:text-white"
                onClick={() => toggleSort('distToAth')}
              >
                <div className="flex items-center gap-1">
                  % to ATH / ATL
                  {sortBy === 'distToAth' && (
                    <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>
                  )}
                </div>
              </th>
              <th className="py-2.5 px-3">Pivot / 20 EMA</th>
              <th className="py-2.5 px-3">10% Strategy Stage</th>
              <th className="py-2.5 px-3">Stock Oscillator (14, 3)</th>
              <th 
                className="py-2.5 px-3 cursor-pointer hover:text-white"
                onClick={() => toggleSort('volumeRatio')}
              >
                <div className="flex items-center gap-1">
                  Volume Surge
                  {sortBy === 'volumeRatio' && (
                    <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>
                  )}
                </div>
              </th>
              <th className="py-2.5 px-3">Market Regime</th>
              <th className="py-2.5 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#21262d]">
            {filteredStocks.length === 0 ? (
              <tr>
                <td colSpan={9} className="text-center py-8 text-gray-500">
                  No stocks match the current 10% Strategy filter criteria (≤10% to ATH with 20 EMA support).
                </td>
              </tr>
            ) : (
              filteredStocks.map((stock) => {
                const isSelected = stock.id === selectedStockId;
                const isSaved = watchlistStockIds.includes(stock.id);
                const isTopStrategyPick = stock.id === bestStrategyStockId;

                return (
                  <tr
                    key={stock.id}
                    onClick={() => onSelectStock(stock)}
                    className={`cursor-pointer transition-colors group ${
                      isSelected
                        ? 'bg-blue-600/15 border-l-2 border-l-blue-500'
                        : 'hover:bg-[#161b22]/80'
                    }`}
                  >
                    {/* Symbol & Name */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onAddToWatchlist(stock.id);
                          }}
                          className={`p-1 rounded hover:bg-[#21262d] transition-colors ${
                            isSaved ? 'text-amber-400' : 'text-gray-500'
                          }`}
                          title={isSaved ? 'In Watchlist' : 'Add to Watchlist'}
                        >
                          <Star className={`w-3.5 h-3.5 ${isSaved ? 'fill-amber-400' : ''}`} />
                        </button>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-white tracking-wide group-hover:text-blue-400 transition-colors">
                              {stock.symbol}
                            </span>
                            <span className="text-[10px] px-1.5 py-0.2 rounded font-mono bg-[#21262d] text-gray-300 border border-[#30363d]">
                              {stock.exchange}
                            </span>
                            {(() => {
                              const condEval = evaluateStockConditions(stock);
                              if (condEval.isBothMet) {
                                return (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded font-bold bg-amber-500/25 text-amber-300 border border-amber-500/40">
                                    CONFLUENCE
                                  </span>
                                );
                              } else if (condEval.isStrategy10Met || condEval.isPatternMet) {
                                return (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40">
                                    10% ATH
                                  </span>
                                );
                              } else if (condEval.isStochMet) {
                                return (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
                                    MOMENTUM
                                  </span>
                                );
                              }
                              return null;
                            })()}
                            {isTopStrategyPick && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                ⭐ Top Strategy Pick
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-gray-400 truncate max-w-[200px]">
                            {stock.name}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Price & Change */}
                    <td className="py-3 px-3 font-mono">
                      <div className="text-white font-semibold">
                        ₹{stock.currentPrice.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </div>
                      <div className={`text-[11px] font-medium flex items-center gap-0.5 ${
                        stock.change >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {stock.change >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%
                      </div>
                    </td>

                    {/* Proximity to ATH & ATL */}
                    <td className="py-3 px-3">
                      <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-mono text-[11px] font-bold border bg-emerald-500/10 text-emerald-300 border-emerald-500/30">
                        {stock.distToAth.toFixed(1)}% below ATH
                      </div>
                      {stock.distToAtl !== undefined && stock.distToAtl <= 15 && (
                        <div className="mt-1">
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded font-mono text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                            {stock.distToAtl.toFixed(1)}% to ATL (Rebound)
                          </span>
                        </div>
                      )}
                      <div className="text-[10px] text-gray-400 mt-0.5 font-mono flex items-center justify-between">
                        <span>ATH: ₹{stock.ath.toLocaleString()}</span>
                        {stock.atl && <span className="text-gray-400">ATL: ₹{stock.atl}</span>}
                      </div>
                    </td>

                    {/* Base Pivot & 20 EMA */}
                    <td className="py-3 px-3 font-mono text-[11px]">
                      <div className="text-amber-300 flex items-center gap-1">
                        <span className="text-gray-500 text-[10px]">Pivot:</span>
                        ₹{stock.baseResistance}
                      </div>
                      <div className="text-rose-400 flex items-center gap-1">
                        <span className="text-gray-500 text-[10px]">20 EMA:</span>
                        ₹{stock.supportEma}
                      </div>
                    </td>

                    {/* 10% Strategy Stage Badge */}
                    <td className="py-3 px-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium ${
                        stock.patternStatus === 'Breakout Confirmed'
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-950'
                          : stock.patternStatus === 'Base Forming / Near Pivot'
                          ? 'bg-amber-500/15 text-amber-300 border border-amber-500/40'
                          : 'bg-blue-500/15 text-blue-300 border border-blue-500/40'
                      }`}>
                        <span className="w-1.5 h-1.5 rounded-full bg-current" />
                        {stock.patternStatus}
                      </span>
                      <div className="text-[10px] text-gray-400 mt-0.5">
                        ≤10% ATH Rule ({stock.distToAth}% to ATH)
                      </div>
                    </td>

                    {/* Stochastic (14, 3) Cell */}
                    <td className="py-3 px-3 font-mono">
                      {stock.stochK !== undefined ? (
                        <div>
                          <div className="flex items-center gap-1 text-[11px]">
                            <span className="text-cyan-400 font-semibold">%K:{stock.stochK}</span>
                            <span className="text-gray-500">/</span>
                            <span className="text-amber-400 font-semibold">%D:{stock.stochD}</span>
                          </div>
                          {stock.stochSignal && (
                            <span className={`inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded text-[10px] font-sans mt-0.5 border ${
                              stock.stochSignal === 'Bullish Crossover' || stock.stochSignal === 'Oversold Hook'
                                ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                                : 'bg-gray-800 text-gray-400 border-gray-700'
                            }`}>
                              {stock.stochSignal}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-500 text-[11px]">-</span>
                      )}
                    </td>

                    {/* Volume Surge Ratio */}
                    <td className="py-3 px-3 font-mono">
                      <div className="flex items-center gap-1.5">
                        <span className={`font-bold ${
                          stock.volumeRatio >= 2.0 ? 'text-emerald-400' : stock.volumeRatio >= 1.5 ? 'text-blue-400' : 'text-gray-300'
                        }`}>
                          {stock.volumeRatio.toFixed(1)}x
                        </span>
                        {stock.volumeRatio >= 2.0 && (
                          <Flame className="w-3.5 h-3.5 text-amber-400" />
                        )}
                      </div>
                      <div className="w-16 h-1.5 bg-[#21262d] rounded-full overflow-hidden mt-1">
                        <div
                          className="h-full bg-emerald-500 rounded-full"
                          style={{ width: `${Math.min(100, (stock.volumeRatio / 3) * 100)}%` }}
                        />
                      </div>
                    </td>

                    {/* Market Regime */}
                    <td className="py-3 px-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium ${
                        stock.marketRegime === 'Bullish Day'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : stock.marketRegime === 'Bearish Day'
                          ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                          : 'bg-gray-500/15 text-gray-300 border border-gray-500/30'
                      }`}>
                        <span className="w-1.5 h-1.5 rounded-full bg-current" />
                        {stock.marketRegime}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenAlertModal(stock);
                          }}
                          className="p-1.5 rounded-md text-gray-400 hover:text-white hover:bg-[#21262d] transition-colors"
                          title="Set Alert for Breakout"
                        >
                          <Bell className="w-3.5 h-3.5" />
                        </button>

                        {isMaster && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenBacktestWithStock(stock);
                            }}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 transition-colors"
                            title="Backtest this setup (Master ID Exclusive)"
                          >
                            <Play className="w-3 h-3" />
                            Backtest
                          </button>
                        )}

                        {onPaperTradeStock && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onPaperTradeStock(stock);
                            }}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-600/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-600/30 transition-colors"
                            title="Execute paper trade on this stock"
                          >
                            <Wallet className="w-3 h-3" />
                            Paper Trade
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
