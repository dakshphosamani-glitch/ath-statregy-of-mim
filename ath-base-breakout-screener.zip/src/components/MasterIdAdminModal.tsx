import { useState, useMemo } from 'react';
import { UserProfile } from '../types';
import { 
  getRegisteredUsers, 
  toggleBlockEmail, 
  isEmailBlocked, 
  deleteUserAccount,
  MASTER_EMAIL 
} from '../utils/userRegistry';
import { soundEffects } from '../utils/audioAlert';
import { 
  ShieldCheck, 
  X, 
  Search, 
  Key, 
  Eye, 
  EyeOff, 
  Copy, 
  Check, 
  Ban, 
  Unlock, 
  Trash2, 
  Users, 
  FileSpreadsheet,
  Download,
  AlertTriangle
} from 'lucide-react';

interface MasterIdAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MasterIdAdminModal({ isOpen, onClose }: MasterIdAdminModalProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAllPasswords, setShowAllPasswords] = useState(false);
  const [passwordVisibilityMap, setPasswordVisibilityMap] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [copyAllStatus, setCopyAllStatus] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Load registered users directly from registry
  const users = useMemo(() => {
    return getRegisteredUsers();
  }, [refreshKey, isOpen]);

  // Filtered list
  const filteredUsers = useMemo(() => {
    if (!searchTerm.trim()) return users;
    const term = searchTerm.toLowerCase();
    return users.filter(
      (u) =>
        u.id.toLowerCase().includes(term) ||
        u.name.toLowerCase().includes(term) ||
        u.gmail.toLowerCase().includes(term)
    );
  }, [users, searchTerm]);

  if (!isOpen) return null;

  const handleToggleBlock = (email: string) => {
    toggleBlockEmail(email);
    soundEffects.playAlertChime();
    setRefreshKey((prev) => prev + 1);
  };

  const handleDeleteUser = (userId: string) => {
    deleteUserAccount(userId);
    setDeleteConfirmId(null);
    soundEffects.playAlertChime();
    setRefreshKey((prev) => prev + 1);
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCopyAllData = () => {
    const header = `ID\tNAME\tGMAIL\tPASSWORD\tSTATUS\tCAPITAL\tREGISTERED`;
    const rows = users.map((u) => {
      const isBlocked = isEmailBlocked(u.gmail);
      const pass = u.password || 'Tr@der2026';
      const reg = u.savedAt ? new Date(u.savedAt).toLocaleDateString() : 'N/A';
      return `${u.id}\t${u.name}\t${u.gmail}\t${pass}\t${isBlocked ? 'BLOCKED' : 'ACTIVE'}\t₹${u.initialCapital}\t${reg}`;
    });
    const content = [header, ...rows].join('\n');
    navigator.clipboard.writeText(content);
    setCopyAllStatus(true);
    soundEffects.playAlertChime();
    setTimeout(() => setCopyAllStatus(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#0d1117] border border-amber-500/40 rounded-2xl w-full max-w-6xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden relative">
        
        {/* Modal Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-[#161b22] via-[#1a1f2c] to-[#161b22] border-b border-[#30363d] flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-white shadow-lg shadow-amber-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                  Master ID Administration Directory
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  DAKSH MASTER ACCESS
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">
                Instant 1-Click Directory: View all registered IDs, Gmails, permanent passwords, and access statuses.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyAllData}
              className="px-3 py-1.5 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-200 text-xs font-semibold border border-[#30363d] transition-all flex items-center gap-1.5"
              title="Copy entire database to clipboard"
            >
              {copyAllStatus ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
              <span>{copyAllStatus ? 'Copied All to Clipboard!' : 'Copy All Accounts (CSV)'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-400 hover:text-white border border-[#30363d] transition-colors"
              title="Close Directory"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Action Controls & Search Toolbar */}
        <div className="p-4 bg-[#11151c] border-b border-[#21262d] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 flex-1 min-w-[260px] max-w-md">
            <div className="relative w-full">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input
                type="text"
                placeholder="Search by ID, name, or Gmail..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-[#161b22] border border-[#30363d] rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowAllPasswords(!showAllPasswords)}
              className="px-3 py-1.5 rounded-lg bg-[#161b22] border border-[#30363d] text-xs font-semibold text-gray-300 hover:text-white transition-all flex items-center gap-1.5"
            >
              {showAllPasswords ? <EyeOff className="w-3.5 h-3.5 text-amber-400" /> : <Eye className="w-3.5 h-3.5 text-amber-400" />}
              <span>{showAllPasswords ? 'Mask Passwords' : 'Show All Passwords'}</span>
            </button>

            <div className="text-xs text-gray-400 font-mono flex items-center gap-2">
              <span className="px-2 py-1 rounded bg-[#161b22] border border-[#30363d]">
                Total: <strong className="text-white">{users.length}</strong>
              </span>
              <span className="px-2 py-1 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-300">
                Active: <strong className="text-emerald-400">{users.filter(u => !isEmailBlocked(u.gmail)).length}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Directory Table */}
        <div className="flex-1 overflow-y-auto p-4">
          {filteredUsers.length === 0 ? (
            <div className="p-12 text-center text-gray-500">
              <Users className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p className="text-sm">No registered trader accounts found matching &quot;{searchTerm}&quot;</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-[#21262d]">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-[#161b22] text-gray-400 font-medium uppercase text-[10px] tracking-wider border-b border-[#21262d]">
                    <th className="py-3 px-3">Trader ID</th>
                    <th className="py-3 px-3">Trader Name</th>
                    <th className="py-3 px-3">Gmail Address</th>
                    <th className="py-3 px-3">Permanent Password</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 px-3 text-right">Capital</th>
                    <th className="py-3 px-3 text-right">Risk %</th>
                    <th className="py-3 px-3">Registered Date</th>
                    <th className="py-3 px-3 text-center">Master Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21262d] font-mono">
                  {filteredUsers.map((u) => {
                    const isDaksh = u.gmail.toLowerCase() === MASTER_EMAIL.toLowerCase();
                    const isBlocked = isEmailBlocked(u.gmail);
                    const isPassVisible = showAllPasswords || passwordVisibilityMap[u.id] || false;
                    const userPass = u.password || 'Tr@der2026';

                    return (
                      <tr
                        key={u.id}
                        className={`hover:bg-[#161b22]/70 transition-colors ${
                          isBlocked
                            ? 'bg-rose-950/20'
                            : isDaksh
                            ? 'bg-amber-500/5'
                            : ''
                        }`}
                      >
                        {/* Trader ID */}
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-amber-300 font-mono text-[11px]">
                              {u.id}
                            </span>
                            <button
                              onClick={() => handleCopy(u.id, `id-${u.id}`)}
                              className="text-gray-500 hover:text-white"
                              title="Copy ID"
                            >
                              {copiedId === `id-${u.id}` ? (
                                <Check className="w-3 h-3 text-emerald-400" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </td>

                        {/* Name */}
                        <td className="py-3 px-3 font-sans font-semibold text-white">
                          <div className="flex items-center gap-1.5">
                            <span>{u.name}</span>
                            {isDaksh && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                OWNER
                              </span>
                            )}
                          </div>
                        </td>

                        {/* Gmail */}
                        <td className="py-3 px-3 text-gray-300 font-sans">
                          <div className="flex items-center gap-1.5">
                            <span>{u.gmail}</span>
                            <button
                              onClick={() => handleCopy(u.gmail, `gmail-${u.id}`)}
                              className="text-gray-500 hover:text-white"
                              title="Copy Gmail"
                            >
                              {copiedId === `gmail-${u.id}` ? (
                                <Check className="w-3 h-3 text-emerald-400" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </td>

                        {/* Permanent Password */}
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1.5 bg-[#090d13] px-2 py-1 rounded border border-[#21262d] max-w-[170px]">
                            <Key className="w-3 h-3 text-amber-400 shrink-0" />
                            <span className="font-mono text-amber-300 font-bold text-xs truncate flex-1">
                              {isPassVisible ? userPass : '••••••••'}
                            </span>
                            <button
                              onClick={() =>
                                setPasswordVisibilityMap((prev) => ({
                                  ...prev,
                                  [u.id]: !prev[u.id],
                                }))
                              }
                              className="p-0.5 text-gray-400 hover:text-white"
                              title={isPassVisible ? 'Hide password' : 'Show permanent password'}
                            >
                              {isPassVisible ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                            </button>
                            <button
                              onClick={() => handleCopy(userPass, `pass-${u.id}`)}
                              className="p-0.5 text-gray-400 hover:text-white"
                              title="Copy permanent password"
                            >
                              {copiedId === `pass-${u.id}` ? (
                                <Check className="w-3 h-3 text-emerald-400" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </td>

                        {/* Status */}
                        <td className="py-3 px-3">
                          {isBlocked ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1 w-fit">
                              <Ban className="w-2.5 h-2.5" /> Blocked
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 w-fit">
                              <Check className="w-2.5 h-2.5" /> Active
                            </span>
                          )}
                        </td>

                        {/* Capital */}
                        <td className="py-3 px-3 text-right text-emerald-400 font-semibold font-mono">
                          ₹{u.initialCapital.toLocaleString()}
                        </td>

                        {/* Risk */}
                        <td className="py-3 px-3 text-right text-gray-400 font-mono">
                          {u.riskPerTradePercent}%
                        </td>

                        {/* Registered */}
                        <td className="py-3 px-3 text-gray-400 text-[11px] font-sans">
                          {u.savedAt ? new Date(u.savedAt).toLocaleString(undefined, {
                            dateStyle: 'short',
                            timeStyle: 'short'
                          }) : 'Active'}
                        </td>

                        {/* Actions */}
                        <td className="py-3 px-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {!isDaksh && (
                              <>
                                <button
                                  onClick={() => handleToggleBlock(u.gmail)}
                                  className={`px-2.5 py-1 rounded text-[10px] font-bold border transition-all flex items-center gap-1 ${
                                    isBlocked
                                      ? 'bg-emerald-600/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-600/30'
                                      : 'bg-rose-600/20 text-rose-300 border-rose-500/40 hover:bg-rose-600/30'
                                  }`}
                                  title={isBlocked ? 'Unblock user' : 'Block user from terminal'}
                                >
                                  {isBlocked ? <Unlock className="w-3 h-3" /> : <Ban className="w-3 h-3" />}
                                  {isBlocked ? 'Unblock' : 'Block'}
                                </button>

                                {deleteConfirmId === u.id ? (
                                  <div className="flex items-center gap-1">
                                    <button
                                      onClick={() => handleDeleteUser(u.id)}
                                      className="px-2 py-1 rounded bg-rose-600 text-white text-[10px] font-bold hover:bg-rose-500"
                                      title="Confirm account deletion"
                                    >
                                      Confirm
                                    </button>
                                    <button
                                      onClick={() => setDeleteConfirmId(null)}
                                      className="px-1.5 py-1 rounded bg-[#21262d] text-gray-400 hover:text-white text-[10px]"
                                    >
                                      Cancel
                                    </button>
                                  </div>
                                ) : (
                                  <button
                                    onClick={() => setDeleteConfirmId(u.id)}
                                    className="p-1 rounded text-gray-500 hover:text-rose-400 hover:bg-rose-500/10 transition-all"
                                    title="Delete user account"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#161b22] border-t border-[#30363d] flex flex-wrap items-center justify-between text-xs text-gray-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Master ID Directory is live and synced to permanent local browser persistence.</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all"
          >
            Close Directory
          </button>
        </div>

      </div>
    </div>
  );
}
