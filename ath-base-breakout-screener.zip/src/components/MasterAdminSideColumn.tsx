import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Users, 
  Key, 
  Bell, 
  Ban, 
  CheckCircle2, 
  LogOut, 
  ChevronLeft, 
  ChevronRight, 
  AlertTriangle, 
  Activity, 
  TrendingUp, 
  Trash2, 
  Eye, 
  EyeOff, 
  Copy, 
  Check,
  Sparkles,
  Lock,
  Unlock,
  Radio,
  FileSpreadsheet
} from 'lucide-react';
import { UserProfile, SignupNotification, GlobalUserTradeRecord, UserActivityItem } from '../types';
import { 
  getRegisteredUsers, 
  getDakshNotifications, 
  markNotificationAsRead, 
  clearAllNotifications, 
  toggleBlockEmail, 
  isEmailBlocked,
  deleteUserAccount,
  getAllUserTrades,
  getUserActivities
} from '../utils/userRegistry';
import { soundEffects } from '../utils/audioAlert';

interface MasterAdminSideColumnProps {
  currentUser: UserProfile;
  onLogout: () => void;
  onSelectUserForInspection?: (email: string) => void;
  onNavigateToTab?: (tab: any) => void;
  onOpenIdAdministration?: () => void;
}

export const MasterAdminSideColumn: React.FC<MasterAdminSideColumnProps> = ({
  currentUser,
  onLogout,
  onSelectUserForInspection,
  onNavigateToTab,
  onOpenIdAdministration,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [notifications, setNotifications] = useState<SignupNotification[]>([]);
  const [trades, setTrades] = useState<GlobalUserTradeRecord[]>([]);
  const [activities, setActivities] = useState<UserActivityItem[]>([]);
  
  // Section tab inside the column: 'accounts' | 'notifications' | 'trades'
  const [columnView, setColumnView] = useState<'accounts' | 'notifications' | 'trades'>('accounts');
  
  // Password visibility toggle per user
  const [showPasswordMap, setShowPasswordMap] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Refresh data
  const loadData = () => {
    setUsers(getRegisteredUsers());
    setNotifications(getDakshNotifications());
    setTrades(getAllUserTrades());
    setActivities(getUserActivities());
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 3000);
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleToggleBlock = (email: string) => {
    const isNowBlocked = toggleBlockEmail(email);
    soundEffects.playAlertChime();
    loadData();
  };

  const handleDeleteUser = (email: string) => {
    if (window.confirm(`Are you sure you want to remove account "${email}" from the registry?`)) {
      deleteUserAccount(email);
      loadData();
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const togglePasswordVisibility = (id: string) => {
    setShowPasswordMap((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const filteredUsers = users.filter((u) => {
    const q = searchQuery.toLowerCase();
    return (
      u.gmail.toLowerCase().includes(q) ||
      u.name.toLowerCase().includes(q) ||
      u.id.toLowerCase().includes(q)
    );
  });

  return (
    <aside
      id="master-admin-side-column"
      className={`relative z-30 shrink-0 border-r border-[#30363d] bg-[#0c1017] transition-all duration-300 flex flex-col h-[calc(100vh-3.5rem)] sticky top-14 ${
        isCollapsed ? 'w-14' : 'w-80 lg:w-96'
      }`}
    >
      {/* Toggle Collapse Button */}
      <button
        id="btn-collapse-admin-column"
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3 top-4 z-40 w-6 h-6 rounded-full bg-[#1f242c] border border-[#30363d] text-gray-300 hover:text-white flex items-center justify-center shadow-md hover:bg-blue-600 transition-colors"
        title={isCollapsed ? 'Expand Master Admin Column' : 'Collapse Column'}
      >
        {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
      </button>

      {/* Collapsed Mini View */}
      {isCollapsed ? (
        <div className="flex flex-col items-center py-4 space-y-5 h-full">
          <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center shadow-lg shadow-purple-500/10" title="Daksh Master Supervisor">
            <ShieldCheck className="w-5 h-5" />
          </div>

          <div className="flex-1 space-y-3 flex flex-col items-center">
            <button
              onClick={() => { setIsCollapsed(false); setColumnView('accounts'); }}
              className="relative p-2.5 rounded-xl text-gray-400 hover:text-white hover:bg-[#161b22] transition-colors"
              title="Signed-up Users & Permanent Passwords"
            >
              <Users className="w-4 h-4" />
              {users.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-blue-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {users.length}
                </span>
              )}
            </button>

            <button
              onClick={() => { setIsCollapsed(false); setColumnView('notifications'); }}
              className="relative p-2.5 rounded-xl text-gray-400 hover:text-white hover:bg-[#161b22] transition-colors"
              title="Signup Notifications to Daksh"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            <button
              onClick={() => { setIsCollapsed(false); setColumnView('trades'); }}
              className="p-2.5 rounded-xl text-gray-400 hover:text-white hover:bg-[#161b22] transition-colors"
              title="Live User Trades & Surveillance"
            >
              <Activity className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={onLogout}
            className="p-2.5 rounded-xl text-rose-400 hover:bg-rose-500/20 transition-colors"
            title="Log Out of Master Session"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      ) : (
        /* Expanded Full Administration Column */
        <div className="flex flex-col h-full overflow-hidden">
          {/* Column Header */}
          <div className="p-4 border-b border-[#30363d] bg-gradient-to-b from-purple-950/20 to-transparent">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-500/25">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-purple-300">
                    Master Terminal Column
                  </h3>
                  <div className="text-[11px] font-mono text-gray-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    dakshphosamani@gmail.com
                  </div>
                </div>
              </div>
              <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                VIP Daksh
              </span>
            </div>

            {/* Quick KPI stats */}
            <div className="grid grid-cols-3 gap-2 mt-3 pt-2.5 border-t border-[#21262d]">
              <div className="bg-[#131821] border border-[#21262d] rounded-lg p-2 text-center">
                <span className="text-[10px] text-gray-400 block">Real Users</span>
                <span className="text-sm font-bold text-white font-mono">{users.length}</span>
              </div>
              <div className="bg-[#131821] border border-[#21262d] rounded-lg p-2 text-center">
                <span className="text-[10px] text-gray-400 block">Live Trades</span>
                <span className="text-sm font-bold text-emerald-400 font-mono">{trades.length}</span>
              </div>
              <div className="bg-[#131821] border border-[#21262d] rounded-lg p-2 text-center">
                <span className="text-[10px] text-gray-400 block">New Alerts</span>
                <span className={`text-sm font-bold font-mono ${unreadCount > 0 ? 'text-rose-400 animate-pulse' : 'text-gray-400'}`}>
                  {unreadCount}
                </span>
              </div>
            </div>

            {/* Quick 1-Click Administration of IDs Button */}
            {onOpenIdAdministration && (
              <button
                onClick={onOpenIdAdministration}
                className="w-full mt-2.5 flex items-center justify-between px-3 py-2 rounded-xl bg-gradient-to-r from-amber-600/25 to-amber-700/25 border border-amber-500/40 text-amber-200 hover:from-amber-600/40 hover:to-amber-700/40 transition-all text-xs font-bold shadow-sm cursor-pointer"
                title="Open comprehensive table of all user IDs, emails, and passwords in a dedicated modal"
              >
                <div className="flex items-center gap-2">
                  <Key className="w-4 h-4 text-amber-400" />
                  <span>Administration of IDs</span>
                </div>
                <span className="text-[10px] bg-amber-400 text-black px-2 py-0.5 rounded font-mono font-bold">
                  OPEN
                </span>
              </button>
            )}

            {/* Navigation Tabs inside the Column */}
            <div className="flex gap-1 mt-3 bg-[#131821] p-1 rounded-xl border border-[#21262d]">
              <button
                onClick={() => setColumnView('accounts')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  columnView === 'accounts'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Accounts &amp; Pass</span>
              </button>

              <button
                onClick={() => setColumnView('notifications')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors relative ${
                  columnView === 'notifications'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                <Bell className="w-3.5 h-3.5" />
                <span>Inbox</span>
                {unreadCount > 0 && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping absolute top-1 right-2" />
                )}
              </button>

              <button
                onClick={() => setColumnView('trades')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  columnView === 'trades'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Live Trades</span>
              </button>
            </div>
          </div>

          {/* VIEW A: REAL SIGNED-UP USERS & PERMANENT PASSWORDS DIRECTORY */}
          {columnView === 'accounts' && (
            <div className="flex-1 flex flex-col min-h-0 bg-[#090d13]">
              {/* Search & Notice Header */}
              <div className="p-3 border-b border-[#21262d] space-y-2 bg-[#0c1017]">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-gray-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-yellow-400" />
                    Permanent Passwords Directory
                  </span>
                  <span className="text-[10px] text-gray-400 font-mono">
                    {filteredUsers.length} real account(s)
                  </span>
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter by Gmail, name, or ID..."
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* User List */}
              <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
                {filteredUsers.length === 0 ? (
                  <div className="text-center py-8 px-4 text-gray-400 space-y-2">
                    <div className="w-10 h-10 rounded-full bg-[#161b22] border border-[#30363d] flex items-center justify-center mx-auto text-gray-500">
                      <Users className="w-5 h-5" />
                    </div>
                    <p className="text-xs font-medium text-gray-300">No external accounts yet</p>
                    <p className="text-[11px] text-gray-500 leading-normal">
                      Only real users who submit their Gmail and details through the signup screen will appear here. No fake accounts!
                    </p>
                  </div>
                ) : (
                  filteredUsers.map((user) => {
                    const isBlocked = isEmailBlocked(user.gmail);
                    const showPass = showPasswordMap[user.id] || false;
                    const isMaster = user.gmail.toLowerCase() === 'dakshphosamani@gmail.com';

                    return (
                      <div
                        key={user.id}
                        className={`rounded-xl border p-3 transition-all ${
                          isBlocked
                            ? 'bg-rose-950/20 border-rose-900/50'
                            : isMaster
                            ? 'bg-purple-950/20 border-purple-500/40 shadow-sm'
                            : 'bg-[#131821] border-[#21262d] hover:border-[#38444d]'
                        }`}
                      >
                        {/* User Title & Block Toggle */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-bold text-white truncate">
                                {user.name}
                              </span>
                              {isMaster && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-extrabold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                                  Master
                                </span>
                              )}
                              {isBlocked && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-0.5">
                                  <Ban className="w-2.5 h-2.5" /> Blocked
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] font-mono text-gray-400 truncate mt-0.5">
                              {user.gmail}
                            </div>
                          </div>

                          {!isMaster && (
                            <button
                              id={`btn-block-${user.id}`}
                              onClick={() => handleToggleBlock(user.gmail)}
                              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
                                isBlocked
                                  ? 'bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 border border-emerald-500/40'
                                  : 'bg-rose-600/20 text-rose-300 hover:bg-rose-600/30 border border-rose-500/40'
                              }`}
                              title={isBlocked ? 'Unblock user' : 'Block this Gmail from website'}
                            >
                              {isBlocked ? <Unlock className="w-3 h-3" /> : <Ban className="w-3 h-3" />}
                              <span className="text-[10px]">{isBlocked ? 'Unblock' : 'Block'}</span>
                            </button>
                          )}
                        </div>

                        {/* Permanent Password Display */}
                        <div className="mt-2.5 bg-[#090d13] border border-[#21262d] rounded-lg px-2.5 py-1.5 flex items-center justify-between">
                          <div className="flex items-center gap-1.5 text-[11px]">
                            <Key className="w-3 h-3 text-amber-400 shrink-0" />
                            <span className="text-gray-400 text-[10px]">Perm Pass:</span>
                            <span className="font-mono font-bold text-amber-300">
                              {showPass ? (user.password || 'Tr@der2026') : '••••••••'}
                            </span>
                          </div>

                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => togglePasswordVisibility(user.id)}
                              className="p-1 text-gray-400 hover:text-white rounded"
                              title={showPass ? 'Hide password' : 'Show permanent password'}
                            >
                              {showPass ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                            </button>
                            <button
                              onClick={() => handleCopy(user.password || 'Tr@der2026', user.id)}
                              className="p-1 text-gray-400 hover:text-white rounded"
                              title="Copy password"
                            >
                              {copiedId === user.id ? (
                                <Check className="w-3 h-3 text-emerald-400" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </div>

                        {/* User Metadata */}
                        <div className="mt-2 flex items-center justify-between text-[10px] text-gray-400 pt-1.5 border-t border-[#1f242c]">
                          <span>ID: <code className="text-gray-300">{user.id}</code></span>
                          <span>Cap: <strong className="text-gray-200">₹{(user.initialCapital || 1000000).toLocaleString()}</strong></span>
                        </div>

                        {/* Delete Account (if non-master) */}
                        {!isMaster && (
                          <div className="mt-2 pt-1 border-t border-[#1f242c] flex justify-end">
                            <button
                              onClick={() => handleDeleteUser(user.gmail)}
                              className="text-[10px] text-rose-400 hover:text-rose-300 flex items-center gap-1"
                              title="Delete user permanently"
                            >
                              <Trash2 className="w-3 h-3" />
                              Delete Account
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* VIEW B: SIGNUP NOTIFICATIONS DISPATCHED TO DAKSH */}
          {columnView === 'notifications' && (
            <div className="flex-1 flex flex-col min-h-0 bg-[#090d13]">
              <div className="p-3 border-b border-[#21262d] flex items-center justify-between bg-[#0c1017]">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-gray-200">
                  <Bell className="w-3.5 h-3.5 text-purple-400" />
                  <span>Daksh's Gmail Signup Alerts</span>
                </div>
                {notifications.length > 0 && (
                  <button
                    onClick={clearAllNotifications}
                    className="text-[10px] text-gray-400 hover:text-rose-400 transition-colors"
                  >
                    Clear All
                  </button>
                )}
              </div>

              <div className="flex-1 overflow-y-auto p-3 space-y-2">
                {notifications.length === 0 ? (
                  <div className="text-center py-8 px-4 text-gray-400 space-y-2">
                    <CheckCircle2 className="w-8 h-8 text-emerald-500/50 mx-auto" />
                    <p className="text-xs font-medium text-gray-300">All alerts cleared</p>
                    <p className="text-[11px] text-gray-500">
                      Whenever a user registers their Gmail, an instant notification will trigger here for Daksh with their details and permanent password.
                    </p>
                  </div>
                ) : (
                  notifications.map((notif) => (
                    <div
                      key={notif.id}
                      className={`p-3 rounded-xl border transition-all ${
                        notif.read
                          ? 'bg-[#131821] border-[#21262d]'
                          : 'bg-purple-950/20 border-purple-500/40 shadow-sm'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-1">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-purple-400" />
                          <span className="text-xs font-bold text-white">{notif.userName}</span>
                        </div>
                        <span className="text-[10px] text-gray-400 font-mono">
                          {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <div className="text-[11px] text-gray-300 font-mono mt-1 break-all">
                        {notif.userEmail}
                      </div>

                      <div className="mt-2 bg-[#090d13] p-2 rounded-lg border border-[#21262d] text-[10px] space-y-1">
                        <div className="flex items-center justify-between text-amber-300 font-mono">
                          <span>Permanent Password:</span>
                          <strong className="text-xs">{notif.permanentPassword || 'N/A'}</strong>
                        </div>
                        <div className="flex items-center justify-between text-gray-400">
                          <span>Starting Capital:</span>
                          <span className="text-gray-200">₹{(notif.initialCapital || 1000000).toLocaleString()}</span>
                        </div>
                      </div>

                      {!notif.read && (
                        <button
                          onClick={() => markNotificationAsRead(notif.id)}
                          className="mt-2 text-[10px] text-purple-400 hover:text-purple-300 font-semibold"
                        >
                          Mark as read &rarr;
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* VIEW C: LIVE TRADES & SURVEILLANCE */}
          {columnView === 'trades' && (
            <div className="flex-1 flex flex-col min-h-0 bg-[#090d13]">
              <div className="p-3 border-b border-[#21262d] flex items-center justify-between bg-[#0c1017]">
                <span className="text-xs font-semibold text-gray-200 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-emerald-400" />
                  Live Trades Surveillance
                </span>
                <span className="text-[10px] text-gray-400 font-mono">
                  {trades.length} trade(s)
                </span>
              </div>

              <div className="flex-1 overflow-y-auto p-3 space-y-2">
                {trades.length === 0 ? (
                  <div className="text-center py-8 px-4 text-gray-400 space-y-2">
                    <Radio className="w-8 h-8 text-gray-600 mx-auto" />
                    <p className="text-xs font-medium text-gray-300">No user paper trades yet</p>
                    <p className="text-[11px] text-gray-500">
                      When any trader executes or squares off positions in Paper Trading, their orders and PnL will appear here in real time.
                    </p>
                  </div>
                ) : (
                  trades.map((t) => (
                    <div
                      key={t.id}
                      className="bg-[#131821] border border-[#21262d] rounded-xl p-2.5 space-y-1 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">{t.symbol}</span>
                        <span
                          className={`px-1.5 py-0.5 rounded font-mono text-[10px] font-bold ${
                            t.outcome === 'PROFIT'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {t.netPnl >= 0 ? '+' : ''}₹{t.netPnl.toLocaleString()} ({t.netPnlPercent >= 0 ? '+' : ''}{t.netPnlPercent}%)
                        </span>
                      </div>

                      <div className="text-[10px] text-gray-400 flex items-center justify-between">
                        <span>Trader: <strong className="text-gray-300">{t.userName}</strong></span>
                        <span className="font-mono text-gray-500">{t.userEmail}</span>
                      </div>

                      <div className="text-[10px] text-gray-500 flex items-center justify-between pt-1 border-t border-[#1f242c]">
                        <span>Entry: ₹{t.entryPrice} &rarr; Exit: ₹{t.exitPrice}</span>
                        <span>{t.exitReason}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Left Column Bottom Footer: User Info & Dedicated Log Out */}
          <div className="p-3 bg-[#0c1017] border-t border-[#30363d] space-y-2">
            <div className="flex items-center justify-between px-1 text-[11px]">
              <div className="flex items-center gap-1.5 text-gray-400">
                <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
                <span className="text-gray-300 font-medium">Logged in as Daksh</span>
              </div>
              {onNavigateToTab && (
                <button
                  onClick={() => onNavigateToTab('admin')}
                  className="text-[10px] text-purple-400 hover:text-purple-300 underline font-medium"
                >
                  Full View &rarr;
                </button>
              )}
            </div>

            <button
              id="btn-admin-logout"
              onClick={onLogout}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-rose-600/15 text-rose-300 hover:bg-rose-600 hover:text-white border border-rose-500/30 text-xs font-bold transition-all shadow-sm group"
            >
              <LogOut className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
              <span>Log Out of Terminal</span>
            </button>
          </div>
        </div>
      )}
    </aside>
  );
};

export default MasterAdminSideColumn;
