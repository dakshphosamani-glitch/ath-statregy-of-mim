import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  X, 
  Sparkles, 
  TrendingUp, 
  RefreshCcw, 
  HelpCircle, 
  ChevronDown, 
  Maximize2, 
  Minimize2,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  Zap,
  Activity
} from 'lucide-react';
import { soundEffects } from '../utils/audioAlert';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

interface AiChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  onOpen: () => void;
  activeStockSymbol?: string;
}

const PRESET_QUESTIONS = [
  'Explain Strategy 1: ATH Base Breakout & 20 EMA Support',
  'Explain Strategy 2: Stock Momentum & ATL 10% Turnaround',
  'Compare both strategies: When should I trade which?',
  'How do I use the Screener Table and read the Candlestick Chart?',
  'What is the Dual Condition Hub & Breakout Probability Score?',
  'How does the Paper Trading Terminal work?',
  'How do I set up Watchlists and Real-Time Price Alerts?',
  'How to run the Strategy Backtester and interpret results?'
];

export const AiChatbot: React.FC<AiChatbotProps> = ({
  isOpen,
  onClose,
  onOpen,
  activeStockSymbol,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: `👋 **Welcome to BreakoutPulse AI Mentor!**

I am trained on both core trading strategies and every tool in this terminal:
1. **Strategy 1:** All-Time High (ATH) Base Breakouts with 20 EMA dynamic support & volume confirmation.
2. **Strategy 2:** Stock Momentum & All-Time Low (ATL) ≤10% Turnaround setups.

You can ask me about **either strategy**, **how to use any specific feature**, or click any quick topic below!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    if (!textToSend) setInputText('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text.trim(),
          history: messages.slice(-6).map((m) => ({
            role: m.sender === 'user' ? 'user' : 'model',
            text: m.text,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get answer from AI mentor');
      }

      const data = await response.json();
      const botMessage: ChatMessage = {
        id: `assistant-${Date.now()}`,
        sender: 'assistant',
        text: data.reply || 'Analysis complete.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMessage]);
      soundEffects.playAlertChime();
    } catch (err: any) {
      const errorMessage: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        text: `⚠️ **Connection notice**: Could not reach backend server (${err.message}). 

**Quick Strategy Summary:**
- **Strategy 1 (ATH Breakout):** Stock within 10% of ATH, holding tight base above 20 EMA, volume > 1.5x at breakout.
- **Strategy 2 (ATL Turnaround):** Stock within 10% of All-Time Low, Stock Oscillator (%K > %D) hooking up from oversold, price curling back above 20 EMA.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Floating Launcher Button */}
      {!isOpen && (
        <button
          id="btn-open-ai-mentor"
          onClick={onOpen}
          className="fixed bottom-5 right-5 z-40 flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white font-semibold rounded-full shadow-xl shadow-blue-500/25 border border-blue-400/30 hover:scale-105 transition-all duration-200 group"
          title="Open AI Strategy & Feature Assistant"
        >
          <div className="relative">
            <Bot className="w-5 h-5 text-white" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full" />
          </div>
          <span className="text-sm tracking-wide">Ask AI Trading Mentor</span>
          <Sparkles className="w-3.5 h-3.5 text-yellow-300 opacity-80 group-hover:rotate-12 transition-transform" />
        </button>
      )}

      {/* Slide-out / Floating Chat Window */}
      {isOpen && (
        <div
          id="ai-chatbot-window"
          className={`fixed z-50 transition-all duration-300 shadow-2xl flex flex-col bg-[#0d1117] border border-[#30363d] rounded-2xl overflow-hidden ${
            isExpanded
              ? 'inset-4 md:inset-10'
              : 'bottom-4 right-4 sm:bottom-6 sm:right-6 w-[94vw] sm:w-[460px] h-[640px] max-h-[85vh]'
          }`}
        >
          {/* Header */}
          <div className="bg-[#161b22] px-4 py-3.5 border-b border-[#30363d] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-500 to-purple-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                    BreakoutPulse AI Mentor
                  </h3>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Live
                  </span>
                </div>
                <p className="text-[11px] text-gray-400">
                  Ask about Strategy 1, Strategy 2 &amp; App features
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-1.5 text-gray-400 hover:text-white hover:bg-[#21262d] rounded-lg transition-colors"
                title={isExpanded ? 'Minimize' : 'Expand full screen'}
              >
                {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
              <button
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-white hover:bg-[#21262d] rounded-lg transition-colors"
                title="Close chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Context / Current Stock Chip */}
          {activeStockSymbol && (
            <div className="bg-blue-950/40 border-b border-blue-900/40 px-3 py-1.5 flex items-center justify-between text-xs">
              <span className="text-blue-300 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-blue-400" />
                Focused Stock: <strong className="text-white">{activeStockSymbol}</strong>
              </span>
              <button
                onClick={() => handleSendMessage(`Analyze ${activeStockSymbol} according to both Strategy 1 (ATH Breakout) and Strategy 2 (ATL Turnaround)`)}
                className="text-[11px] text-blue-400 hover:text-blue-200 underline font-medium"
              >
                Analyze {activeStockSymbol} &rarr;
              </button>
            </div>
          )}

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#090d13]">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'assistant' && (
                  <div className="w-7 h-7 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center shrink-0 text-blue-400 mt-1">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-tr-none shadow-md'
                      : 'bg-[#161b22] text-gray-200 border border-[#30363d] rounded-tl-none shadow-sm'
                  }`}
                >
                  <div className="whitespace-pre-wrap break-words">{msg.text}</div>
                  <div
                    className={`mt-1.5 text-[10px] ${
                      msg.sender === 'user' ? 'text-blue-200 text-right' : 'text-gray-400 text-left'
                    }`}
                  >
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-3 justify-start items-center">
                <div className="w-7 h-7 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center shrink-0 text-blue-400">
                  <Bot className="w-3.5 h-3.5 animate-pulse" />
                </div>
                <div className="bg-[#161b22] border border-[#30363d] rounded-2xl px-4 py-2.5 text-xs text-gray-400 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" />
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.2s]" />
                  <span className="w-2 h-2 rounded-full bg-purple-400 animate-bounce [animation-delay:0.4s]" />
                  <span className="ml-1 text-[11px] text-gray-300">Synthesizing strategy rules...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Preset Questions (Scrollable) */}
          <div className="bg-[#161b22] px-3 py-2 border-t border-[#30363d] overflow-x-auto scrollbar-none flex gap-1.5">
            {PRESET_QUESTIONS.map((q, idx) => (
              <button
                key={idx}
                disabled={isLoading}
                onClick={() => handleSendMessage(q)}
                className="shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-[#21262d] text-gray-300 hover:text-white hover:bg-blue-600/30 border border-[#30363d] hover:border-blue-500/40 transition-all text-left flex items-center gap-1.5 disabled:opacity-50"
              >
                <Sparkles className="w-3 h-3 text-blue-400" />
                <span>{q}</span>
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="p-3 bg-[#161b22] border-t border-[#30363d]">
            <div className="flex items-center gap-2 bg-[#0d1117] border border-[#30363d] focus-within:border-blue-500 rounded-xl px-3 py-1.5 transition-colors">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Ask about Strategy 1, Strategy 2, or how to use a feature..."
                disabled={isLoading}
                className="flex-1 bg-transparent text-xs text-white placeholder-gray-500 focus:outline-none py-1.5"
              />
              <button
                id="btn-send-ai-chat"
                onClick={() => handleSendMessage()}
                disabled={!inputText.trim() || isLoading}
                className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white disabled:opacity-40 disabled:hover:bg-blue-600 transition-colors"
                title="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-center justify-between mt-2 px-1 text-[10px] text-gray-400">
              <span>Supports natural language questions on technical setups &amp; terminal usage</span>
              <span className="text-gray-400">Gemini Powered</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AiChatbot;
