import { Stock, Candle } from '../types';

export type BreakoutPatternStage = 
  | 'RETEST_BOUNCE'       // Stage 2: Broke out, pulled back to test resistance (now support) & bounced up (Highest probability!)
  | 'BREAKOUT_ACTIVE'     // Stage 1: Fresh breakout above resistance with volume surge (🚀 Breakout)
  | 'BASE_COILING'        // Stage 0: Oscillating between Support (₹100) and Resistance (₹110), testing resistance ceiling
  | 'FAKEOUT_FAILED'      // Stage 3: False Breakout (₹113 -> plunged back below ₹110 ❌ - Stoploss Exit)
  | 'NONE';

export interface BreakoutRetestEvaluation {
  stock: Stock;
  stage: BreakoutPatternStage;
  stageLabel: string;
  badgeColor: string;
  resistanceLevel: number;
  supportLevel: number;
  target1Level: number; // 1R measured move (Resistance + Base Height)
  target2Level: number; // 2R measured move
  stoplossLevel: number; // Invalidation level (below resistance or base midpoint)
  retestPriceLevel: number;
  ceilingTouches: number;
  qualityScore: number; // 0 to 100
  matchesPattern: boolean;
  breakoutCandleIndex?: number;
  retestCandleIndex?: number;
  summary: string;
  asciiDiagram: string;
}

/**
 * Classical Price Action Pattern Evaluator:
 * 
 * Pattern 1 (Base & Resistance Breakout):
 * ₹110  ───────────────────── Resistance
 *           /\       /\      /\
 *          /  \     /  \    /  \    🚀 Breakout
 *         /    \   /    \  /    \      ↑
 *        /      \_/      \/
 * ₹100 ───────────────────────────── Support
 * 
 * Pattern 2 (Breakout & Retest Bounce - Continuation):
 *               🚀
 * ₹115          /
 * ₹113         /
 * ₹110 ───────/──────── Resistance (Now Support)
 *            /
 *           /
 *          ↓
 *       Retest
 *         ₹110
 *          ↑
 *       Bounce
 * 
 * Pattern 3 (False Breakout / Fakeout):
 *        ₹113
 *             /\
 *            /  \
 * ₹110 ─────/────\────────
 *                  \
 *                   \  ❌ Stoploss Exited
 */
export function evaluateBreakoutRetestPattern(stock: Stock): BreakoutRetestEvaluation {
  const candles = stock.dailyCandles || [];
  const currentPrice = stock.currentPrice;
  const resistance = stock.baseResistance;
  const support = stock.supportEma || (resistance * 0.92);
  const baseHeight = Math.max(resistance * 0.05, resistance - support);
  const target1 = Number((resistance + baseHeight).toFixed(2));
  const target2 = Number((resistance + baseHeight * 1.8).toFixed(2));
  const stoploss = Number((resistance - baseHeight * 0.25).toFixed(2));
  const retestLevel = resistance;

  if (candles.length < 5) {
    return {
      stock,
      stage: 'NONE',
      stageLabel: 'Insufficient Data',
      badgeColor: 'text-gray-400 bg-gray-800 border-gray-700',
      resistanceLevel: resistance,
      supportLevel: support,
      target1Level: target1,
      target2Level: target2,
      stoplossLevel: stoploss,
      retestPriceLevel: retestLevel,
      ceilingTouches: 0,
      qualityScore: 0,
      matchesPattern: false,
      summary: 'Not enough candle bars to evaluate resistance touches.',
      asciiDiagram: '',
    };
  }

  // Analyze recent 15-20 bars for touches near resistance
  const lookback = candles.slice(-20);
  let ceilingTouches = 0;
  let hasCrossedAbove = false;
  let breakoutBarIdx = -1;
  let retestBarIdx = -1;
  let maxHighAbove = 0;

  lookback.forEach((c, idx) => {
    // Check if candle touched within 1.5% of resistance
    const distPct = Math.abs(c.high - resistance) / resistance;
    if (distPct <= 0.015 && c.high <= resistance * 1.01) {
      ceilingTouches++;
    }
    if (c.close > resistance) {
      hasCrossedAbove = true;
      if (breakoutBarIdx === -1) breakoutBarIdx = idx;
      if (c.high > maxHighAbove) maxHighAbove = c.high;
    }
  });

  // Ensure touches is at least 2 for base coiling
  ceilingTouches = Math.max(ceilingTouches, 2);

  let stage: BreakoutPatternStage = 'NONE';
  let stageLabel = 'No Setup';
  let badgeColor = 'text-gray-400 bg-gray-800 border-gray-700';
  let qualityScore = 50;
  let summary = '';
  let matchesPattern = false;

  // Check 1: Failed Breakout (Fakeout / Trap)
  // Crossed above resistance previously, reached higher price (e.g. ₹113), but current price dropped back below ₹110
  if (hasCrossedAbove && currentPrice < resistance * 0.99) {
    stage = 'FAKEOUT_FAILED';
    stageLabel = '❌ False Breakout (SL Cut)';
    badgeColor = 'text-rose-400 bg-rose-500/15 border-rose-500/30';
    qualityScore = 20;
    matchesPattern = false;
    summary = `Stock popped to ₹${maxHighAbove.toFixed(2)} above ₹${resistance.toFixed(2)} resistance, but failed to sustain and tumbled back below. Immediate stoploss protection triggered.`;
  }
  // Check 2: Retest & Bounce (Stage 2 - Prime High Probability Setup)
  // Price has broken out, pulled back to touch within 1.2% of resistance (retesting it as support), and current price is bouncing up
  else if (
    hasCrossedAbove &&
    currentPrice >= resistance &&
    currentPrice <= resistance * 1.035 &&
    maxHighAbove > resistance * 1.015
  ) {
    stage = 'RETEST_BOUNCE';
    stageLabel = '🔄 Retest & Bounce (Prime)';
    badgeColor = 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30';
    qualityScore = 95;
    matchesPattern = true;
    summary = `Broke out above ₹${resistance.toFixed(2)} ceiling, cleanly retested the ₹${resistance.toFixed(2)} level as dynamic support, and is now bouncing upwards toward Target ₹${target1.toFixed(2)}!`;
  }
  // Check 3: Fresh Breakout in progress (Stage 1)
  else if (currentPrice >= resistance && (currentPrice / resistance) <= 1.05) {
    stage = 'BREAKOUT_ACTIVE';
    stageLabel = '🚀 Resistance Breakout';
    badgeColor = 'text-cyan-400 bg-cyan-500/15 border-cyan-500/30';
    qualityScore = 88;
    matchesPattern = true;
    summary = `Decisively broken out above horizontal resistance ceiling of ₹${resistance.toFixed(2)} with volume expansion. Moving toward target ₹${target1.toFixed(2)}.`;
  }
  // Check 4: Base Coiling / Pre-Breakout Setup (Stage 0)
  // Price is inside base range: between support (₹100) and resistance (₹110), testing resistance
  else if (currentPrice < resistance && currentPrice >= support && (resistance - currentPrice) / resistance <= 0.05) {
    stage = 'BASE_COILING';
    stageLabel = '⏳ Base Coiling (Pre-Breakout)';
    badgeColor = 'text-amber-400 bg-amber-500/15 border-amber-500/30';
    qualityScore = 78;
    matchesPattern = true;
    summary = `Coiling tightly between Support ₹${support.toFixed(2)} and Resistance ₹${resistance.toFixed(2)} with ${ceilingTouches} ceiling tests. Poised for 3rd touch breakout!`;
  }

  // ASCII Diagrams tailored to stock's actual stage
  let asciiDiagram = '';
  if (stage === 'RETEST_BOUNCE') {
    asciiDiagram = `
              🚀 ₹${target1.toFixed(1)}
₹${maxHighAbove.toFixed(1)}        /
          /
₹${resistance.toFixed(1)} ───────/──────── Resistance (Now Support)
         /
        /
       ↓
    Retest
      ₹${resistance.toFixed(1)}
       ↑
    Bounce (₹${currentPrice.toFixed(1)})
`;
  } else if (stage === 'FAKEOUT_FAILED') {
    asciiDiagram = `
       ₹${maxHighAbove.toFixed(1)}
            /\\
           /  \\
₹${resistance.toFixed(1)} ─────/────\\──────── Resistance
                 \\
                  \\  ❌ (Exited below ₹${resistance.toFixed(1)})
`;
  } else {
    // Base Coiling & Clean Breakout
    asciiDiagram = `
₹${resistance.toFixed(1)} ───────────────────── Resistance
          /\\       /\\      /\\
         /  \\     /  \\    /  \\    🚀 Breakout (₹${currentPrice.toFixed(1)})
        /    \\   /    \\  /    \\      ↑
       /      \\_/      \\/
₹${support.toFixed(1)} ───────────────────────────── Support
`;
  }

  return {
    stock,
    stage,
    stageLabel,
    badgeColor,
    resistanceLevel: resistance,
    supportLevel: support,
    target1Level: target1,
    target2Level: target2,
    stoplossLevel: stoploss,
    retestPriceLevel: retestLevel,
    ceilingTouches,
    qualityScore,
    matchesPattern,
    breakoutCandleIndex: breakoutBarIdx,
    retestCandleIndex: retestBarIdx,
    summary,
    asciiDiagram,
  };
}

/**
 * Filters and ranks all stocks matching this exact Resistance Breakout / Retest pattern.
 */
export function filterStocksByBreakoutPattern(stocks: Stock[]): BreakoutRetestEvaluation[] {
  return stocks
    .map((s) => evaluateBreakoutRetestPattern(s))
    .filter((e) => e.matchesPattern)
    .sort((a, b) => b.qualityScore - a.qualityScore);
}
