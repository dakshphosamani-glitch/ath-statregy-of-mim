import { Stock } from '../types';

export interface ConditionEvaluation {
  stock: Stock;
  isPatternMet: boolean; // Backwards compatible alias
  isStrategy10Met: boolean; // 10% ATH Strategy
  isStochMet: boolean;
  isAnyMet: boolean;
  isBothMet: boolean;
  category: 'BOTH' | 'PATTERN_ONLY' | 'STOCH_ONLY' | 'NONE';
  patternReason: string; // Backwards compatible alias
  strategy10Reason: string;
  stochReason: string;
}

export function evaluateStockConditions(stock: Stock): ConditionEvaluation {
  // Condition 1: 10% ATH Strategy Mandate
  // Criteria:
  // 1. Strictly within 10% of ATH (distToAth <= 10)
  // 2. Trading above or respecting 20 EMA dynamic support (price >= supportEma * 0.97)
  const isNearAth = stock.distToAth <= 10;
  const isHoldingEma = stock.currentPrice >= stock.supportEma * 0.97;

  const isStrategy10Met = isNearAth && isHoldingEma;
  const isPatternMet = isStrategy10Met;

  let strategy10Reason = '';
  if (isStrategy10Met) {
    if (stock.distToAth <= 3.5) {
      strategy10Reason = `10% ATH Strategy: Prime ${stock.distToAth}% to ATH (₹${stock.ath}), holding 20 EMA ₹${stock.supportEma}`;
    } else {
      strategy10Reason = `10% ATH Strategy: ${stock.distToAth}% from ATH, supported at ₹${stock.supportEma} 20 EMA`;
    }
  } else {
    strategy10Reason = `Does not qualify for 10% ATH strategy (distance: ${stock.distToAth}% > 10%)`;
  }
  const patternReason = strategy10Reason;

  // Condition 2: Stochastic Momentum Condition
  // Criteria:
  // 1. Stochastic Bullish Crossover (%K crosses above %D) OR
  // 2. Oversold Hook (%K hooking upwards from oversold) OR
  // 3. Strong Momentum Zone (%K > %D between 40 and 85) OR
  // 4. Confluence at 20 EMA Support
  const hasBullishCross = stock.stochSignal === 'Bullish Crossover';
  const hasOversoldHook = stock.stochSignal === 'Oversold Hook';
  const hasMomentumZone = stock.stochSignal === 'Momentum Zone';
  const hasKAboveD = stock.stochK > stock.stochD && stock.stochK < 88;
  const hasStochEmaConfluence = stock.isStochAtEmaSupport;

  const isStochMet = hasBullishCross || hasOversoldHook || hasMomentumZone || (hasKAboveD && hasStochEmaConfluence) || (stock.stochK <= 35 && hasKAboveD);

  let stochReason = '';
  if (isStochMet) {
    stochReason = `${stock.stochSignal}: %K (${stock.stochK}) vs %D (${stock.stochD})${hasStochEmaConfluence ? ' at 20 EMA support' : ''}`;
  } else {
    stochReason = `Neutral/Bearish momentum: %K (${stock.stochK}) vs %D (${stock.stochD})`;
  }

  const isAnyMet = isStrategy10Met || isStochMet;
  const isBothMet = isStrategy10Met && isStochMet;

  let category: 'BOTH' | 'PATTERN_ONLY' | 'STOCH_ONLY' | 'NONE' = 'NONE';
  if (isBothMet) {
    category = 'BOTH';
  } else if (isStrategy10Met) {
    category = 'PATTERN_ONLY';
  } else if (isStochMet) {
    category = 'STOCH_ONLY';
  }

  return {
    stock,
    isPatternMet,
    isStrategy10Met,
    isStochMet,
    isAnyMet,
    isBothMet,
    category,
    patternReason,
    strategy10Reason,
    stochReason,
  };
}
