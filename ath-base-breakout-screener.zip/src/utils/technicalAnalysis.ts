import { Stock, Candle, BacktestTrade, BacktestStrategyConfig, BacktestMetrics, Timeframe, MarketRegime } from '../types';

export const DEFAULT_STRATEGY_CONFIG: BacktestStrategyConfig = {
  stopLossPercent: 4.5,
  targetPercent: 12.0,
  volumeMultiplier: 1.5,
  maxDistToAth: 10.0,
  timeframe: '1D',
  marketRegimeFilter: 'ALL',
  requireEmaSupport: true,
  maxHoldingBars: 15,
  entryApproach: 'BOTH',
  useStructuralStopLoss: true,
};

// Check if a specific candle represents a valid Base Breakout setup near ATH
export function evaluateBreakoutSetup(
  candles: Candle[],
  currentIndex: number,
  ath: number,
  config: BacktestStrategyConfig
): {
  isTrigger: boolean;
  baseResistance: number;
  reason?: string;
  marketRegime: MarketRegime;
  entryType?: 'Aggressive Breakout' | 'ATH 10% Dip-Buy' | 'Dual Confluence' | 'Retest & Bounce';
  structuralStopLoss?: number;
} {
  if (currentIndex < 10) {
    return { isTrigger: false, baseResistance: 0, marketRegime: 'Neutral Day' };
  }

  const current = candles[currentIndex];
  const prevCandles = candles.slice(Math.max(0, currentIndex - 15), currentIndex);

  // 1. Proximity to All-Time High (Within 10% of ATH)
  const distToAth = Math.max(0, ((ath - current.close) / ath) * 100);
  if (distToAth > config.maxDistToAth) {
    return { isTrigger: false, baseResistance: 0, reason: 'Too far from ATH (>10%)', marketRegime: current.marketRegime || 'Neutral Day' };
  }

  // 2. Base Resistance: highest high of the preceding consolidation
  const baseResistance = Math.max(...prevCandles.map(c => c.high));

  // 3. Structural Stop-Loss Calculation: Below recent higher low / consolidation base floor
  const recentLows = prevCandles.slice(-8).map(c => c.low);
  const baseStructuralLow = Math.min(...recentLows);
  const structuralStopLoss = Number((baseStructuralLow * 0.99).toFixed(2));

  // Average volume
  const avgVol = prevCandles.reduce((sum, c) => sum + c.volume, 0) / prevCandles.length;

  // Approach A: Aggressive Breakout Entry (Candle closes above base resistance with volume)
  const isAggressiveBreakout = current.close >= baseResistance * 0.995 && current.volume >= avgVol * config.volumeMultiplier;

  // Approach B: Dip-Buying Entry (Asset pulls back roughly 10% from ATH down to rising 20 EMA support)
  const isDipPullback = distToAth >= 4.0 && distToAth <= 12.0 &&
    current.ema20 !== undefined &&
    current.low <= current.ema20 * 1.015 &&
    current.close >= current.ema20 * 0.985 &&
    current.close >= current.open;

  // Approach C: Price Action Retest & Bounce Entry (User Pattern Specification)
  // Stage: Price recently broke above base resistance, pulls back to test resistance (now support), and prints a bullish bounce candle
  const recentBars = prevCandles.slice(-4);
  const hadRecentBreakout = recentBars.some(c => c.high >= baseResistance * 0.998);
  const isRetestBounce = hadRecentBreakout &&
    current.low <= baseResistance * 1.02 &&
    current.low >= baseResistance * 0.985 &&
    current.close >= current.open &&
    current.close >= baseResistance * 0.995;

  const approach = config.entryApproach || 'BOTH';
  let isTrigger = false;
  let entryType: 'Aggressive Breakout' | 'ATH 10% Dip-Buy' | 'Dual Confluence' | 'Retest & Bounce' = 'Aggressive Breakout';

  if (approach === 'AGGRESSIVE_BREAKOUT' && isAggressiveBreakout) {
    isTrigger = true;
    entryType = 'Aggressive Breakout';
  } else if (approach === 'DIP_BUYING_PULLBACK' && isDipPullback) {
    isTrigger = true;
    entryType = 'ATH 10% Dip-Buy';
  } else if (approach === 'RETEST_BOUNCE' && isRetestBounce) {
    isTrigger = true;
    entryType = 'Retest & Bounce';
  } else if (approach === 'BOTH') {
    if (isRetestBounce) {
      isTrigger = true;
      entryType = 'Retest & Bounce';
    } else if (isAggressiveBreakout && isDipPullback) {
      isTrigger = true;
      entryType = 'Dual Confluence';
    } else if (isAggressiveBreakout) {
      isTrigger = true;
      entryType = 'Aggressive Breakout';
    } else if (isDipPullback) {
      isTrigger = true;
      entryType = 'ATH 10% Dip-Buy';
    }
  }

  if (!isTrigger) {
    return {
      isTrigger: false,
      baseResistance,
      reason: 'Strategy conditions (Breakout above resistance or 20 EMA dip-buy) not met',
      marketRegime: current.marketRegime || 'Neutral Day',
    };
  }

  // EMA Support check
  if (config.requireEmaSupport && current.ema20) {
    if (current.close < current.ema20 * 0.985) {
      return { isTrigger: false, baseResistance, reason: 'Price lost 20 EMA support', marketRegime: current.marketRegime || 'Neutral Day' };
    }
  }

  // Market regime filter
  const marketRegime = current.marketRegime || 'Neutral Day';
  if (config.marketRegimeFilter === 'BULLISH_ONLY' && marketRegime !== 'Bullish Day') {
    return { isTrigger: false, baseResistance, reason: 'Filter: Bullish Day Only', marketRegime };
  }
  if (config.marketRegimeFilter === 'NON_BEARISH' && marketRegime === 'Bearish Day') {
    return { isTrigger: false, baseResistance, reason: 'Filter: Exclude Bearish Days', marketRegime };
  }

  // Stochastic indicator confirmation check (if configured)
  if (config.requireStochBullish) {
    if (current.stochK !== undefined && current.stochD !== undefined) {
      if (current.stochK < current.stochD) {
        return { isTrigger: false, baseResistance, reason: 'Stochastic %K < %D (Bearish/Divergent)', marketRegime };
      }
    }
  }
  if (config.stochMaxK && current.stochK !== undefined && current.stochK > config.stochMaxK) {
    return { isTrigger: false, baseResistance, reason: `Stochastic %K (${current.stochK}) exceeds max limit (${config.stochMaxK})`, marketRegime };
  }

  return { isTrigger: true, baseResistance, marketRegime, entryType, structuralStopLoss };
}

// Full historical backtest simulation
export function runBacktest(
  stocks: Stock[],
  config: BacktestStrategyConfig = DEFAULT_STRATEGY_CONFIG,
  selectedSymbol?: string
): { trades: BacktestTrade[]; metrics: BacktestMetrics } {
  const trades: BacktestTrade[] = [];
  const targetStocks = selectedSymbol && selectedSymbol !== 'ALL'
    ? stocks.filter(s => s.symbol === selectedSymbol)
    : stocks;

  targetStocks.forEach(stock => {
    const candles = config.timeframe === '1D' ? stock.dailyCandles : stock.weeklyCandles;
    if (!candles || candles.length < 12) return;

    let inTrade = false;
    let entryBar = 0;
    let entryPrice = 0;
    let stopLoss = 0;
    let target = 0;
    let tradeMarketRegime: MarketRegime = 'Neutral Day';
    let entryDate = '';
    let entryResistance = 0;
    let entryStoch: { k: number; d: number; signal: string } | undefined = undefined;
    let currentEntryType: 'Aggressive Breakout' | 'ATH 10% Dip-Buy' | 'Dual Confluence' | 'Retest & Bounce' = 'Aggressive Breakout';

    for (let i = 10; i < candles.length; i++) {
      const candle = candles[i];

      if (!inTrade) {
        // Evaluate entry condition
        const evaluation = evaluateBreakoutSetup(candles, i, stock.ath, config);
        if (evaluation.isTrigger) {
          inTrade = true;
          entryBar = i;
          entryPrice = candle.close;
          entryResistance = evaluation.baseResistance;
          currentEntryType = evaluation.entryType || 'Aggressive Breakout';

          if (config.useStructuralStopLoss !== false && evaluation.structuralStopLoss && evaluation.structuralStopLoss < entryPrice) {
            stopLoss = evaluation.structuralStopLoss;
          } else {
            stopLoss = Number((entryPrice * (1 - config.stopLossPercent / 100)).toFixed(2));
          }

          target = Number((entryPrice * (1 + config.targetPercent / 100)).toFixed(2));
          tradeMarketRegime = evaluation.marketRegime;
          entryDate = candle.date;
          if (candle.stochK !== undefined && candle.stochD !== undefined) {
            entryStoch = {
              k: candle.stochK,
              d: candle.stochD,
              signal: candle.stochK >= candle.stochD ? 'Bullish Cross' : 'Bearish Cross',
            };
          } else {
            entryStoch = undefined;
          }
        }
      } else {
        // Trade management in forward bars
        const barsHeld = i - entryBar;
        let isExit = false;
        let exitPrice = candle.close;
        let exitReason: 'Target Hit' | 'Trailing Stop' | 'Stop Loss Hit' | 'Fakeout Breakdown' | 'Fakeout Immediate Cut (❌)' = 'Stop Loss Hit';
        let status: 'SUCCESS' | 'FAILED' = 'FAILED';

        // Check 1: User's Fakeout Protection (Drop back below broken resistance ceiling e.g. ₹110)
        if (config.fakeoutImmediateCut && barsHeld <= 4 && entryResistance > 0 && candle.close < entryResistance * 0.992) {
          isExit = true;
          exitPrice = candle.close;
          exitReason = 'Fakeout Immediate Cut (❌)';
          status = 'FAILED';
        }
        // Check 2: Stop Loss breached
        else if (candle.low <= stopLoss) {
          isExit = true;
          exitPrice = stopLoss;
          exitReason = barsHeld <= 2 ? 'Fakeout Breakdown' : 'Stop Loss Hit';
          status = 'FAILED';
        }
        // Check 3: Target Hit
        else if (candle.high >= target) {
          isExit = true;
          exitPrice = target;
          exitReason = 'Target Hit';
          status = 'SUCCESS';
        }
        // Check 4: Trailing EMA or max holding bars
        else if (barsHeld >= config.maxHoldingBars) {
          isExit = true;
          exitPrice = candle.close;
          status = exitPrice >= entryPrice ? 'SUCCESS' : 'FAILED';
          exitReason = status === 'SUCCESS' ? 'Trailing Stop' : 'Stop Loss Hit';
        }

        if (isExit) {
          const pnlPercent = Number((((exitPrice - entryPrice) / entryPrice) * 100).toFixed(2));
          const patternStage: 'BREAKOUT_ACTIVE' | 'RETEST_BOUNCE' | 'FAKEOUT_FAILED' = 
            exitReason.includes('Fakeout') 
              ? 'FAKEOUT_FAILED' 
              : currentEntryType === 'Retest & Bounce' 
                ? 'RETEST_BOUNCE' 
                : 'BREAKOUT_ACTIVE';

          trades.push({
            id: `${stock.symbol}-${entryDate}-${i}`,
            symbol: stock.symbol,
            name: stock.name,
            timeframe: config.timeframe,
            entryDate,
            entryPrice,
            stopLoss,
            target,
            exitDate: candle.date,
            exitPrice,
            pnlPercent,
            status,
            marketRegime: tradeMarketRegime,
            holdingBars: barsHeld,
            exitReason,
            entryType: currentEntryType,
            patternStage,
            isAutoExecuted: true,
            patternNotes: `${currentEntryType} at ₹${entryPrice} with ${config.useStructuralStopLoss !== false ? 'Structural SL below base structure' : `${config.stopLossPercent}% fixed SL`}${exitReason.includes('Fakeout') ? ' • Fakeout stopped at resistance line ❌' : ''}`,
            stochAtEntry: entryStoch,
          });
          inTrade = false;
        }
      }
    }
  });

  // Calculate Metrics
  const totalTrades = trades.length;
  const successfulTrades = trades.filter(t => t.status === 'SUCCESS').length;
  const failedTrades = trades.filter(t => t.status === 'FAILED').length;
  const winRate = totalTrades > 0 ? Number(((successfulTrades / totalTrades) * 100).toFixed(1)) : 0;

  const wins = trades.filter(t => t.pnlPercent > 0);
  const losses = trades.filter(t => t.pnlPercent < 0);

  const totalWinPnl = wins.reduce((sum, t) => sum + t.pnlPercent, 0);
  const totalLossPnl = Math.abs(losses.reduce((sum, t) => sum + t.pnlPercent, 0));
  const profitFactor = totalLossPnl > 0 ? Number((totalWinPnl / totalLossPnl).toFixed(2)) : totalWinPnl > 0 ? 9.99 : 0;

  const netPnlPercent = Number((totalWinPnl - totalLossPnl).toFixed(1));
  const avgWinPercent = wins.length > 0 ? Number((totalWinPnl / wins.length).toFixed(1)) : 0;
  const avgLossPercent = losses.length > 0 ? Number((totalLossPnl / losses.length).toFixed(1)) : 0;

  // Market Regime Breakdown
  const bullishTrades = trades.filter(t => t.marketRegime === 'Bullish Day');
  const bullishWins = bullishTrades.filter(t => t.status === 'SUCCESS').length;
  const bullishDayWinRate = bullishTrades.length > 0 ? Number(((bullishWins / bullishTrades.length) * 100).toFixed(1)) : 0;

  const bearishTrades = trades.filter(t => t.marketRegime === 'Bearish Day');
  const bearishWins = bearishTrades.filter(t => t.status === 'SUCCESS').length;
  const bearishDayWinRate = bearishTrades.length > 0 ? Number(((bearishWins / bearishTrades.length) * 100).toFixed(1)) : 0;

  const neutralTrades = trades.filter(t => t.marketRegime === 'Neutral Day');
  const neutralWins = neutralTrades.filter(t => t.status === 'SUCCESS').length;
  const neutralDayWinRate = neutralTrades.length > 0 ? Number(((neutralWins / neutralTrades.length) * 100).toFixed(1)) : 0;

  // Stochastic Confirmed Win Rate (%K >= %D at entry)
  const stochTrades = trades.filter(t => t.stochAtEntry && t.stochAtEntry.k >= t.stochAtEntry.d);
  const stochWins = stochTrades.filter(t => t.status === 'SUCCESS').length;
  const stochConfirmedWinRate = stochTrades.length > 0 ? Number(((stochWins / stochTrades.length) * 100).toFixed(1)) : winRate;

  // Equity Curve calculation
  let runningEquity = 100000;
  let peakEquity = runningEquity;
  let maxDrawdown = 0;
  const equityCurve = [{ date: 'Start', equity: 100000 }];

  trades.forEach(t => {
    const gainOrLoss = runningEquity * (t.pnlPercent / 100);
    runningEquity += gainOrLoss;
    if (runningEquity > peakEquity) peakEquity = runningEquity;
    const currentDrawdown = ((peakEquity - runningEquity) / peakEquity) * 100;
    if (currentDrawdown > maxDrawdown) maxDrawdown = currentDrawdown;

    equityCurve.push({
      date: t.exitDate,
      equity: Math.round(runningEquity),
    });
  });

  const metrics: BacktestMetrics = {
    totalTrades,
    successfulTrades,
    failedTrades,
    winRate,
    profitFactor,
    netPnlPercent,
    maxDrawdown: Number(maxDrawdown.toFixed(1)),
    avgWinPercent,
    avgLossPercent,
    bullishDayWinRate,
    bearishDayWinRate,
    neutralDayWinRate,
    bullishTradesCount: bullishTrades.length,
    bearishTradesCount: bearishTrades.length,
    stochConfirmedWinRate,
    equityCurve,
  };

  return { trades, metrics };
}

// -------------------------------------------------------------
// STOCHASTIC OSCILLATOR CALCULATION (14, 3, 3)
// -------------------------------------------------------------
export function calculateStochastic(
  candles: Candle[],
  kPeriod: number = 14,
  dPeriod: number = 3
): { stochK: number[]; stochD: number[] } {
  const kValues: number[] = [];
  const dValues: number[] = [];

  for (let i = 0; i < candles.length; i++) {
    const windowStart = Math.max(0, i - kPeriod + 1);
    const windowCandles = candles.slice(windowStart, i + 1);

    const highestHigh = Math.max(...windowCandles.map((c) => c.high));
    const lowestLow = Math.min(...windowCandles.map((c) => c.low));
    const currentClose = candles[i].close;

    let k = 50; // default midpoint if range is 0
    if (highestHigh > lowestLow) {
      k = ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;
      k = Math.max(0, Math.min(100, k));
    }
    kValues.push(Number(k.toFixed(1)));

    // Calculate %D as 3-period SMA of %K
    const dWindowStart = Math.max(0, i - dPeriod + 1);
    const dSlice = kValues.slice(dWindowStart, i + 1);
    const dAvg = dSlice.reduce((sum, val) => sum + val, 0) / dSlice.length;
    dValues.push(Number(dAvg.toFixed(1)));
  }

  return { stochK: kValues, stochD: dValues };
}

// Enriches candle array with both EMA20 and Stochastic %K and %D
export function enrichCandlesWithIndicators(candles: Candle[]): Candle[] {
  if (!candles || candles.length === 0) return [];
  const { stochK, stochD } = calculateStochastic(candles, 14, 3);
  return candles.map((c, i) => ({
    ...c,
    stochK: stochK[i],
    stochD: stochD[i],
  }));
}

// Evaluate whether any stock meets the ATH Base Breakout + Stochastic Pattern
export interface PatternCheckResult {
  matchesPattern: boolean;
  score: number; // 0-100
  distToAth: number;
  athPassed: boolean;
  emaSupportPassed: boolean;
  baseResistancePassed: boolean;
  stochPassed: boolean;
  stochSignal: 'Bullish Crossover' | 'Oversold Hook' | 'Momentum Zone' | 'Neutral' | 'Bearish Cross';
  stochQuality: 'Prime (Crossover at 20 EMA)' | 'Strong Momentum' | 'Early Turnaround' | 'Extended Breakout';
  summary: string;
  recommendation: string;
}

export function evaluateStockPatternAndStoch(
  currentPrice: number,
  ath: number,
  baseResistance: number,
  supportEma: number,
  stochK: number,
  stochD: number,
  prevStochK?: number,
  prevStochD?: number
): PatternCheckResult {
  const distToAth = Math.max(0, Number((((ath - currentPrice) / ath) * 100).toFixed(2)));
  const athPassed = distToAth <= 10.0;
  const emaSupportPassed = currentPrice >= supportEma * 0.985; // within 1.5% of 20 EMA or above
  const baseResistancePassed = currentPrice >= baseResistance * 0.98;

  // Stochastic signal detection
  const isCrossover = (prevStochK !== undefined && prevStochD !== undefined)
    ? prevStochK <= prevStochD && stochK > stochD
    : stochK > stochD && stochK <= 85;

  let stochSignal: PatternCheckResult['stochSignal'] = 'Neutral';
  let stochQuality: PatternCheckResult['stochQuality'] = 'Early Turnaround';
  let stochPassed = false;

  if (isCrossover && emaSupportPassed && distToAth <= 5) {
    stochSignal = 'Bullish Crossover';
    stochQuality = 'Prime (Crossover at 20 EMA)';
    stochPassed = true;
  } else if (stochK < 35 && stochK > stochD) {
    stochSignal = 'Oversold Hook';
    stochQuality = 'Early Turnaround';
    stochPassed = true;
  } else if (stochK >= 50 && stochK <= 80 && stochK > stochD) {
    stochSignal = 'Momentum Zone';
    stochQuality = 'Strong Momentum';
    stochPassed = true;
  } else if (stochK > 80 && baseResistancePassed) {
    stochSignal = 'Momentum Zone';
    stochQuality = 'Extended Breakout';
    stochPassed = true;
  } else if (stochK < stochD) {
    stochSignal = 'Bearish Cross';
    stochQuality = 'Early Turnaround';
    stochPassed = false;
  }

  let score = 0;
  if (athPassed) score += 35;
  if (emaSupportPassed) score += 25;
  if (baseResistancePassed) score += 20;
  if (stochPassed) score += 20;

  const matchesPattern = athPassed && emaSupportPassed && (baseResistancePassed || stochPassed);

  let summary = '';
  let recommendation = '';

  if (matchesPattern && stochSignal === 'Bullish Crossover') {
    summary = `Prime Confluence: ≤${distToAth}% to ATH, 20 EMA support, & Bullish Stoch Crossover (%K ${stochK} > %D ${stochD})`;
    recommendation = 'Ideal high-probability entry trigger. Risk defined at 20 EMA.';
  } else if (matchesPattern) {
    summary = `10% ATH Strategy Active: Consolidated within ${distToAth}% of ATH with dynamic 20 EMA support (Stoch: ${stochSignal})`;
    recommendation = 'Watch for breakout confirmation volume above pivot resistance.';
  } else {
    summary = `Partial Setup: ${distToAth > 10 ? 'Beyond 10% ATH limit' : 'Awaiting EMA / Stoch alignment'}`;
    recommendation = 'Keep on radar until price coils into 20 EMA base.';
  }

  return {
    matchesPattern,
    score,
    distToAth,
    athPassed,
    emaSupportPassed,
    baseResistancePassed,
    stochPassed,
    stochSignal,
    stochQuality,
    summary,
    recommendation,
  };
}
