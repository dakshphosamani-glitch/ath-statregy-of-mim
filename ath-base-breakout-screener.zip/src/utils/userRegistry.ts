import { UserProfile, UserActivityItem, GlobalUserTradeRecord, PaperTradeRecord, SignupNotification } from '../types';

export const MASTER_EMAIL = 'dakshphosamani@gmail.com';
export const MASTER_PASSWORD = 'Daksh2011';
export const MASTER_EMAILS = ['dakshphosamani@gmail.com'];

// Real data storage keys - isolates from old mock/demo sessions
const STORAGE_USERS_KEY = 'bp_real_registered_users_v4';
const STORAGE_ACTIVITIES_KEY = 'bp_real_user_activities_v4';
const STORAGE_TRADES_KEY = 'bp_real_user_trades_v4';
const STORAGE_BLOCKED_KEY = 'bp_real_blocked_emails_v4';
const STORAGE_NOTIFICATIONS_KEY = 'bp_real_daksh_notifications_v4';

// Check if credentials match Daksh's master administrator account
export function isMasterCredentials(email: string, password?: string): boolean {
  if (!email || !password) return false;
  const cleanEmail = email.trim().toLowerCase();
  const isEmailMatch = MASTER_EMAILS.some((m) => m.toLowerCase() === cleanEmail);
  return isEmailMatch && password.trim() === MASTER_PASSWORD;
}

export function isMasterEmail(email?: string): boolean {
  if (!email) return false;
  const cleanEmail = email.trim().toLowerCase();
  return MASTER_EMAILS.some((m) => m.toLowerCase() === cleanEmail);
}

// Block / Banned Accounts Management
export function getBlockedEmails(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_BLOCKED_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    // fallback
  }
  return [];
}

export function isEmailBlocked(email: string): boolean {
  if (!email) return false;
  const blocked = getBlockedEmails();
  const clean = email.trim().toLowerCase();
  return blocked.some((b) => b.trim().toLowerCase() === clean);
}

export function toggleBlockEmail(email: string): boolean {
  const clean = email.trim().toLowerCase();
  // Master email cannot be blocked
  if (isMasterEmail(clean)) return false;

  const blocked = getBlockedEmails();
  const exists = blocked.some((b) => b.toLowerCase() === clean);
  let updated: string[];
  if (exists) {
    updated = blocked.filter((b) => b.toLowerCase() !== clean);
  } else {
    updated = [...blocked, clean];
  }
  localStorage.setItem(STORAGE_BLOCKED_KEY, JSON.stringify(updated));
  return !exists; // returns true if newly blocked
}

// Notifications for Daksh whenever any real user signs up
export function getDakshNotifications(): SignupNotification[] {
  try {
    const raw = localStorage.getItem(STORAGE_NOTIFICATIONS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    // fallback
  }
  return [];
}

export function markNotificationAsRead(id: string): void {
  const notifs = getDakshNotifications();
  const updated = notifs.map((n) => (n.id === id ? { ...n, read: true } : n));
  localStorage.setItem(STORAGE_NOTIFICATIONS_KEY, JSON.stringify(updated));
}

export function clearAllNotifications(): void {
  localStorage.setItem(STORAGE_NOTIFICATIONS_KEY, JSON.stringify([]));
}

// Real Registered Users (NO fake/mock accounts)
export function getRegisteredUsers(): UserProfile[] {
  try {
    const raw = localStorage.getItem(STORAGE_USERS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // Tag blocked status
        const blocked = getBlockedEmails();
        return parsed.map((u) => ({
          ...u,
          isBlocked: blocked.includes(u.gmail.toLowerCase()),
        }));
      }
    }
  } catch (e) {
    // fallback
  }
  return [];
}

// Verify credentials during login / details filling
export function verifyUserCredentials(
  email: string,
  password?: string
): { success: boolean; error?: string; isMaster?: boolean; user?: UserProfile } {
  const cleanEmail = email.trim().toLowerCase();

  // Check if blocked
  if (isEmailBlocked(cleanEmail)) {
    return {
      success: false,
      error: `Access Denied: The account "${email}" has been blocked by the Administrator (dakshphosamani@gmail.com).`,
    };
  }

  // Check if master
  if (isMasterEmail(cleanEmail)) {
    if (password && password.trim() === MASTER_PASSWORD) {
      return { success: true, isMaster: true };
    }
    return {
      success: false,
      error: `Master ID requires password "${MASTER_PASSWORD}" to access the administrative terminal.`,
    };
  }

  // Check regular user permanent password
  const users = getRegisteredUsers();
  const existing = users.find((u) => u.gmail.toLowerCase() === cleanEmail);

  if (existing && existing.password) {
    if (password && existing.password !== password) {
      return {
        success: false,
        error: `Incorrect permanent password for "${email}". Please enter the password you set during initial signup.`,
      };
    }
    return { success: true, user: existing };
  }

  // New user signing up
  return { success: true };
}

// Record User Registration / Session with Permanent Password
export function recordUserSession(profile: UserProfile, password?: string): UserProfile {
  const users = getRegisteredUsers();
  const isMaster = isMasterCredentials(profile.gmail, password);
  const cleanEmail = profile.gmail.trim().toLowerCase();
  
  const id = profile.id || `trader-${cleanEmail.split('@')[0]}-${Math.floor(100 + Math.random() * 900)}`;
  const permanentPassword = password || profile.password || 'Tr@der2026';

  const updatedProfile: UserProfile = {
    ...profile,
    id,
    gmail: cleanEmail,
    password: permanentPassword,
    isMasterAdmin: isMaster,
    isMasterUser: isMaster,
    hasCompletedOnboarding: true,
    lastActive: new Date().toISOString(),
    isBlocked: isEmailBlocked(cleanEmail),
  };

  const existingIndex = users.findIndex((u) => u.gmail.toLowerCase() === cleanEmail);
  let newUsers: UserProfile[];
  const isNewSignup = existingIndex < 0;

  if (!isNewSignup) {
    newUsers = [...users];
    newUsers[existingIndex] = {
      ...newUsers[existingIndex],
      ...updatedProfile,
      // Retain original permanent password if not overridden
      password: newUsers[existingIndex].password || permanentPassword,
      lastActive: new Date().toISOString(),
    };
  } else {
    // Save new real user
    newUsers = [updatedProfile, ...users];

    // Dispatch notification to Daksh's master account if not Daksh himself signing in
    if (!isMaster) {
      const notif: SignupNotification = {
        id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        userEmail: cleanEmail,
        userName: profile.name,
        permanentPassword,
        initialCapital: profile.initialCapital,
        experience: profile.experience,
        timestamp: new Date().toISOString(),
        read: false,
      };
      const currentNotifs = getDakshNotifications();
      localStorage.setItem(STORAGE_NOTIFICATIONS_KEY, JSON.stringify([notif, ...currentNotifs]));
    }
  }

  localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(newUsers));

  // Log session activity
  recordUserActivity(
    updatedProfile,
    'LOGIN',
    isMaster
      ? 'Master Terminal Administrator logged in with VIP Supervisor authorization'
      : isNewSignup
      ? `New Trader signed up: Capital ₹${updatedProfile.initialCapital.toLocaleString()} (Permanent Password Set)`
      : `Trader logged into BreakoutPulse terminal`
  );

  return updatedProfile;
}

// Delete / deregister a user (admin capability)
export function deleteUserAccount(email: string): void {
  const clean = email.trim().toLowerCase();
  const users = getRegisteredUsers();
  const filtered = users.filter((u) => u.gmail.toLowerCase() !== clean);
  localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(filtered));
}

// Real Activities
export function getUserActivities(filterEmail?: string): UserActivityItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_ACTIVITIES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        if (filterEmail) {
          return parsed.filter((a) => a.userEmail.toLowerCase() === filterEmail.toLowerCase());
        }
        return parsed;
      }
    }
  } catch (e) {
    // fallback
  }
  return [];
}

type UserLike = { email?: string; gmail?: string; name?: string; id?: string };

export function recordUserActivity(
  user: UserProfile | UserLike | null,
  action: UserActivityItem['action'],
  details: string,
  symbol?: string,
  amount?: number
): void {
  const activities = getUserActivities();
  const effectiveUser = user as UserLike | null;
  const email = effectiveUser?.gmail || effectiveUser?.email || 'trader.demo@gmail.com';
  const name = effectiveUser?.name || email.split('@')[0];
  const userId = effectiveUser?.id || `user-${email.split('@')[0]}`;

  const newActivity: UserActivityItem = {
    id: `act-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    userId,
    userEmail: email,
    userName: name,
    action,
    details,
    timestamp: new Date().toISOString(),
    symbol,
    amount,
  };

  const updated = [newActivity, ...activities].slice(0, 200);
  localStorage.setItem(STORAGE_ACTIVITIES_KEY, JSON.stringify(updated));
}

// Real Trades
export function getAllUserTrades(filterEmail?: string): GlobalUserTradeRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_TRADES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        if (filterEmail) {
          return parsed.filter((t) => t.userEmail.toLowerCase() === filterEmail.toLowerCase());
        }
        return parsed;
      }
    }
  } catch (e) {
    // fallback
  }
  return [];
}

export function recordGlobalTrade(
  user: UserProfile | UserLike | null,
  trade: PaperTradeRecord
): void {
  const trades = getAllUserTrades();
  const effectiveUser = user as UserLike | null;
  const email = effectiveUser?.gmail || effectiveUser?.email || 'trader.demo@gmail.com';
  const name = effectiveUser?.name || email.split('@')[0];
  const userId = effectiveUser?.id || `user-${email.split('@')[0]}`;

  const globalTrade: GlobalUserTradeRecord = {
    ...trade,
    userId,
    userEmail: email,
    userName: name,
  };

  const updated = [globalTrade, ...trades].slice(0, 250);
  localStorage.setItem(STORAGE_TRADES_KEY, JSON.stringify(updated));

  // Also record activity
  recordUserActivity(
    user,
    'PAPER_TRADE_SELL',
    `Closed ${trade.symbol} (${trade.side}) at ₹${trade.exitPrice} | PnL: ${trade.netPnl >= 0 ? '+' : ''}₹${trade.netPnl.toLocaleString()} (${trade.netPnlPercent >= 0 ? '+' : ''}${trade.netPnlPercent}%) - ${trade.exitReason}`,
    trade.symbol,
    trade.netPnl
  );
}
