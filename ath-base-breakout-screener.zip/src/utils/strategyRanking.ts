import { Stock } from '../types';

export interface StrategyEvaluation {
  stock: Stock;
  score: number;
  strategy1Satisfied: boolean; // ATH <= 10%
  strategy2Satisfied: boolean; // ATL <= 10% or oversold momentum hook
  isDualConfluence: boolean;
  strategy1Score: number;
  strategy2Score: number;
  primaryStrategyName: 'Strategy 1: ATH Base Breakout' | 'Strategy 2: ATL Turnaround' | 'Dual Strategy Confluence' | 'Momentum Radar';
  badgeLabel: string;
  reason: string;
}

/**
 * Evaluates how strongly an individual stock satisfies Strategy 1 (ATH <= 10%)
 * and Strategy 2 (ATL <= 10% or oversold reversal).
 */
export function evaluateStockStrategies(stock: Stock): StrategyEvaluation {
  const isStrategy1 = stock.distToAth <= 10;
  const isStrategy2 = stock.distToAtl <= 10 || (stock.stochK < 40 && stock.stochK > stock.stochD);

  let s1Score = 0;
  if (isStrategy1) {
    // Proximity to ATH: closer gives more points (up to 40 pts)
    const proximityPoints = Math.max(0, (10 - stock.distToAth) * 4);
    s1Score += proximityPoints;

    // Breakout confirmation past horizontal pivot resistance (up to 30 pts)
    if (stock.currentPrice >= stock.baseResistance) {
      s1Score += 30;
    } else if (stock.currentPrice >= stock.baseResistance * 0.98) {
      s1Score += 18; // Coiling tight right beneath pivot
    }

    // 20 EMA dynamic support (20 pts)
    if (stock.currentPrice >= stock.supportEma) {
      s1Score += 20;
    }

    // Institutional volume ratio (up to 25 pts)
    if (stock.volumeRatio >= 2.0) {
      s1Score += 25;
    } else if (stock.volumeRatio >= 1.5) {
      s1Score += 18;
    } else if (stock.volumeRatio >= 1.2) {
      s1Score += 10;
    }

    // Stochastic momentum continuation (15 pts)
    if (stock.stochK > stock.stochD) {
      s1Score += 15;
    }
  }

  let s2Score = 0;
  if (isStrategy2) {
    // Proximity to ATL: closer gives more points (up to 40 pts)
    const atlPoints = stock.distToAtl <= 10 ? Math.max(0, (10 - stock.distToAtl) * 4) : 10;
    s2Score += atlPoints;

    // Oversold Stochastic Hook / Bullish Cross (up to 35 pts)
    if (stock.stochK < 35 && stock.stochK > stock.stochD) {
      s2Score += 35; // Golden hook from deep oversold
    } else if (stock.stochK > stock.stochD) {
      s2Score += 20;
    }

    // Dynamic 20 EMA reclaim (20 pts)
    if (stock.currentPrice >= stock.supportEma) {
      s2Score += 20;
    }

    // Rebound volume accumulation (15 pts)
    if (stock.volumeRatio >= 1.3) {
      s2Score += 15;
    }
  }

  const isDual = isStrategy1 && isStrategy2;
  const dualBonus = isDual ? 35 : 0;
  const totalScore = Math.max(s1Score, s2Score) + (isDual ? dualBonus : 0);

  let primaryStrategyName: StrategyEvaluation['primaryStrategyName'] = 'Momentum Radar';
  let badgeLabel = 'Momentum Radar';
  let reason = '';

  if (isDual) {
    primaryStrategyName = 'Dual Strategy Confluence';
    badgeLabel = '⚡ 10% Strategy Confluence';
    reason = `Satisfies 10% ATH proximity (${stock.distToAth}% from ATH) and momentum hook above 20 EMA.`;
  } else if (s1Score >= s2Score && isStrategy1) {
    primaryStrategyName = 'Strategy 1: ATH Base Breakout';
    badgeLabel = '🎯 10% ATH Strategy';
    reason = `Only ${stock.distToAth}% below All-Time High (≤10%) with 20 EMA cushion at ₹${stock.supportEma}.`;
  } else if (isStrategy2) {
    primaryStrategyName = 'Strategy 2: ATL Turnaround';
    badgeLabel = '🔄 10% Value Turnaround';
    reason = `Cyclical support floor (${stock.distToAtl}% from ATL) with bullish Stochastic crossover (%K ${stock.stochK} > %D ${stock.stochD}).`;
  } else {
    reason = `Active NSE momentum asset holding key support levels.`;
  }

  return {
    stock,
    score: totalScore,
    strategy1Satisfied: isStrategy1,
    strategy2Satisfied: isStrategy2,
    isDualConfluence: isDual,
    strategy1Score: s1Score,
    strategy2Score: s2Score,
    primaryStrategyName,
    badgeLabel,
    reason,
  };
}

/**
 * Returns all stocks ranked by their strategy satisfaction score in descending order.
 */
export function rankStocksByStrategy(stocks: Stock[]): StrategyEvaluation[] {
  return stocks
    .map(evaluateStockStrategies)
    .sort((a, b) => b.score - a.score);
}

/**
 * Dynamically finds the single stock in the universe that BEST satisfies
 * the conditions of the two strategies. No stock is ever hardcoded.
 */
export function getBestStrategyStock(stocks: Stock[]): Stock {
  if (!stocks || stocks.length === 0) {
    throw new Error('Stock universe is empty');
  }

  const ranked = rankStocksByStrategy(stocks);
  return ranked[0].stock;
}
