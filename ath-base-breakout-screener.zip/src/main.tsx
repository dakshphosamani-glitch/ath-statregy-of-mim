import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Guard against external cross-origin script errors leaking from third-party embeds
window.addEventListener('error', (event) => {
  if (
    event.message === 'Script error.' ||
    event.message?.includes('ResizeObserver') ||
    event.filename === ''
  ) {
    event.stopImmediatePropagation();
    event.preventDefault();
    return true;
  }
});

window.addEventListener('unhandledrejection', (event) => {
  if (
    event.reason?.message === 'Script error.' ||
    event.reason?.message?.includes('ResizeObserver')
  ) {
    event.stopImmediatePropagation();
    event.preventDefault();
  }
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

